# ComplianceIQ — Scanner (Core Service)

Scanner CSPM multi-cloud : découverte, normalisation, graphe de ressources,
évaluation de règles contextuelles, analyse de chemins d'attaque, détection
de dérive de posture, production de findings tracables.

Ce document décrit exactement ce qui est implémenté dans ce dépôt — aucune
fonctionnalité listée ici n'est planifiée ou partiellement codée sans que ce
soit signalé explicitement dans la section *Limites connues*.

---

## Objectif de cette phase

Faire de la découverte, du Resource Graph, du Drift Detection et de
l'Attack Path Analysis des **capacités centrales** du scanner, câblées dans
un seul pipeline exécutable — pas des modules isolés ni des classes vides
en attente d'implémentation future. Chaque capacité devait être prouvée par
des tests réellement exécutés, pas seulement écrite.

---

## Fonctionnalités implémentées

| Capacité | État |
|---|---|
| Découverte AWS (S3, Security Groups, IAM) | ✅ Code écrit — ⚠️ jamais exécuté contre un compte réel (voir Limites) |
| Découverte hors-ligne déterministe (mock) | ✅ Exécutée, 8 ressources fixtures |
| Normalisation multi-cloud (`NormalizedResource`) | ✅ |
| Modélisation des relations entre ressources | ✅ |
| Resource Graph (nœuds, arêtes, traversées bornées) | ✅ |
| Policy Engine déclaratif YAML (règles simples) | ✅ 33 règles, 5 domaines |
| Policy Engine contextuel (AND / OR / NOT, fonctions sur le graphe) | ✅ |
| Attack Path Analysis (découverte, contraintes, scoring, techniques) | ✅ |
| Drift Detection (canonicalisation, diff, classification) | ✅ |
| Enrichissement du risque par l'implication dans un Attack Path | ✅ |
| Contrat de sortie aligné sur l'AI Service (11 champs documentés) | ✅ |
| Persistance (PostgreSQL) | ❌ Non implémentée dans ce dépôt |
| API HTTP | ❌ Non implémentée dans ce dépôt |
| Authentification / autorisation | ❌ Non implémentée dans ce dépôt |
| Collecteur Azure | ❌ Non implémenté dans ce dépôt |

---

## Architecture et modules

```
scanner/
├── schema.py            Modèles canoniques : NormalizedResource, Rule,
│                         Finding, ResourceRelationship, enums partagés
├── value_objects.py      Evidence, RiskScore, ConfidenceScore
├── conditions.py          Évaluateur de conditions AND/OR/NOT, feuilles
│                         resource ou graph, logique à trois valeurs
├── rule_engine.py         Chargement des règles YAML, orchestration de
│                         l'évaluation, RiskCalculator
├── scan_service.py        Orchestrateur : collecte → graphe → règles →
│                         attack path → enrichissement du risque → drift
├── graph/
│   ├── models.py           GraphNode, GraphEdge, ResourceGraph
│   ├── builder.py          Construit le graphe à partir des relations
│   │                     réellement collectées
│   └── context.py          ResourceContext + registre fermé de fonctions
│                         contextuelles (is_publicly_exposed,
│                         is_reachable_from_internet, has_path_to)
├── attack_path/
│   ├── models.py           AttackPath, AttackPathEdgeRef, ExposureLevel
│   ├── discovery.py         PathDiscovery — DFS borné en profondeur et en
│   │                     nombre de chemins
│   ├── constraints.py       PathConstraintEvaluator — exposition,
│   │                     privilège, sensibilité de la cible
│   ├── scorer.py            AttackPathScorer — score versionné (1.0)
│   ├── technique_mapper.py   AttackTechniqueMapper — étiquettes dérivées
│   │                     des attributs réellement collectés
│   └── analyzer.py          AttackPathAnalyzer — orchestrateur
├── drift/
│   ├── models.py            DriftEvent, DriftType
│   ├── canonicalization.py   Forme canonique d'une ressource avant
│   │                     comparaison
│   └── diff_engine.py        DiffEngine — compare deux snapshots,
│                         classe chaque changement
└── collectors/
    ├── base.py               BaseCollector, CollectionResult
    ├── mock_collector.py      Collecteur hors-ligne déterministe
    └── aws_collector.py       Collecteur AWS réel (boto3)
```

**Règle de dépendance respectée** : aucun fichier de `scanner/` n'importe
directement `boto3` — même `collectors/aws_collector.py` reçoit une
`boto3.Session` déjà construite en paramètre (injection de dépendance),
plutôt que de créer sa propre dépendance au SDK. Les fonctions
contextuelles du graphe (`graph/context.py`) forment un registre fermé —
une règle YAML ne peut appeler que les trois fonctions qui y sont
enregistrées, jamais du code arbitraire (`eval()` n'est utilisé nulle part
dans le projet).

---

## Modèles et composants principaux

### `NormalizedResource` (`schema.py`)
Champs : `resource_id`, `resource_type`, `cloud_provider`, `tenant_id`,
`region`, `attributes` (dict libre, propre au fournisseur), `tags`,
`relationships` (liste de `ResourceRelationship`), `collected_at`.
Immuable (`frozen=True`), rejette tout champ inconnu (`extra="forbid"`).

### `ResourceRelationship` (`schema.py`)
`relationship_type` (enum `RelationshipType` : `CONTAINS`, `CONNECTS_TO`,
`PROTECTS`, `ALLOWS`, `ASSUMES`, `ACCESSES`, `ATTACHED_TO`,
`PUBLICLY_EXPOSED`), `target_resource_id`, `source_field` (traçabilité —
d'où vient la donnée), `properties`.

### `Finding` (`schema.py`)
Champs exposés au contrat AI Service (11) : `id`, `tenant_id`,
`resource_id`, `rule_id`, `framework`, `control_id`, `domain`, `status`,
`severity`, `evidence`, `detected_at`. Champs internes supplémentaires :
`scan_id`, `rule_version`, `region`, `environment`, `risk` (`RiskScore`),
`confidence` (`ConfidenceScore`), `version`, `superseded_by`,
`related_drift_event_ids`, `related_attack_path_ids`.

### `ResourceGraph` (`graph/models.py`)
Graphe en mémoire scopé à un tenant. `add_node`/`add_edge` valident
l'isolation multi-tenant et l'existence des nœuds référencés. Un nœud
`__internet__` (`INTERNET_NODE_ID`) est ajouté uniquement si au moins une
ressource porte une relation `PUBLICLY_EXPOSED`.

### `ConditionOutcome` / `evaluate_condition_tree` (`conditions.py`)
Trois états : `matched`, `not_matched`, `indeterminate`. Un attribut non
collecté ne devient jamais une conformité silencieuse. Les combinateurs
`all`/`any`/`not` suivent une logique à trois valeurs cohérente (ex : `not`
d'un résultat indéterminé reste indéterminé, jamais inversé en un
booléen). Opérateurs supportés sur les feuilles resource : `equals`,
`not_equals`, `greater_than`, `less_than`, `contains`, `not_contains`,
`in`, `not_in`, `exists`, `not_exists`.

### `AttackPath` (`attack_path/models.py`)
`id`, `tenant_id`, `source_resource_id`, `target_resource_id`, `nodes`,
`edges`, `risk_score`, `severity`, `exposure`, `attack_techniques`,
`contributing_finding_ids`, `discovered_at`, `graph_version`,
`algorithm_version` (fixé à `"1.0"`).

### `DriftEvent` (`drift/models.py`)
`id`, `tenant_id`, `resource_id`, `previous_scan_id`, `current_scan_id`,
`field`, `old_value`, `new_value`, `drift_type` (`CONFIGURATION_DRIFT`,
`SECURITY_POSTURE_DRIFT`, `RESOURCE_LIFECYCLE_DRIFT`,
`RELATIONSHIP_DRIFT`), `severity`, `detected_at`, `related_rule_id`.

---

## Flux d'exécution (`ScanService.run`)

```
1. Collecte (un ou plusieurs collecteurs, AWS et/ou mock)
2. Construction du Resource Graph (GraphBuilder, à partir des
   `relationships` réellement portées par les ressources collectées)
3. Évaluation des règles (RuleEngine, graph-aware — les conditions
   `source: graph` consultent le graphe construit à l'étape 2)
4. Analyse des chemins d'attaque (AttackPathAnalyzer, à partir du graphe
   et des findings en échec produits à l'étape 3)
5. Enrichissement du risque (les findings impliqués dans un chemin
   d'attaque voient leur RiskScore augmenté du facteur
   attack_path_involvement, et reçoivent les related_attack_path_ids
   correspondants)
6. Drift (uniquement si un snapshot précédent est fourni en paramètre de
   `run()` — sinon cette étape est simplement absente du rapport)
```

Séquence justifiée dans le code (`scan_service.py`, docstring du module) :
le graphe précède l'évaluation des règles car des conditions contextuelles
en dépendent ; l'Attack Path suit les findings car il cite les findings
contributeurs par nœud du chemin ; le risque est enrichi après l'Attack
Path car le facteur `attack_path_involvement` n'est connu qu'à ce moment.

---

## Tests et résultats

Exécutés réellement dans l'environnement de développement (voir
`pytest.ini`, substitut Pydantic utilisé en l'absence de réseau — voir
Limites) :

| Fichier | Tests | Résultat |
|---|---|---|
| `test_rule_engine.py` | 35 | ✅ verts |
| `test_scan_service.py` | 12 | ✅ verts |
| `test_drift.py` | 12 | ✅ verts |
| `test_value_objects.py` | 9 | ✅ verts |
| `test_attack_path.py` | 9 | ✅ verts |
| `test_graph.py` | 7 | ✅ verts |
| **Total exécuté** | **84** | **✅ 84/84** |
| `test_aws_collector_moto.py` | 6 | ⚠️ non exécuté (dépendances `moto`/`boto3` absentes de l'environnement d'écriture) |

Cas explicitement couverts par les tests dédiés :
- **Graph** : construction depuis des relations réelles, absence de nœud
  Internet quand rien n'est exposé, relation vers une cible hors périmètre
  ignorée (jamais fabriquée), cycles sans boucle infinie, arête bloquée
  exclue des voisins par défaut, isolation multi-tenant, arête vers un
  nœud inexistant rejetée.
- **Attack Path** : chemin public → base de données, chemin multi-sauts
  (LB → app → DB), chemin bloqué par un contrôle de sécurité (score 0),
  chemins multiples vers la même cible, graphe cyclique, profondeur
  maximale respectée, chemin impliquant une identité privilégiée scorant
  plus haut, aucun chemin sans exposition publique, lien bidirectionnel
  finding ↔ chemin.
- **Drift** : absence de changement, `collected_at` seul n'en produit
  jamais, ordre des tags ignoré, dégradation de posture (sévérité HIGH),
  amélioration de posture (sévérité LOW), drift de configuration,
  drift de relation, création/suppression de ressource, ajout/retrait
  d'attribut, isolation multi-tenant.

Commande :
```bash
pip install -r requirements-dev.txt
pytest -v
python -m scripts.demo_scan   # démonstration hors-ligne complète
```

---

## Limites connues / éléments non implémentés

- **Collecteur AWS réel jamais exécuté** contre un compte AWS ni contre
  `moto` — écrit, non prouvé. `test_aws_collector_moto.py` existe mais
  n'a jamais tourné faute de dépendances installées dans l'environnement
  d'écriture.
- **Tests exécutés avec un substitut Pydantic maison**, pas la
  bibliothèque réelle (absente du réseau de l'environnement d'écriture).
  La logique métier est prouvée ; la validation stricte réelle de
  Pydantic (`extra="forbid"`, coercition de types) n'a pas été vérifiée
  avec la bibliothèque officielle.
- **`MISSING COLLECTOR CAPABILITY` documenté dans le code**
  (`aws_collector.py`) : la relation `ALLOWS` entre un security group et
  une instance RDS existe dans `MockAwsCollector` mais pas dans le
  collecteur AWS réel — celui-ci ne collecte pas encore les instances RDS
  du tout, ni l'attachement des security groups aux ressources.
- **Persistance absente** : aucun scan n'est sauvegardé. Le Drift
  Detection est fonctionnel et testé, mais compare deux jeux de données
  fournis directement en mémoire (voir `ScanService.run`,
  paramètres `previous_resources`/`previous_scan_id`) — rien ne fournit
  encore automatiquement le scan précédent depuis un historique.
- **`contributing_finding_ids` sur-attribue parfois** : un finding en
  échec sur un nœud du chemin est considéré contributeur même s'il n'a
  pas de lien causal avec l'exploitabilité de ce chemin précis (ex : un
  problème de rétention de sauvegarde apparaissant comme contributeur
  d'un chemin d'exploitation réseau). Limite documentée dans
  `attack_path/analyzer.py`.
- **`SENSITIVE_RESOURCE_TYPES`** (`rds_instance`, `s3_bucket`) est une
  heuristique fixe dans le code, pas un catalogue de criticité des actifs
  configurable.
- Aucune API HTTP, aucune authentification, aucun collecteur Azure,
  aucune persistance PostgreSQL — aucun de ces éléments n'a de code dans
  ce dépôt.

---

## Prochaines étapes

1. Exécuter réellement `test_aws_collector_moto.py` (installer
   `moto`/`boto3`) pour confirmer le collecteur AWS.
2. Étendre `aws_collector.py` pour collecter les instances RDS et
   l'attachement des security groups, afin que la relation `ALLOWS`
   SG→RDS soit produite par le collecteur réel, pas seulement par le mock.
3. Ajouter la persistance des scans (PostgreSQL) pour que le Drift Engine
   compare deux scans historiques réels plutôt qu'un couple fourni
   manuellement.
4. Exposer une API HTTP pour rendre les résultats du scan consommables
   par l'AI Service et un futur dashboard.
5. Affiner `contributing_finding_ids` par catégorisation des règles
   (vecteur d'accès vs impact) pour réduire la sur-attribution documentée.
