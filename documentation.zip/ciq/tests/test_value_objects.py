"""Tests des value objects introduits par la revue d'architecture du Finding.

Chaque test prouve un défaut réel de l'ancien modèle (dict libre, float nu)
qui ne peut plus se produire avec le nouveau.
"""
from datetime import datetime, timezone

import pytest

from scanner.value_objects import ConfidenceScore, Evidence, EvidenceOutcome, RiskScore

NOW = datetime(2026, 1, 15, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# Evidence — corrige P2 : plus de dict libre à 3 formes
# ---------------------------------------------------------------------------
def test_evidence_matched_has_a_stable_shape():
    ev = Evidence(
        outcome=EvidenceOutcome.MATCHED,
        observed_attribute="public_access_blocked",
        expected_value=False,
        actual_value=False,
        operator="equals",
        collector="aws",
        collected_at=NOW,
    )
    assert ev.outcome == EvidenceOutcome.MATCHED
    assert ev.indeterminate_reason is None


def test_evidence_indeterminate_requires_a_reason():
    """Avant : un dict {reason: 'indeterminate', ...} sans garantie de
    structure. Maintenant : impossible de construire un Evidence
    indéterminé sans expliquer pourquoi."""
    with pytest.raises(ValueError):
        Evidence(
            outcome=EvidenceOutcome.INDETERMINATE,
            observed_attribute="encrypted",
            collected_at=NOW,
            # indeterminate_reason manquant volontairement
        )


def test_evidence_non_indeterminate_cannot_carry_a_reason():
    """Symétrique : une raison d'indétermination sur un finding conforme
    serait incohérente et signalerait un bug amont."""
    with pytest.raises(ValueError):
        Evidence(
            outcome=EvidenceOutcome.MATCHED,
            observed_attribute="encrypted",
            collected_at=NOW,
            indeterminate_reason="ne devrait pas être là",
        )


def test_evidence_rejects_unknown_fields():
    """extra='forbid' : un champ en trop (ex: une config brute oubliée
    par erreur) fait échouer la construction plutôt que de fuiter."""
    with pytest.raises(TypeError):
        Evidence(
            outcome=EvidenceOutcome.MATCHED,
            observed_attribute="x",
            collected_at=NOW,
            secret_access_key="AKIA...",  # ne doit JAMAIS pouvoir passer
        )


# ---------------------------------------------------------------------------
# RiskScore — corrige P8 : plus de float nu, sans borne ni version
# ---------------------------------------------------------------------------
def test_risk_score_is_bounded():
    with pytest.raises(ValueError):
        RiskScore(value=150.0)
    with pytest.raises(ValueError):
        RiskScore(value=-1.0)


def test_risk_score_carries_a_model_version():
    """Le champ non négociable de la revue (Q8) : sans lui, un score
    archivé n'est pas reproductible."""
    score = RiskScore(value=85.0)
    assert score.model_version == "crsf-1.0"


def test_risk_score_preserves_explainability_factors():
    score = RiskScore(value=91.5, factors={"severity": 1.0, "exposure": 1.0})
    assert score.factors["severity"] == 1.0


# ---------------------------------------------------------------------------
# ConfidenceScore
# ---------------------------------------------------------------------------
def test_confidence_score_band_thresholds():
    assert ConfidenceScore(value=95.0).band == "high"
    assert ConfidenceScore(value=70.0).band == "medium"
    assert ConfidenceScore(value=30.0).band == "low"


def test_confidence_score_is_bounded():
    with pytest.raises(ValueError):
        ConfidenceScore(value=101.0)
