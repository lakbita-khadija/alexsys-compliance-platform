"""
Test d'intégration du collecteur AWS avec `moto` (AWS simulé en mémoire).

NON EXÉCUTÉ dans l'environnement hors-ligne d'écriture : moto et boto3
n'y étaient pas installables. C'est LE test à lancer en premier pour
valider `scanner/collectors/aws_collector.py`.

    pip install moto boto3
    pytest tests/test_aws_collector_moto.py -v

Si ce test passe, le collecteur AWS parle correctement à l'API S3/EC2/IAM.
S'il échoue, le problème est dans aws_collector.py — le reste du scanner
(Rule Engine, ScanService) est déjà couvert par 35 tests verts.
"""

import pytest

boto3 = pytest.importorskip("boto3")
moto = pytest.importorskip("moto")

from moto import mock_aws  # noqa: E402

from scanner.collectors.aws_collector import AwsCollector  # noqa: E402

REGION = "eu-west-1"


@pytest.fixture
def session():
    with mock_aws():
        yield boto3.Session(
            aws_access_key_id="testing",
            aws_secret_access_key="testing",
            region_name=REGION,
        )


def test_collects_a_public_bucket_and_flags_its_attributes(session):
    s3 = session.client("s3", region_name=REGION)
    s3.create_bucket(
        Bucket="public-bucket",
        CreateBucketConfiguration={"LocationConstraint": REGION},
    )

    result = AwsCollector(session, region=REGION).collect("tenant-a")
    buckets = [r for r in result.resources if r.resource_type == "s3_bucket"]

    assert len(buckets) == 1
    assert buckets[0].resource_id == "public-bucket"
    assert buckets[0].tenant_id == "tenant-a"


def test_encrypted_bucket_is_detected_as_encrypted(session):
    s3 = session.client("s3", region_name=REGION)
    s3.create_bucket(
        Bucket="encrypted-bucket",
        CreateBucketConfiguration={"LocationConstraint": REGION},
    )
    s3.put_bucket_encryption(
        Bucket="encrypted-bucket",
        ServerSideEncryptionConfiguration={
            "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]
        },
    )

    result = AwsCollector(session, region=REGION).collect("tenant-a")
    bucket = next(r for r in result.resources if r.resource_id == "encrypted-bucket")
    assert bucket.attributes.get("encrypted") is True


def test_open_ssh_security_group_is_normalized_correctly(session):
    ec2 = session.client("ec2", region_name=REGION)
    vpc = ec2.create_vpc(CidrBlock="10.0.0.0/16")["Vpc"]
    sg = ec2.create_security_group(
        GroupName="open-ssh", Description="test", VpcId=vpc["VpcId"]
    )
    ec2.authorize_security_group_ingress(
        GroupId=sg["GroupId"],
        IpPermissions=[
            {
                "IpProtocol": "tcp",
                "FromPort": 22,
                "ToPort": 22,
                "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
            }
        ],
    )

    result = AwsCollector(session, region=REGION).collect("tenant-a")
    groups = [r for r in result.resources if r.resource_type == "security_group"]
    target = next(r for r in groups if r.resource_id == sg["GroupId"])

    assert target.attributes["ssh_open_to_world"] is True
    assert target.attributes["any_port_open_to_world"] is True
    assert target.attributes["rdp_open_to_world"] is False


def test_iam_user_without_mfa_is_normalized(session):
    iam = session.client("iam")
    iam.create_user(UserName="no-mfa-user")

    result = AwsCollector(session, region=REGION).collect("tenant-a")
    users = [r for r in result.resources if r.resource_type == "iam_user"]
    target = next(r for r in users if r.resource_id == "no-mfa-user")

    assert target.attributes.get("mfa_enabled") is False


def test_collection_does_not_raise_when_a_service_is_unavailable(session):
    """Tolérance aux échecs partiels : l'objet CollectionResult est toujours
    renvoyé, jamais une exception."""
    result = AwsCollector(session, region=REGION).collect("tenant-a")
    assert result is not None
    assert isinstance(result.resources, list)
    assert isinstance(result.errors, list)


def test_end_to_end_scan_with_moto_produces_findings(session):
    """Chaîne complète : AWS simulé -> collecteur -> Rule Engine -> findings."""
    from pathlib import Path

    from scanner.rule_engine import RuleEngine
    from scanner.scan_service import ScanService

    s3 = session.client("s3", region_name=REGION)
    s3.create_bucket(
        Bucket="scan-me", CreateBucketConfiguration={"LocationConstraint": REGION}
    )

    rules_dir = Path(__file__).resolve().parent.parent / "rules"
    service = ScanService(
        collectors=[AwsCollector(session, region=REGION)],
        rule_engine=RuleEngine.from_directory(rules_dir),
    )
    report = service.run("tenant-a")

    assert report.resources
    assert report.findings
    assert all(f.tenant_id == "tenant-a" for f in report.findings)
