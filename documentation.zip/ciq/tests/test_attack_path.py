"""Tests de l'Attack Path Engine — cas exigés explicitement au cahier des
charges : chemin public->DB, chemin bloqué, chemins multiples, cycle,
profondeur max, scoring, confiance (via findings contributeurs)."""
from datetime import datetime, timezone

from scanner.attack_path.analyzer import AttackPathAnalyzer
from scanner.attack_path.discovery import PathDiscovery
from scanner.graph.builder import GraphBuilder
from scanner.graph.models import INTERNET_NODE_ID
from scanner.schema import (
    CloudProvider,
    ComplianceStatus,
    Domain,
    Framework,
    Finding,
    NormalizedResource,
    RelationshipType,
    ResourceRelationship,
    Severity,
)
from scanner.value_objects import ConfidenceScore, Evidence, EvidenceOutcome, RiskScore

NOW = datetime(2026, 1, 15, tzinfo=timezone.utc)


def _resource(rid, rtype, relationships=None, attributes=None, tenant="tenant-a"):
    return NormalizedResource(
        resource_id=rid, resource_type=rtype, cloud_provider=CloudProvider.AWS,
        tenant_id=tenant, region="eu-west-1", attributes=attributes or {},
        relationships=relationships or [],
    )


def _finding(resource_id, rule_id="r1", tenant="tenant-a"):
    return Finding(
        tenant_id=tenant, scan_id="scan-1", cloud_provider=CloudProvider.AWS,
        resource_id=resource_id, resource_type="rds_instance", rule_id=rule_id,
        domain=Domain.NETWORK, severity=Severity.HIGH, status=ComplianceStatus.FAIL,
        description="test", framework=Framework.ISO_27001, control_id="A.1",
        evidence=Evidence(outcome=EvidenceOutcome.MATCHED, observed_attribute="x",
                           collected_at=NOW),
        risk=RiskScore(value=50.0), confidence=ConfidenceScore(value=95.0),
    )


def test_public_vm_to_database_path_is_detected():
    sg = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="db-1", source_field="test"),
    ])
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([sg, db], tenant_id="tenant-a")

    findings = [_finding("db-1")]
    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", findings)

    assert len(paths) == 1
    assert paths[0].nodes == [INTERNET_NODE_ID, "sg-1", "db-1"]
    assert paths[0].target_resource_id == "db-1"
    assert paths[0].risk_score > 0
    assert paths[0].algorithm_version == "1.0"


def test_public_lb_to_app_to_database_multi_hop_path():
    lb = _resource("lb-1", "load_balancer", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="app-1", source_field="test"),
    ])
    app = _resource("app-1", "compute_instance", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.ACCESSES,
                              target_resource_id="db-1", source_field="test"),
    ])
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([lb, app, db], tenant_id="tenant-a")

    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", [])
    assert any(p.nodes == [INTERNET_NODE_ID, "lb-1", "app-1", "db-1"] for p in paths)


def test_blocked_path_produces_no_attack_path():
    """Un chemin techniquement présent mais bloqué par un contrôle de
    sécurité actif ne doit JAMAIS être compté comme exploitable."""
    sg = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="db-1", source_field="test",
                              properties={"blocked": True}),
    ])
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([sg, db], tenant_id="tenant-a")

    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", [])
    assert paths == []


def test_multiple_independent_paths_to_the_same_target():
    sg1 = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="db-1", source_field="test"),
    ])
    sg2 = _resource("sg-2", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="db-1", source_field="test"),
    ])
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([sg1, sg2, db], tenant_id="tenant-a")

    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", [])
    targets = {p.nodes[-1] for p in paths}
    assert targets == {"db-1"}
    assert len(paths) == 2  # un chemin par security group


def test_cyclic_graph_does_not_hang_and_still_finds_the_path():
    sg = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="app-1", source_field="test"),
    ])
    app = _resource("app-1", "compute_instance", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="sg-1", source_field="test"),  # cycle
        ResourceRelationship(relationship_type=RelationshipType.ACCESSES,
                              target_resource_id="db-1", source_field="test"),
    ])
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([sg, app, db], tenant_id="tenant-a")

    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", [])
    assert any(p.nodes[-1] == "db-1" for p in paths)


def test_max_depth_prunes_paths_beyond_the_limit():
    resources = []
    prev_id = None
    for i in range(8):
        rid = f"hop-{i}"
        rels = []
        if prev_id is None:
            rels.append(ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                                               target_resource_id=INTERNET_NODE_ID, source_field="test"))
        else:
            pass
        resources.append(_resource(rid, "compute_instance", relationships=rels))
        prev_id = rid
    # chaîne hop-0 -> hop-1 -> ... -> hop-7 -> db-1 (9 sauts, > max_depth par défaut)
    for i in range(7):
        resources[i] = _resource(
            f"hop-{i}", "compute_instance",
            relationships=(resources[i].relationships + [
                ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                                      target_resource_id=f"hop-{i+1}", source_field="test")
            ]),
        )
    resources[-1] = _resource(
        "hop-7", "compute_instance",
        relationships=(resources[-1].relationships + [
            ResourceRelationship(relationship_type=RelationshipType.ACCESSES,
                                  target_resource_id="db-1", source_field="test")
        ]),
    )
    resources.append(_resource("db-1", "rds_instance"))

    graph = GraphBuilder.build(resources, tenant_id="tenant-a")
    discovery = PathDiscovery(max_depth=3, max_paths_per_target=5)
    paths = discovery.discover(graph, INTERNET_NODE_ID, ["db-1"])
    assert paths == []  # la cible est à 9 sauts, hors de la profondeur autorisée


def test_path_involving_privileged_identity_scores_higher():
    """Le chemin passant par une identité avec has_admin_access=True doit
    scorer plus haut qu'un chemin équivalent sans ce facteur — c'est la
    preuve que ce n'est PAS un simple plus-court-chemin."""
    sg_a = _resource("sg-a", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="db-a", source_field="test"),
    ])
    db_a = _resource("db-a", "rds_instance")

    sg_b = _resource("sg-b", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ASSUMES,
                              target_resource_id="role-privileged", source_field="test"),
    ])
    role = _resource("role-privileged", "iam_role", attributes={"has_admin_access": True},
                      relationships=[
        ResourceRelationship(relationship_type=RelationshipType.ACCESSES,
                              target_resource_id="db-b", source_field="test"),
    ])
    db_b = _resource("db-b", "rds_instance")

    graph = GraphBuilder.build([sg_a, db_a, sg_b, role, db_b], tenant_id="tenant-a")
    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", [])

    path_a = next(p for p in paths if p.nodes[-1] == "db-a")
    path_b = next(p for p in paths if p.nodes[-1] == "db-b")
    assert path_b.risk_score > path_a.risk_score
    assert "privilege_escalation" in path_b.attack_techniques


def test_no_attack_paths_when_nothing_publicly_exposed():
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([db], tenant_id="tenant-a")
    assert AttackPathAnalyzer().analyze(graph, "tenant-a", []) == []


def test_contributing_findings_are_linked_bidirectionally():
    sg = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="db-1", source_field="test"),
    ])
    db = _resource("db-1", "rds_instance")
    graph = GraphBuilder.build([sg, db], tenant_id="tenant-a")

    finding = _finding("db-1", rule_id="storage.rds_not_encrypted")
    paths = AttackPathAnalyzer().analyze(graph, "tenant-a", [finding])

    assert finding.finding_id in paths[0].contributing_finding_ids
