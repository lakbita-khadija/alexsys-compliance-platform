"""Tests du Resource Graph — construction, cycles, isolation multi-tenant."""
from datetime import datetime, timezone

import pytest

from scanner.graph.builder import GraphBuilder
from scanner.graph.models import INTERNET_NODE_ID, GraphEdge, GraphNode, ResourceGraph
from scanner.schema import CloudProvider, NormalizedResource, RelationshipType, ResourceRelationship

NOW = datetime(2026, 1, 15, tzinfo=timezone.utc)


def _resource(rid, rtype="s3_bucket", relationships=None, tenant="tenant-a"):
    return NormalizedResource(
        resource_id=rid, resource_type=rtype, cloud_provider=CloudProvider.AWS,
        tenant_id=tenant, region="eu-west-1", attributes={},
        relationships=relationships or [],
    )


def test_graph_construction_from_relationships():
    sg = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                              target_resource_id=INTERNET_NODE_ID, source_field="test"),
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="rds-1", source_field="test"),
    ])
    rds = _resource("rds-1", "rds_instance")

    graph = GraphBuilder.build([sg, rds], tenant_id="tenant-a")

    assert graph.node_count == 3  # sg, rds, + internet ajouté automatiquement
    assert graph.get_node(INTERNET_NODE_ID) is not None
    edges_from_internet = graph.neighbors(INTERNET_NODE_ID)
    assert any(e.target_id == "sg-1" for e in edges_from_internet)
    edges_from_sg = graph.neighbors("sg-1")
    assert any(e.target_id == "rds-1" for e in edges_from_sg)


def test_no_internet_node_when_nothing_is_publicly_exposed():
    """Ne jamais fabriquer un graphe connecté à Internet quand rien ne
    l'expose réellement."""
    private = _resource("db-private", "rds_instance")
    graph = GraphBuilder.build([private], tenant_id="tenant-a")
    assert graph.get_node(INTERNET_NODE_ID) is None


def test_relationship_to_uncollected_target_is_dropped_not_fabricated():
    """Une relation référençant une ressource hors périmètre du scan ne
    doit jamais créer un nœud fantôme."""
    sg = _resource("sg-1", "security_group", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="not-in-this-scan", source_field="test"),
    ])
    graph = GraphBuilder.build([sg], tenant_id="tenant-a")
    assert graph.get_node("not-in-this-scan") is None
    assert graph.edge_count == 0


def test_graph_handles_cycles_without_infinite_loop():
    a = _resource("a", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="b", source_field="test"),
    ])
    b = _resource("b", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="a", source_field="test"),
    ])
    graph = GraphBuilder.build([a, b], tenant_id="tenant-a")
    assert graph.edge_count == 2  # a->b et b->a, cycle représenté sans erreur


def test_blocked_edge_is_excluded_from_default_neighbors():
    a = _resource("a", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.ALLOWS,
                              target_resource_id="b", source_field="test",
                              properties={"blocked": True}),
    ])
    b = _resource("b")
    graph = GraphBuilder.build([a, b], tenant_id="tenant-a")
    assert graph.neighbors("a", include_blocked=False) == []
    assert len(graph.neighbors("a", include_blocked=True)) == 1


def test_adding_node_from_another_tenant_raises():
    """Isolation multi-tenant au niveau du graphe lui-même, pas seulement
    au niveau applicatif."""
    graph = ResourceGraph(tenant_id="tenant-a")
    with pytest.raises(ValueError):
        graph.add_node(GraphNode(id="x", resource_type="s3_bucket", tenant_id="tenant-b"))


def test_edge_to_nonexistent_node_raises():
    graph = ResourceGraph(tenant_id="tenant-a")
    graph.add_node(GraphNode(id="a", resource_type="s3_bucket", tenant_id="tenant-a"))
    with pytest.raises(ValueError):
        graph.add_edge(GraphEdge(source_id="a", target_id="ghost",
                                  relationship_type=RelationshipType.CONNECTS_TO))
