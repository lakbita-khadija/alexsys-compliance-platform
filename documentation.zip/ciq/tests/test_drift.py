"""Tests du Drift Detection Engine -- tous les cas exiges au cahier des
charges : pas de changement, drift de config, drift de posture, drift de
relation, creation, suppression, champ ajoute/retire, champs volatils
ignores, isolation multi-tenant."""
from scanner.drift.diff_engine import DiffEngine
from scanner.drift.models import DriftType
from scanner.schema import CloudProvider, NormalizedResource, RelationshipType, ResourceRelationship


def _resource(rid, attributes=None, tags=None, relationships=None, tenant="tenant-a"):
    return NormalizedResource(
        resource_id=rid, resource_type="s3_bucket", cloud_provider=CloudProvider.AWS,
        tenant_id=tenant, region="eu-west-1", attributes=attributes or {},
        tags=tags or {}, relationships=relationships or [],
    )


def test_no_change_produces_no_drift():
    r = _resource("b1", attributes={"encrypted": True})
    events = DiffEngine.compare({"b1": r}, {"b1": r}, "scan-1", "scan-2", "tenant-a")
    assert events == []


def test_collected_at_alone_never_produces_drift():
    """collected_at change a CHAQUE scan par construction -- la
    canonicalisation doit l'exclure, sinon chaque scan produirait un faux
    drift sur 100% des ressources."""
    r1 = _resource("b1", attributes={"encrypted": True})
    events = DiffEngine.compare({"b1": r1}, {"b1": r1}, "scan-1", "scan-2", "tenant-a")
    assert events == []


def test_tag_order_alone_never_produces_drift():
    r1 = _resource("b1", tags={"a": "1", "b": "2"})
    r2 = _resource("b1", tags={"b": "2", "a": "1"})
    events = DiffEngine.compare({"b1": r1}, {"b1": r2}, "scan-1", "scan-2", "tenant-a")
    assert events == []


def test_security_posture_drift_public_access_becomes_true():
    """L'exemple exact du cahier des charges : public_access false -> true
    doit produire un DriftEvent SECURITY_POSTURE_DRIFT de severite HIGH."""
    before = _resource("b1", attributes={"public_access_blocked": True})
    after = _resource("b1", attributes={"public_access_blocked": False})
    events = DiffEngine.compare({"b1": before}, {"b1": after}, "scan-1", "scan-2", "tenant-a")

    assert len(events) == 1
    assert events[0].drift_type == DriftType.SECURITY_POSTURE_DRIFT
    assert events[0].severity == "high"
    assert events[0].old_value is True
    assert events[0].new_value is False
    assert events[0].field == "attributes.public_access_blocked"


def test_security_posture_improving_is_low_severity_not_high():
    """La direction du changement compte : redevenir sur n'est pas la meme
    alerte que devenir dangereux."""
    before = _resource("b1", attributes={"public_access_blocked": False})
    after = _resource("b1", attributes={"public_access_blocked": True})
    events = DiffEngine.compare({"b1": before}, {"b1": after}, "scan-1", "scan-2", "tenant-a")
    assert events[0].severity == "low"


def test_configuration_drift_for_non_security_field():
    before = _resource("b1", attributes={"versioning_enabled": False})
    after = _resource("b1", attributes={"versioning_enabled": True})
    events = DiffEngine.compare({"b1": before}, {"b1": after}, "scan-1", "scan-2", "tenant-a")
    assert events[0].drift_type == DriftType.CONFIGURATION_DRIFT


def test_relationship_drift_when_target_changes():
    before = _resource("vm-1", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="subnet-A", source_field="test"),
    ])
    after = _resource("vm-1", relationships=[
        ResourceRelationship(relationship_type=RelationshipType.CONNECTS_TO,
                              target_resource_id="subnet-B", source_field="test"),
    ])
    events = DiffEngine.compare({"vm-1": before}, {"vm-1": after}, "scan-1", "scan-2", "tenant-a")
    assert any(e.drift_type == DriftType.RELATIONSHIP_DRIFT for e in events)


def test_resource_created_produces_lifecycle_drift():
    after = _resource("new-bucket")
    events = DiffEngine.compare({}, {"new-bucket": after}, "scan-1", "scan-2", "tenant-a")
    assert len(events) == 1
    assert events[0].drift_type == DriftType.RESOURCE_LIFECYCLE_DRIFT
    assert events[0].new_value == "created"


def test_resource_deleted_produces_lifecycle_drift():
    before = _resource("gone-bucket")
    events = DiffEngine.compare({"gone-bucket": before}, {}, "scan-1", "scan-2", "tenant-a")
    assert len(events) == 1
    assert events[0].drift_type == DriftType.RESOURCE_LIFECYCLE_DRIFT
    assert events[0].new_value == "deleted"


def test_property_added_is_a_configuration_drift():
    before = _resource("b1", attributes={})
    after = _resource("b1", attributes={"new_field": "value"})
    events = DiffEngine.compare({"b1": before}, {"b1": after}, "scan-1", "scan-2", "tenant-a")
    assert len(events) == 1
    assert events[0].old_value is None
    assert events[0].new_value == "value"


def test_property_removed_is_a_configuration_drift():
    before = _resource("b1", attributes={"old_field": "value"})
    after = _resource("b1", attributes={})
    events = DiffEngine.compare({"b1": before}, {"b1": after}, "scan-1", "scan-2", "tenant-a")
    assert len(events) == 1
    assert events[0].new_value is None


def test_multi_tenant_isolation_of_drift_events():
    before = _resource("b1", attributes={"encrypted": True}, tenant="tenant-a")
    after = _resource("b1", attributes={"encrypted": False}, tenant="tenant-a")
    events = DiffEngine.compare({"b1": before}, {"b1": after}, "scan-1", "scan-2", "tenant-a")
    assert all(e.tenant_id == "tenant-a" for e in events)
