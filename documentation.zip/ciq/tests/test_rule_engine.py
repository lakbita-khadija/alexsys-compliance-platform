"""Tests du Rule Engine.

Chaque test prouve un comportement précis, nommé dans le test lui-même.
"""
from pathlib import Path

import pytest

from scanner.conditions import ConditionError, ConditionOutcome, evaluate_condition_tree
from scanner.graph.builder import GraphBuilder
from scanner.graph.context import ResourceContext
from scanner.graph.models import GraphEdge, GraphNode, INTERNET_NODE_ID, ResourceGraph
from scanner.rule_engine import RuleEngine
from scanner.schema import (
    CloudProvider,
    ComplianceStatus,
    NormalizedResource,
    RelationshipType,
    ResourceRelationship,
    Severity,
)

RULES_DIR = Path(__file__).resolve().parent.parent / "rules"


def _resource(resource_type="s3_bucket", attributes=None, tenant="tenant-a", env="production"):
    return NormalizedResource(
        resource_id="test-resource",
        resource_type=resource_type,
        cloud_provider=CloudProvider.AWS,
        tenant_id=tenant,
        region="eu-west-1",
        attributes=attributes or {},
        tags={"Environment": env},
    )


# ---------------------------------------------------------------------------
# Évaluation des conditions — les 3 états, sur des feuilles simples
# ---------------------------------------------------------------------------
def _ctx(resource):
    graph = ResourceGraph(tenant_id=resource.tenant_id)
    graph.add_node(GraphNode(id=resource.resource_id, resource_type=resource.resource_type,
                              tenant_id=resource.tenant_id))
    return ResourceContext(resource=resource, graph=graph)


def test_condition_matched_when_value_equals():
    cond = {"attribute": "encrypted", "operator": "equals", "value": False}
    result = evaluate_condition_tree(cond, _ctx(_resource(attributes={"encrypted": False})))
    assert result.outcome == ConditionOutcome.MATCHED


def test_condition_not_matched_when_value_differs():
    cond = {"attribute": "encrypted", "operator": "equals", "value": False}
    result = evaluate_condition_tree(cond, _ctx(_resource(attributes={"encrypted": True})))
    assert result.outcome == ConditionOutcome.NOT_MATCHED


def test_missing_attribute_is_indeterminate_not_compliant():
    """LE test de sécurité central : un attribut non collecté ne doit
    JAMAIS être silencieusement traité comme conforme."""
    cond = {"attribute": "encrypted", "operator": "equals", "value": False}
    result = evaluate_condition_tree(cond, _ctx(_resource(attributes={})))
    assert result.outcome == ConditionOutcome.INDETERMINATE


def test_none_attribute_is_also_indeterminate():
    cond = {"attribute": "encrypted", "operator": "equals", "value": False}
    result = evaluate_condition_tree(cond, _ctx(_resource(attributes={"encrypted": None})))
    assert result.outcome == ConditionOutcome.INDETERMINATE


def test_unsupported_operator_raises():
    cond = {"attribute": "x", "operator": "regex_match", "value": ".*"}
    with pytest.raises(ConditionError):
        evaluate_condition_tree(cond, _ctx(_resource(attributes={"x": "abc"})))


def test_contains_operator_on_non_iterable_does_not_crash():
    """Une règle mal écrite ne doit pas interrompre tout le scan."""
    cond = {"attribute": "flag", "operator": "contains", "value": "*"}
    result = evaluate_condition_tree(cond, _ctx(_resource(attributes={"flag": True})))
    assert result.outcome == ConditionOutcome.NOT_MATCHED


def test_greater_than_on_incomparable_types_does_not_crash():
    cond = {"attribute": "age", "operator": "greater_than", "value": 90}
    result = evaluate_condition_tree(cond, _ctx(_resource(attributes={"age": "not-a-number"})))
    assert result.outcome == ConditionOutcome.NOT_MATCHED


# ---------------------------------------------------------------------------
# AND / OR / NOT — logique à trois valeurs
# ---------------------------------------------------------------------------
def test_all_is_matched_only_if_every_leaf_matches():
    tree = {"all": [
        {"attribute": "a", "operator": "equals", "value": True},
        {"attribute": "b", "operator": "equals", "value": True},
    ]}
    ctx = _ctx(_resource(attributes={"a": True, "b": True}))
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.MATCHED


def test_all_is_not_matched_if_one_leaf_fails():
    tree = {"all": [
        {"attribute": "a", "operator": "equals", "value": True},
        {"attribute": "b", "operator": "equals", "value": True},
    ]}
    ctx = _ctx(_resource(attributes={"a": True, "b": False}))
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.NOT_MATCHED


def test_all_is_indeterminate_if_no_leaf_fails_but_one_is_unknown():
    tree = {"all": [
        {"attribute": "a", "operator": "equals", "value": True},
        {"attribute": "b", "operator": "equals", "value": True},
    ]}
    ctx = _ctx(_resource(attributes={"a": True}))  # b manquant
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.INDETERMINATE


def test_any_is_matched_if_at_least_one_leaf_matches():
    tree = {"any": [
        {"attribute": "a", "operator": "equals", "value": True},
        {"attribute": "b", "operator": "equals", "value": True},
    ]}
    ctx = _ctx(_resource(attributes={"a": False, "b": True}))
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.MATCHED


def test_any_prefers_matched_over_indeterminate():
    tree = {"any": [
        {"attribute": "a", "operator": "equals", "value": True},   # manquant -> indeterminate
        {"attribute": "b", "operator": "equals", "value": True},   # matched
    ]}
    ctx = _ctx(_resource(attributes={"b": True}))
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.MATCHED


def test_not_inverts_matched_and_not_matched():
    tree = {"not": {"attribute": "a", "operator": "equals", "value": True}}
    assert evaluate_condition_tree(tree, _ctx(_resource(attributes={"a": True}))).outcome == ConditionOutcome.NOT_MATCHED
    assert evaluate_condition_tree(tree, _ctx(_resource(attributes={"a": False}))).outcome == ConditionOutcome.MATCHED


def test_not_never_inverts_indeterminate():
    """Inverser une incertitude produirait une fausse certitude — interdit."""
    tree = {"not": {"attribute": "a", "operator": "equals", "value": True}}
    result = evaluate_condition_tree(tree, _ctx(_resource(attributes={})))
    assert result.outcome == ConditionOutcome.INDETERMINATE


def test_nested_all_within_any():
    tree = {"any": [
        {"all": [
            {"attribute": "a", "operator": "equals", "value": True},
            {"attribute": "b", "operator": "equals", "value": True},
        ]},
        {"attribute": "c", "operator": "equals", "value": True},
    ]}
    ctx = _ctx(_resource(attributes={"a": True, "b": True, "c": False}))
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.MATCHED


# ---------------------------------------------------------------------------
# Feuilles graphe (fonctions contextuelles enregistrées, pas d'eval())
# ---------------------------------------------------------------------------
def test_graph_leaf_unknown_function_raises():
    tree = {"source": "graph", "function": "delete_everything"}
    with pytest.raises(ConditionError):
        evaluate_condition_tree(tree, _ctx(_resource()))


def test_is_reachable_from_internet_true_when_path_exists():
    resource = _resource(attributes={})
    graph = ResourceGraph(tenant_id=resource.tenant_id)
    graph.add_node(GraphNode(id=INTERNET_NODE_ID, resource_type="internet", tenant_id=resource.tenant_id))
    graph.add_node(GraphNode(id=resource.resource_id, resource_type=resource.resource_type,
                              tenant_id=resource.tenant_id))
    graph.add_edge(GraphEdge(source_id=INTERNET_NODE_ID, target_id=resource.resource_id,
                              relationship_type=RelationshipType.CONNECTS_TO))
    ctx = ResourceContext(resource=resource, graph=graph)
    tree = {"source": "graph", "function": "is_reachable_from_internet"}
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.MATCHED


def test_is_reachable_from_internet_false_when_edge_blocked():
    resource = _resource(attributes={})
    graph = ResourceGraph(tenant_id=resource.tenant_id)
    graph.add_node(GraphNode(id=INTERNET_NODE_ID, resource_type="internet", tenant_id=resource.tenant_id))
    graph.add_node(GraphNode(id=resource.resource_id, resource_type=resource.resource_type,
                              tenant_id=resource.tenant_id))
    graph.add_edge(GraphEdge(source_id=INTERNET_NODE_ID, target_id=resource.resource_id,
                              relationship_type=RelationshipType.CONNECTS_TO, blocked=True))
    ctx = ResourceContext(resource=resource, graph=graph)
    tree = {"source": "graph", "function": "is_reachable_from_internet"}
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.NOT_MATCHED


def test_contextual_rule_combines_resource_and_graph_leaves():
    """La règle exemple du prompt : 'VM dangereuse si IP publique ET port
    22 accessible depuis Internet' — un AND entre une feuille resource et
    une feuille graph."""
    resource = _resource(resource_type="security_group", attributes={"ssh_open_to_world": True})
    graph = ResourceGraph(tenant_id=resource.tenant_id)
    graph.add_node(GraphNode(id=INTERNET_NODE_ID, resource_type="internet", tenant_id=resource.tenant_id))
    graph.add_node(GraphNode(id=resource.resource_id, resource_type=resource.resource_type,
                              tenant_id=resource.tenant_id))
    graph.add_edge(GraphEdge(source_id=INTERNET_NODE_ID, target_id=resource.resource_id,
                              relationship_type=RelationshipType.CONNECTS_TO))
    ctx = ResourceContext(resource=resource, graph=graph)
    tree = {"all": [
        {"attribute": "ssh_open_to_world", "operator": "equals", "value": True},
        {"source": "graph", "function": "is_reachable_from_internet"},
    ]}
    assert evaluate_condition_tree(tree, ctx).outcome == ConditionOutcome.MATCHED


# ---------------------------------------------------------------------------
# Chargement des règles
# ---------------------------------------------------------------------------
def test_rules_load_from_directory():
    engine = RuleEngine.from_directory(RULES_DIR)
    assert len(engine.rules) > 20, "les 5 fichiers YAML doivent fournir un jeu de règles conséquent"


def test_every_rule_has_a_framework_mapping():
    """Sans framework/control_id, le Finding serait rejeté par l'AI Service."""
    engine = RuleEngine.from_directory(RULES_DIR)
    for rule in engine.rules:
        assert rule.framework is not None
        assert rule.control_id


def test_no_duplicate_rule_ids_across_files():
    engine = RuleEngine.from_directory(RULES_DIR)
    ids = [r.rule_id for r in engine.rules]
    assert len(ids) == len(set(ids))


def test_missing_rules_directory_raises():
    with pytest.raises(FileNotFoundError):
        RuleEngine.from_directory("/nonexistent/rules")


# ---------------------------------------------------------------------------
# Production de findings
# ---------------------------------------------------------------------------
def test_public_bucket_produces_a_critical_violation():
    engine = RuleEngine.from_directory(RULES_DIR)
    resource = _resource(attributes={"public_access_blocked": False})
    findings = engine.evaluate_resource(resource, scan_id="scan-1")

    violation = next(f for f in findings if f.rule_id == "storage.s3_bucket_public_access")
    assert violation.status == ComplianceStatus.FAIL
    assert violation.severity == Severity.CRITICAL
    assert violation.evidence.actual_value is False


def test_compliant_bucket_produces_a_pass_finding():
    """Les succès sont émis : sans eux, aucun dénominateur pour la couverture."""
    engine = RuleEngine.from_directory(RULES_DIR)
    resource = _resource(attributes={"public_access_blocked": True})
    findings = engine.evaluate_resource(resource, scan_id="scan-1")

    passed = next(f for f in findings if f.rule_id == "storage.s3_bucket_public_access")
    assert passed.status == ComplianceStatus.PASS
    assert passed.risk.value == 0.0


def test_emit_passes_false_returns_violations_only():
    engine = RuleEngine.from_directory(RULES_DIR, emit_passes=False)
    resource = _resource(attributes={"public_access_blocked": True})
    findings = engine.evaluate_resource(resource, scan_id="scan-1")
    assert all(f.status == ComplianceStatus.FAIL for f in findings)


def test_indeterminate_finding_is_flagged_with_low_confidence_and_downgraded_severity():
    engine = RuleEngine.from_directory(RULES_DIR)
    resource = _resource(attributes={})  # rien n'a pu être collecté
    findings = engine.evaluate_resource(resource, scan_id="scan-1")

    indet = next(f for f in findings if f.rule_id == "storage.s3_bucket_public_access")
    assert indet.status == ComplianceStatus.FAIL          # signalé, pas ignoré
    assert indet.evidence.outcome == "indeterminate"
    assert indet.confidence.value < 50
    assert indet.severity == Severity.HIGH                # rétrogradé depuis CRITICAL


def test_indeterminate_ranks_below_a_confirmed_violation():
    engine = RuleEngine.from_directory(RULES_DIR)
    confirmed = engine.evaluate_resource(_resource(attributes={"public_access_blocked": False}), scan_id="scan-1")
    unknown = engine.evaluate_resource(_resource(attributes={}), scan_id="scan-1")

    c = next(f for f in confirmed if f.rule_id == "storage.s3_bucket_public_access")
    u = next(f for f in unknown if f.rule_id == "storage.s3_bucket_public_access")
    assert u.risk.value < c.risk.value


def test_rule_is_skipped_for_a_non_matching_resource_type():
    engine = RuleEngine.from_directory(RULES_DIR)
    findings = engine.evaluate_resource(
        _resource(resource_type="iam_user", attributes={"mfa_enabled": True}), scan_id="scan-1"
    )
    assert all(f.resource_type == "iam_user" for f in findings)
    assert not any(f.rule_id.startswith("storage.") for f in findings)


def test_production_scores_higher_than_sandbox():
    engine = RuleEngine.from_directory(RULES_DIR)
    prod = engine.evaluate_resource(
        _resource(attributes={"public_access_blocked": False}, env="production"), scan_id="scan-1"
    )
    sandbox = engine.evaluate_resource(
        _resource(attributes={"public_access_blocked": False}, env="sandbox"), scan_id="scan-1"
    )
    p = next(f for f in prod if f.rule_id == "storage.s3_bucket_public_access")
    s = next(f for f in sandbox if f.rule_id == "storage.s3_bucket_public_access")
    assert p.risk.value > s.risk.value


# ---------------------------------------------------------------------------
# Isolation multi-tenant
# ---------------------------------------------------------------------------
def test_resource_from_another_tenant_is_never_evaluated():
    """GARDE DE SÉCURITÉ : un bug de collecteur ne doit pas faire fuiter les
    findings d'un client vers un autre."""
    engine = RuleEngine.from_directory(RULES_DIR)
    resources = [
        _resource(attributes={"public_access_blocked": False}, tenant="tenant-a"),
        _resource(attributes={"public_access_blocked": False}, tenant="tenant-b"),
    ]
    findings = engine.evaluate_all(resources, scan_id="scan-1", tenant_id="tenant-a")
    assert findings
    assert all(f.tenant_id == "tenant-a" for f in findings)


def test_evaluate_all_without_tenant_guard_processes_everything():
    engine = RuleEngine.from_directory(RULES_DIR)
    resources = [
        _resource(attributes={"public_access_blocked": False}, tenant="tenant-a"),
        _resource(attributes={"public_access_blocked": False}, tenant="tenant-b"),
    ]
    findings = engine.evaluate_all(resources, scan_id="scan-1")
    assert {f.tenant_id for f in findings} == {"tenant-a", "tenant-b"}


# ---------------------------------------------------------------------------
# Cas AWS réalistes (issus du Terraform de test)
# ---------------------------------------------------------------------------
def test_non_compliant_cloudtrail_is_detected():
    """Reproduit la ressource `aws_cloudtrail.non_compliant` du Terraform."""
    engine = RuleEngine.from_directory(RULES_DIR)
    trail = NormalizedResource(
        resource_id="ciq-test-trail-non-compliant",
        resource_type="cloudtrail",
        cloud_provider=CloudProvider.AWS,
        tenant_id="tenant-a",
        attributes={
            "is_multi_region": False,
            "log_file_validation_enabled": False,
            "cloudwatch_logs_enabled": False,
            "log_bucket_encrypted": True,
        },
        tags={"Environment": "sandbox", "ComplianceStatus": "non-compliant"},
    )
    violations = [f for f in engine.evaluate_resource(trail, scan_id="scan-1") if f.is_violation]
    rule_ids = {f.rule_id for f in violations}
    assert "logging.cloudtrail_not_multi_region" in rule_ids
    assert "logging.cloudtrail_no_log_validation" in rule_ids


def test_compliant_cloudtrail_produces_no_violation():
    engine = RuleEngine.from_directory(RULES_DIR)
    trail = NormalizedResource(
        resource_id="ciq-compliant-trail",
        resource_type="cloudtrail",
        cloud_provider=CloudProvider.AWS,
        tenant_id="tenant-a",
        attributes={
            "is_multi_region": True,
            "log_file_validation_enabled": True,
            "cloudwatch_logs_enabled": True,
            "log_bucket_encrypted": True,
        },
        tags={"Environment": "production"},
    )
    violations = [f for f in engine.evaluate_resource(trail, scan_id="scan-1") if f.is_violation]
    assert violations == []


def test_open_ssh_security_group_is_critical():
    engine = RuleEngine.from_directory(RULES_DIR)
    sg = NormalizedResource(
        resource_id="sg-open-ssh",
        resource_type="security_group",
        cloud_provider=CloudProvider.AWS,
        tenant_id="tenant-a",
        attributes={
            "ssh_open_to_world": True,
            "rdp_open_to_world": False,
            "database_port_open_to_world": False,
            "any_port_open_to_world": False,
        },
        tags={"Environment": "production"},
    )
    violation = next(
        f for f in engine.evaluate_resource(sg, scan_id="scan-1") if f.rule_id == "network.ssh_open_to_world"
    )
    assert violation.severity == Severity.CRITICAL
    assert violation.status == ComplianceStatus.FAIL
