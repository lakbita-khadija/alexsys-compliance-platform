from pathlib import Path

from scanner.collectors.mock_collector import MockAwsCollector
from scanner.rule_engine import RuleEngine
from scanner.scan_service import ScanService
from scanner.schema import ComplianceStatus, Severity

RULES_DIR = Path(__file__).resolve().parent.parent / "rules"


def _service(with_errors=False, emit_passes=True):
    return ScanService(
        collectors=[MockAwsCollector(with_errors=with_errors)],
        rule_engine=RuleEngine.from_directory(RULES_DIR, emit_passes=emit_passes),
    )


def test_scan_produces_resources_and_findings():
    report = _service().run("tenant-a")
    assert len(report.resources) == 8
    assert report.findings
    assert report.violations


def test_compliant_cloudtrail_yields_no_violation_but_yields_passes():
    report = _service().run("tenant-a")
    trail_findings = [
        f for f in report.findings if f.resource_id == "ciq-sandbox-compliant-trail"
    ]
    assert trail_findings, "les succès doivent être émis pour permettre le calcul de couverture"
    assert all(f.status == ComplianceStatus.PASS for f in trail_findings)


def test_non_compliant_cloudtrail_is_flagged():
    report = _service().run("tenant-a")
    rule_ids = {
        f.rule_id
        for f in report.violations
        if f.resource_id == "ciq-sandbox-test-trail-non-compliant"
    }
    assert "logging.cloudtrail_not_multi_region" in rule_ids
    assert "logging.cloudtrail_no_log_validation" in rule_ids


def test_public_bucket_is_among_the_top_risks():
    report = _service().run("tenant-a")
    top_resources = {f.resource_id for f in report.top_findings(5)}
    assert "ciq-sandbox-public-bucket" in top_resources


def test_permission_denied_resource_produces_indeterminate_findings():
    """La ressource dont rien n'a pu être lu doit être signalée, pas ignorée."""
    report = _service().run("tenant-a")
    indet = [
        f
        for f in report.findings
        if f.resource_id == "ciq-sandbox-permission-denied"
        and f.evidence.outcome == "indeterminate"
    ]
    assert indet, "une ressource non lisible doit produire des findings indéterminés"
    assert all(f.confidence.value < 50 for f in indet)


def test_indeterminate_never_outranks_a_confirmed_critical():
    report = _service().run("tenant-a")
    top = report.top_findings(3)
    assert all(f.confidence.value > 50 for f in top), (
        "les findings incertains ne doivent pas occuper le haut de la file de priorisation"
    )


def test_partial_collection_failure_is_reported_but_data_is_kept():
    report = _service(with_errors=True).run("tenant-a")
    assert report.errors
    assert report.resources
    assert not report.is_complete
    assert report.errors[0].startswith("[mock-aws]")


def test_severity_breakdown_is_computed():
    report = _service().run("tenant-a")
    breakdown = report.by_severity()
    assert Severity.CRITICAL.value in breakdown
    assert sum(breakdown.values()) == len(report.violations)


def test_domain_breakdown_covers_multiple_domains():
    report = _service().run("tenant-a")
    domains = report.by_domain()
    assert len(domains) >= 3, "le scan doit couvrir plusieurs domaines transverses"


def test_compliance_rate_is_between_0_and_100():
    report = _service().run("tenant-a")
    assert 0.0 <= report.compliance_rate <= 100.0


def test_all_findings_carry_the_scanned_tenant():
    report = _service().run("tenant-a")
    assert all(f.tenant_id == "tenant-a" for f in report.findings)


def test_every_finding_has_a_framework_and_control():
    """Sans ces deux champs, le Finding serait rejeté par l'AI Service."""
    report = _service().run("tenant-a")
    for finding in report.findings:
        assert finding.framework is not None
        assert finding.control_id
