"""
scripts/demo_scan.py

Démonstration complète, hors-ligne : aucun compte AWS, aucun credential,
aucun réseau requis.

    python -m scripts.demo_scan
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from scanner.collectors.mock_collector import MockAwsCollector
from scanner.rule_engine import RuleEngine
from scanner.scan_service import ScanService

RULES_DIR = Path(__file__).resolve().parent.parent / "rules"


def main() -> None:
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")

    engine = RuleEngine.from_directory(RULES_DIR)
    service = ScanService(collectors=[MockAwsCollector()], rule_engine=engine)
    report = service.run("tenant-acme")

    print("=" * 78)
    print(f"  SCAN {report.scan_id[:8]}   tenant={report.tenant_id}")
    print("=" * 78)
    print(f"  règles chargées      : {len(engine.rules)}")
    print(f"  ressources scannées  : {len(report.resources)}")
    print(f"  contrôles évalués    : {len(report.findings)}")
    print(f"  violations           : {len(report.violations)}")
    print(f"  conformes            : {len(report.passed)}")
    print(f"  taux de conformité   : {report.compliance_rate} %")
    print(f"  scan complet         : {report.is_complete}")

    print("\n  RÉPARTITION PAR SÉVÉRITÉ")
    print("  " + "-" * 74)
    for severity in ("critical", "high", "medium", "low"):
        count = report.by_severity().get(severity, 0)
        bar = "█" * min(count, 40)
        print(f"  {severity:9} {count:3}  {bar}")

    print("\n  RÉPARTITION PAR DOMAINE")
    print("  " + "-" * 74)
    for domain, count in sorted(report.by_domain().items(), key=lambda x: -x[1]):
        print(f"  {domain:12} {count:3}")

    print("\n  TOP 8 DES RISQUES (score interne 0-100)")
    print("  " + "-" * 74)
    for f in report.top_findings(8):
        print(
            f"  [{f.severity.value.upper():8}] risque={f.risk.value:6.2f} "
            f"conf={f.confidence.value:5.1f}  {f.rule_id:45} {f.resource_id[:28]}"
        )

    indeterminate = [f for f in report.findings if f.evidence.outcome == "indeterminate"]
    if indeterminate:
        print(f"\n  ⚠ {len(indeterminate)} contrôle(s) INDÉTERMINÉ(S) — attributs non collectés")
        print("  " + "-" * 74)
        print("  Signalés plutôt qu'ignorés : un scanner aveugle ne doit jamais")
        print("  rapporter une posture saine par défaut.")
        for f in indeterminate[:3]:
            print(f"    - {f.resource_id}  ({f.rule_id})")

    print("\n  RESOURCE GRAPH")
    print("  " + "-" * 74)
    print(f"  nœuds={report.graph.node_count}  arêtes={report.graph.edge_count}")

    if report.attack_paths:
        print(f"\n  ATTACK PATHS DÉTECTÉS ({len(report.attack_paths)})")
        print("  " + "-" * 74)
        for ap in report.attack_paths:
            print(f"  [{ap.severity.upper():8}] score={ap.risk_score:5.1f}  "
                  f"{' -> '.join(n.replace('__internet__', 'INTERNET') for n in ap.nodes)}")
            print(f"             techniques: {', '.join(ap.attack_techniques)}")
            print(f"             {len(ap.contributing_finding_ids)} finding(s) contributeur(s)")
    else:
        print("\n  Aucun attack path détecté (rien d'exposé publiquement dans ce jeu de données)")

    enriched = [f for f in report.findings if f.related_attack_path_ids]
    if enriched:
        print(f"\n  {len(enriched)} finding(s) avec risque réévalué par l'Attack Path Engine")

    print("\n  DRIFT — comparaison avec un scan précédent où le SG SSH était bloqué")
    print("  " + "-" * 74)
    from scanner.drift.diff_engine import DiffEngine

    # Simule un scan PRÉCÉDENT où sg-ciq-open-ssh était encore sécurisé --
    # exactement le scénario S11 : le drift crée un nouveau chemin
    # d'attaque, détectable en comparant deux scans réels.
    previous_by_id = {r.resource_id: r for r in report.resources}
    if "sg-ciq-open-ssh" in previous_by_id:
        safe_sg = previous_by_id["sg-ciq-open-ssh"].model_copy(
            update={"attributes": {
                **previous_by_id["sg-ciq-open-ssh"].attributes,
                "ssh_open_to_world": False,
                "any_port_open_to_world": False,
            }}
        )
        previous_by_id["sg-ciq-open-ssh"] = safe_sg

    drift_events = DiffEngine.compare(
        previous=previous_by_id, current={r.resource_id: r for r in report.resources},
        previous_scan_id="scan-precedent", current_scan_id=report.scan_id,
        tenant_id="tenant-acme",
    )
    for d in drift_events:
        print(f"  [{d.severity.upper():6}] {d.drift_type.value}: {d.field} "
              f"{d.old_value!r} -> {d.new_value!r}")
    print("  -> ce type de drift, une fois persisté (phase dédiée), déclenche")
    print("     une ré-analyse Attack Path : le chemin détecté plus haut vers")
    print("     ciq-sandbox-db-public n'existait PAS avant cette régression.")

    print("\n  PAYLOAD TRANSMIS À L'AI SERVICE (format contrat DOCUMENTÉ — 11 champs)")
    print("  " + "-" * 74)
    top = report.top_findings(1)[0]
    contract = {
        "id": top.finding_id,
        "tenant_id": top.tenant_id,
        "resource_id": top.resource_id,
        "rule_id": top.rule_id,
        "framework": top.framework.value,
        "control_id": top.control_id,
        "domain": top.domain.value,
        "status": top.status.value,
        "severity": top.severity.value,
        "evidence": top.evidence.model_dump(mode="json"),
        "detected_at": top.detected_at.isoformat(),
    }
    print(json.dumps(contract, indent=2, ensure_ascii=False, default=str))
    print("\n  (risk / confidence restent INTERNES : les exposer ferait rejeter")
    print("   le payload par extra='forbid' côté AI Service)")

    print("\n  CHAMPS AJOUTÉS PAR LA REVUE, PAS ENCORE CONFIRMÉS CÔTÉ AI SERVICE")
    print("  " + "-" * 74)
    print(f"  scan_id={top.scan_id}  rule_version={top.rule_version}")
    print(f"  region={top.region}  environment={top.environment}")
    print("  ⚠ absents du contrat qu'elle documente aujourd'hui — à négocier")
    print("   avant de les considérer comme partie du contrat v1.")


if __name__ == "__main__":
    main()
