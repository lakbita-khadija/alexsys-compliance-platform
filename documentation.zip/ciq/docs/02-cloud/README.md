# 02 · Cloud

## AWS — PARTIALLY IMPLEMENTED

Voir `01-architecture/infrastructure.md` pour le détail complet
(`collectors/aws_collector.py`, S3/SecurityGroups/IAM Users collectés, RDS
non collecté — `MISSING COLLECTOR CAPABILITY` documenté dans le code
lui-même). Non exécuté contre `moto` ni un compte réel au moment de la
rédaction.

## Azure — NOT IMPLEMENTED

Aucun fichier `azure_collector.py` ni équivalent dans ce dépôt.

## Terraform — NOT PRESENT IN THIS REPOSITORY

`find . -iname "*.tf"` ne retourne aucun résultat dans ce dépôt. Du
Terraform de test (ressources AWS volontairement mal configurées) a été
mentionné dans des échanges antérieurs de ce projet — les noms de
ressources du `mock_collector.py` actuel (ex : `ciq-sandbox-cloudtrail-logs`,
`ciq-sandbox-test-trail-non-compliant`) en portent la trace conceptuelle,
mais **aucun fichier `.tf` n'est présent dans ce dépôt**. Ne pas documenter
son contenu comme existant ici.
