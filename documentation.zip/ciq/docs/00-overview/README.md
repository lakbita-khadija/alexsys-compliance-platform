# 00 · Vue d'ensemble

## 1. Résumé exécutif

Ce dépôt (`ciq/`) implémente un **pipeline CSPM déterministe complet et
testé** — découverte, normalisation, graphe de ressources, évaluation de
règles (y compris contextuelles), analyse de chemins d'attaque, détection
de dérive de posture — sans encore aucune couche de persistance, d'API ni
d'authentification. **35 fichiers Python, 90 tests écrits, 84 exécutés et
verts.**

## 2. Flux CURRENT (vérifié dans le code)

```
Cloud Credentials (session boto3 injectee)
   |
Collector (BaseCollector : Mock IMPLEMENTED, AWS PARTIAL, Azure NOT IMPLEMENTED)
   |
NormalizedResource (schema.py)
   |
ResourceGraph (graph/builder.py -- construit depuis les relations
   |            reellement collectees, jamais fabriquees)
   |
RuleEngine (rule_engine.py + conditions.py -- AND/OR/NOT, fonctions
   |         contextuelles sur le graphe)
   |
Finding (immuable, verse d'un scan_id/rule_version)
   |
   +-- AttackPathAnalyzer (attack_path/) -- avant l'enrichissement du risque
   |
   +-- RiskCalculator -- enrichi du facteur attack_path_involvement
   |
   +-- DiffEngine (drift/) -- SI un snapshot precedent est fourni manuellement
   |
ScanReport (en memoire uniquement -- NOT PERSISTED)
```

## 3. Flux TARGET (conceptuel, pas encore construit)

```
Cloud Credentials -> AWS/Azure -> Discovery -> Normalization
   -> NormalizedResource -> Resource Inventory -> Resource Graph
   -> YAML Policy Engine -> Rule Evaluation -> Raw Findings
   -> Risk + Confidence -> Compliance Finding
   -> Persistence [NOT IMPLEMENTED] -> FastAPI [NOT IMPLEMENTED]
   -> React Dashboard [NOT IMPLEMENTED] -> AI Compliance Assistant [dépôt séparé]
```

**Écart entre CURRENT et TARGET** : tout ce qui suit `Finding` dans le
schéma cible (persistance, API, dashboard) n'existe pas dans ce dépôt.
`Resource Inventory` en tant que concept formel (distinction
DISCOVERED/IN SCOPE/EVALUATED/PASSED/FAILED/UNSUPPORTED/PERMISSION_DENIED/
ERROR) **n'est pas non plus implémenté** — le `ScanReport` actuel distingue
seulement `violations`/`passed`, pas les 8 états visés (voir
`03-scanner/resource-inventory.md`).

## 4. Phases réelles (INFERENCE — aucun historique Git disponible)

Reconstruites à partir des dépendances effectives entre modules (un module
qui importe un autre a nécessairement été écrit après ou avec lui) :

| Phase (inférée) | Composants | Preuve de dépendance |
|---|---|---|
| A — Domaine de base | `schema.py`, `value_objects.py` | Base de tout le reste, aucune dépendance interne |
| B — Rule Engine | `conditions.py`, `rule_engine.py` | Importe `schema.py`/`value_objects.py` |
| C — Collecte | `collectors/base.py`, `mock_collector.py`, `aws_collector.py` | Importe `schema.py` |
| D — Orchestration | `scan_service.py` | Importe collectors + rule_engine |
| E — Resource Graph | `graph/models.py`, `builder.py`, `context.py` | Importe `schema.py` ; `conditions.py` importe `graph/context.py` (donc E précède/accompagne une révision de B) |
| F — Attack Path | `attack_path/*.py` (6 fichiers) | Importe `graph/`, `schema.py` |
| G — Drift Detection | `drift/*.py` (3 fichiers) | Importe `schema.py` uniquement, indépendant de F |
| H — Intégration finale | `scan_service.py` (révisé) | Importe Graph + AttackPath + Drift simultanément |

Cette reconstruction est **une inférence de dépendances de code**, pas une
chronologie confirmée — à traiter comme telle en soutenance si la question
est posée.

## 5. Composants NOT IMPLEMENTED dans ce dépôt (constat, pas un jugement)

Persistance (PostgreSQL), API (FastAPI), Authentification/RBAC, Frontend
(React), Assistant IA (dépôt séparé), Terraform (aucun fichier `.tf` dans
CE dépôt — référencé dans des échanges antérieurs du projet mais absent
ici), Docker/CI (aucun fichier trouvé).
