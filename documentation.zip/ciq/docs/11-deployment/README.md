# 11 · Deployment

## Statut : NOT IMPLEMENTED

`find . -iname "docker*"` → aucun résultat dans ce dépôt. Aucun
`Dockerfile`, `docker-compose.yml` ni pipeline CI/CD trouvé.
