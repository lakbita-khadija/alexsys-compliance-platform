# 04 · Compliance

| Sous-composant | Fichier | Statut |
|---|---|---|
| Policy Engine | `conditions.py`, `rule_engine.py` | IMPLEMENTED |
| YAML Rules (33 règles) | `rules/*.yaml` | IMPLEMENTED — voir [yaml-rules.md](yaml-rules.md) |
| Rule Evaluation | `rule_engine.py::RuleEngine` | IMPLEMENTED |
| Risk Scoring | `rule_engine.py::RiskCalculator` | IMPLEMENTED |
| Findings | `schema.py::Finding` | IMPLEMENTED |
| Framework Mapping / Coverage / Priority (Compliance Intelligence) | — | NOT IMPLEMENTED dans ce dépôt |
