# Findings

## Cycle de vie (CURRENT CODE)

```
NormalizedResource + Rule
   |
evaluate_condition_tree
   |
ConditionResult
   |
RiskCalculator.calculate (si FAIL/INDETERMINATE)
   |
Finding (frozen=True, extra="forbid")
   |
[ScanService._enrich_with_attack_path_involvement -- si implique dans un AttackPath]
   |
ScanReport.findings  -- NOT PERSISTED
```

## Champs réels (`schema.py::Finding`)

`finding_id`, `schema_version`, `tenant_id`, `scan_id`, `cloud_provider`,
`resource_id`, `resource_type`, `region`, `environment`, `rule_id`,
`rule_version`, `domain`, `severity`, `status`, `description`, `framework`,
`control_id`, `evidence`, `detected_at`, `risk`, `confidence`, `version`,
`superseded_by`, `related_drift_event_ids`, `related_attack_path_ids`.

**Immuable, versionné, traçable** : `frozen=True` (Pydantic) garantit
l'immuabilité au niveau objet ; `version`/`superseded_by` existent comme
champs mais **aucun mécanisme ne les fait évoluer** aujourd'hui (pas de
persistance, donc pas de "nouvelle version remplaçant l'ancienne" en
pratique) — la mécanique est posée, pas encore exercée.

## Contrat externe (11 champs, AI Service)

Voir le handoff d'intégration reçu de la coéquipière (mémorisé) :
`id, tenant_id, resource_id, rule_id, framework, control_id, domain,
status, severity, evidence, detected_at` — **confirmé identique** aux 11
champs déjà documentés dans les sessions précédentes de ce projet. Aucune
Anti-Corruption Layer n'existe encore dans ce dépôt pour projeter le
`Finding` riche interne vers ce sous-ensemble.
