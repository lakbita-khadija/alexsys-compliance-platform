# Rule Evaluation

## États possibles (CURRENT CODE)

| État | Déclencheur | Traitement |
|---|---|---|
| `MATCHED` | La condition est vraie | → Finding `status=fail` |
| `NOT_MATCHED` | La condition est fausse | → Finding `status=pass` (si `emit_passes=True`, défaut) |
| `INDETERMINATE` | Attribut/fonction non déterminable | → Finding `status=fail`, sévérité rétrogradée d'un cran (`Severity.downgrade()`), confiance 30% |

## Pourquoi émettre aussi les PASS

`RuleEngine.__init__(emit_passes: bool = True)`. Sans les succès, aucun
dénominateur pour un futur calcul de couverture (« combien de contrôles
évalués ? ») — documenté explicitement dans le docstring du module.

## Isolation tenant à l'évaluation

`evaluate_all(resources, scan_id, tenant_id=None, graph=None)` — une
ressource dont `tenant_id` diverge du paramètre est écartée avec un log
`logger.error`, jamais évaluée. Testé :
`test_resource_from_another_tenant_is_never_evaluated`,
`test_tenant_mismatch_is_reported_and_skipped` (dans `test_scan_service.py`).
