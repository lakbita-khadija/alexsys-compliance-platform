# Policy Engine

## 1. Overview

Évalue les règles YAML contre les `NormalizedResource`, produit des
`Finding`. **IMPLEMENTED**, sans `eval()`/`exec()` — vérifié explicitement :
`grep -rn "eval(\|exec(" scanner/` → aucun résultat dans tout le dépôt.

## 2. Flux réel

```
YAML (rules/*.yaml)
   |
yaml.safe_load (rule_engine.py::RuleEngine.from_directory)
   |
Validation Pydantic (Rule model, extra="forbid", doublons de rule_id rejetes)
   |
Rule (en memoire)
   |
Pour chaque (Rule, NormalizedResource) applicable (resource_type match) :
   |
evaluate_condition_tree(rule.condition, ResourceContext(resource, graph))
   |
ConditionResult(outcome, trace)  -- matched | not_matched | indeterminate
   |
Finding
```

## 3. AND / OR / NOT — implémenté, non encore utilisé par une règle réelle

Voir `yaml-rules.md` §"Capacité vs usage réel". Logique à trois valeurs
(Kleene), pas booléenne : `all` échoue dès qu'une feuille est
`not_matched`, sinon devient `indeterminate` si une feuille l'est ;
`not` d'un résultat `indeterminate` reste `indeterminate` (jamais inversé
en une fausse certitude) — vérifié par
`test_not_never_inverts_indeterminate`.

## 4. Fonctions contextuelles (registre fermé)

`CONTEXT_FUNCTIONS = {"is_publicly_exposed": ..., "is_reachable_from_internet":
..., "has_path_to": ...}` (`graph/context.py`). Une règle référençant une
fonction hors de cette liste lève `ConditionError` — testé
(`test_graph_leaf_unknown_function_raises`).

## 5. Sécurité — absence d'eval() confirmée

| THREAT | ATTACK | RISK | DEFENSE | IMPLEMENTATION | TEST |
|---|---|---|---|---|---|
| Exécution de code arbitraire via une règle malveillante | Une règle YAML contient une expression Python | Compromission du process scanner | `yaml.safe_load` + évaluateur fermé, jamais `eval()` | `rule_engine.py`, `conditions.py` | Vérification statique (`grep`), pas de test dynamique dédié — **GAP LOW** : un test explicite `test_no_eval_in_codebase` renforcerait la garantie en CI |

## 6. Testing

35 tests (`test_rule_engine.py`) + 18 tests dédiés aux conditions
(inclus dans le même fichier) : chargement, doublons, matched/not_matched/
indeterminate, AND/OR/NOT imbriqués, fonctions contextuelles, fail-safe.

## 7. Common Mistakes

**Sécurité** : ajouter un opérateur qui accepte une chaîne évaluée
dynamiquement (ex : un futur opérateur "regex" mal implémenté avec
`re.compile(user_input)` sans limite) — aucun opérateur actuel ne le fait,
à surveiller pour toute extension future.
