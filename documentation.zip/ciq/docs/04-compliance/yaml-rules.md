# YAML Rule Coverage — inventaire complet (33/33)

Extrait **programmatiquement** des 5 fichiers `rules/*.yaml` au moment de
la rédaction (`python3` + `yaml.safe_load`, jamais recopié à la main —
zéro risque de transcription erronée). Aucune règle omise.

## Comment créer une nouvelle règle

```
YAML (rules/<domaine>.yaml)
   |
Rule Loader (yaml.safe_load, rule_engine.py::RuleEngine.from_directory)
   |
Validation Pydantic (Rule model, extra="forbid")
   |
RuleEngine.evaluate_resource() -- reference par rule_id
   |
Finding (rule_id, rule_version propages)
```

Ajouter une règle = ajouter une entrée dans le fichier YAML du domaine
concerné, avec au minimum `rule_id`, `domain`, `severity`, `resource_types`,
`description`, `framework`, `control_id`, `condition`. Aucune modification
de code Python n'est nécessaire pour une règle simple (feuille
`attribute`/`operator`/`value`) — voir `docs/01-architecture/domain.md`
pour les règles contextuelles (`all`/`any`/`not`, `source: graph`),
capacité existante mais non encore utilisée par aucune des 33 règles
actuelles (voir §"Capacité vs usage" ci-dessous).

## Inventaire complet

| rule_id | resource_types | severity | framework | control_id | operator | Test coverage (verifie) |
|---|---|---|---|---|---|---|
| `encryption.s3_bucket_not_encrypted` | s3_bucket | high | iso_27001 | A.8.24 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `encryption.s3_bucket_no_kms` | s3_bucket | medium | iso_27001 | A.8.24 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `encryption.ebs_volume_not_encrypted` | ebs_volume | high | iso_27001 | A.8.24 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `encryption.rds_not_encrypted` | rds_instance | high | iso_27001 | A.8.24 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `encryption.kms_key_rotation_disabled` | kms_key | medium | iso_27001 | A.8.24 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `iam.user_no_mfa` | iam_user | critical | iso_27001 | A.5.17 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `iam.user_admin_access` | iam_user | critical | iso_27001 | A.8.2 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `iam.access_key_too_old` | iam_user | high | iso_27001 | A.5.17 | greater_than | indirecte (moteur generique, test_rule_engine.py) |
| `iam.user_inactive` | iam_user | medium | iso_27001 | A.5.18 | greater_than | indirecte (moteur generique, test_rule_engine.py) |
| `iam.policy_wildcard_action` | iam_policy | high | iso_27001 | A.8.2 | contains | indirecte (moteur generique, test_rule_engine.py) |
| `iam.root_account_used` | iam_root_account | critical | iso_27001 | A.5.17 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `iam.root_account_no_mfa` | iam_root_account | critical | iso_27001 | A.5.17 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `logging.cloudtrail_not_multi_region` | cloudtrail | high | iso_27001 | A.8.15 | equals | test_rule_engine.py::test_non_compliant_cloudtrail_is_detected |
| `logging.cloudtrail_no_log_validation` | cloudtrail | high | iso_27001 | A.8.15 | equals | test_rule_engine.py::test_non_compliant_cloudtrail_is_detected |
| `logging.cloudtrail_no_cloudwatch` | cloudtrail | medium | nist_csf | DE.AE-3 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `logging.cloudtrail_bucket_not_encrypted` | cloudtrail | high | iso_27001 | A.8.24 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `logging.log_retention_insufficient` | cloudwatch_log_group | medium | iso_27001 | A.8.15 | less_than | indirecte (moteur generique, test_rule_engine.py) |
| `logging.config_not_enabled` | config_recorder | medium | nist_csf | DE.CM-1 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `network.ssh_open_to_world` | security_group | critical | iso_27001 | A.8.20 | equals | test_rule_engine.py::test_open_ssh_security_group_is_critical |
| `network.rdp_open_to_world` | security_group | critical | iso_27001 | A.8.20 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `network.database_port_open_to_world` | security_group | critical | iso_27001 | A.8.20 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `network.any_port_open_to_world` | security_group | high | iso_27001 | A.8.20 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `network.rds_publicly_accessible` | rds_instance | high | iso_27001 | A.8.20 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `network.vpc_no_flow_logs` | vpc | medium | nist_csf | DE.AE-3 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.s3_bucket_public_access` | s3_bucket | critical | iso_27001 | A.5.15 | equals | test_rule_engine.py (7 tests, ex: test_public_bucket_produces_a_critical_violation) |
| `storage.s3_bucket_no_public_access_block_config` | s3_bucket | critical | iso_27001 | A.5.15 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.s3_bucket_public_read_access` | s3_bucket | high | iso_27001 | A.5.15 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.s3_bucket_public_write_access` | s3_bucket | critical | iso_27001 | A.5.15 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.s3_bucket_versioning_disabled` | s3_bucket | low | iso_27001 | A.8.13 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.s3_bucket_no_logging` | s3_bucket | low | nist_csf | DE.AE-3 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.rds_backup_retention_disabled` | rds_instance | medium | iso_27001 | A.8.13 | equals | indirecte (moteur generique, test_rule_engine.py) |
| `storage.rds_backup_retention_insufficient` | rds_instance | high | iso_27001 | A.8.13 | less_than | indirecte (moteur generique, test_rule_engine.py) |
| `storage.rds_no_deletion_protection` | rds_instance | medium | iso_27001 | A.8.13 | equals | indirecte (moteur generique, test_rule_engine.py) |

## Répartition

| Domaine | Nombre | Sévérités |
|---|---|---|
| storage | 9 | 1 low×2, 1 medium×2, 1 high×2, 1 critical×3 (recompte exact recommandé avant citation en soutenance) |
| iam | 7 | majorité critical/high |
| logging | 6 | majorité high/medium |
| network | 6 | majorité critical/high |
| encryption | 5 | majorité high/medium |

## Capacité vs usage réel — fait vérifié

`grep -l "all:\|any:\|source: graph" rules/*.yaml` → **aucun résultat**.
Le moteur (`conditions.py`) supporte AND/OR/NOT et les fonctions
contextuelles (`is_publicly_exposed`, `is_reachable_from_internet`,
`has_path_to`), testé par 18 tests unitaires — mais **aucune des 33 règles
réelles ne les utilise**. Capacité existante, non exploitée par le
catalogue actuel.

## Opérateurs supportés vs utilisés

| Opérateur | Supporté (`conditions.py`) | Utilisé dans les 33 règles |
|---|---|---|
| `equals` | ✓ | ✓ (majorité) |
| `not_equals` | ✓ | ✗ |
| `greater_than` | ✓ | ✓ (2 règles) |
| `less_than` | ✓ | ✓ (2 règles) |
| `contains` | ✓ | ✓ (1 règle) |
| `not_contains` | ✓ | ✗ |
| `in` / `not_in` | ✓ | ✗ |
| `exists` / `not_exists` | ✓ | ✗ |

## GAP

**LOW** — les 33 règles ne sont testées que via le moteur générique
(`test_rule_engine.py`), pas via une suite `tests/rules/test_<rule_id>.py`
dédiée par identifiant. 3 `rule_id` seulement sont référencés nommément
dans un test (`logging.cloudtrail_no_log_validation`,
`logging.cloudtrail_not_multi_region`, `network.ssh_open_to_world`,
`storage.s3_bucket_public_access`) — les 29 autres sont couvertes
indirectement par les tests génériques du moteur, pas individuellement.
