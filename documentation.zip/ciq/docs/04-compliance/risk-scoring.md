# Risk Scoring

## Formule réelle (CURRENT CODE, `rule_engine.py::RiskCalculator`)

```
score = 100 * ( 0.40 * severity_factor
              + 0.25 * exposure_factor
              + 0.10 * environment_factor
              + 0.10 * confidence
              + 0.15 * attack_path_involvement )

si confidence < 0.5 :
    score *= (confidence + 0.2)      # amortissement des findings incertains

score = min(round(score, 2), 100.0)
```

- `severity_factor = rule.severity.weight / 4.0` (`low`=1 → 0.25,
  `critical`=4 → 1.0)
- `exposure_factor = 1.0` si `public_access_blocked is False` ou
  `public_read_access is True`, sinon `0.3`
- `environment_factor = 1.0` si `environment == "production"`, sinon `0.5`
- `attack_path_involvement` ∈ {0.0, 1.0} — peuplé **après coup** par
  `ScanService._enrich_with_attack_path_involvement`, pas au moment du
  calcul initial (voir `05-security-analysis/attack-paths.md`)

`model_version = "crsf-1.1"` — versionné explicitement, chaque `RiskScore`
porte sa version de formule (reproductibilité). `"1.1"` marque l'ajout du
facteur `attack_path_involvement` par rapport à `"1.0"` (commentaire
explicite dans le code).

## Confidence

`CONFIDENCE_CONFIRMED = 0.95`, `CONFIDENCE_INDETERMINATE = 0.30` — deux
constantes fixes, pas un calcul continu.

## GAP

**LOW** — les poids (0.40/0.25/0.10/0.10/0.15) sont un point de départ
documenté comme "défendable, pas une vérité scientifique" mais ne
proviennent d'aucune calibration empirique — à assumer explicitement en
soutenance plutôt qu'à défendre comme optimal.
