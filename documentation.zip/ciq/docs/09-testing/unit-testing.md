# Unit Testing

## Ce que chaque suite protège (pas seulement "quels tests existent")

| Suite | Comportement protégé |
|---|---|
| `test_rule_engine.py` (35) | 3 états d'évaluation, AND/OR/NOT, fonctions contextuelles, chargement YAML (doublons rejetés), rétrocompatibilité des règles simples |
| `test_value_objects.py` (9) | Bornes de `RiskScore`/`ConfidenceScore`, cohérence `Evidence.indeterminate_reason`, rejet des champs inconnus (`extra="forbid"`) |
| `test_graph.py` (7) | Isolation tenant au niveau domaine, absence de nœud fantôme, cycles sans boucle infinie |
| `test_attack_path.py` (9) | Non-shortest-path (privilège fait scorer plus haut), chemin bloqué = score 0, profondeur maximale |
| `test_drift.py` (12) | Canonicalisation (champs volatils exclus), direction du changement de posture |

Aucun mock utilisé dans ces suites — le domaine ne dépend d'aucune
infrastructure, donc rien à mocker (voir `01-architecture/dependency-rules.md`).
