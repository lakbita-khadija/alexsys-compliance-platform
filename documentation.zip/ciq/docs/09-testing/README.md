# 09 · Testing

## Matrice de couverture (comptage exact, recompté à la rédaction)

| Fichier | Tests | Type | Statut |
|---|---|---|---|
| `test_rule_engine.py` | 35 | Unit (domaine) | ✓ verts |
| `test_scan_service.py` | 12 | Integration (pipeline complet, en mémoire) | ✓ verts |
| `test_drift.py` | 12 | Unit (domaine) | ✓ verts |
| `test_value_objects.py` | 9 | Unit (domaine) | ✓ verts |
| `test_attack_path.py` | 9 | Unit (domaine) | ✓ verts |
| `test_graph.py` | 7 | Unit (domaine) + sécurité (isolation tenant) | ✓ verts |
| `test_aws_collector_moto.py` | 6 | Integration (AWS simulé) | ✗ non exécuté |
| **Total** | **90** | | **84/90 exécutés et verts** |

Voir `09-testing/unit-testing.md`, `integration-testing.md`,
`rule-coverage.md` pour le détail.
