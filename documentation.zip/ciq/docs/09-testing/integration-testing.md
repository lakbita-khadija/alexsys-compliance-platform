# Integration Testing

## `test_scan_service.py` (12 tests) — le seul niveau d'intégration exécuté

Exerce le pipeline complet en mémoire : `MockAwsCollector` →
`RuleEngine` → `GraphBuilder` → `AttackPathAnalyzer` → enrichissement du
risque. Aucune base de données, aucun réseau — c'est une intégration
"interne au process", pas une intégration système.

## `test_aws_collector_moto.py` (6 tests) — NON EXÉCUTÉ

Écrit pour simuler AWS en mémoire via `moto` (aucun compte réel requis).
**Jamais exécuté** — `moto`/`boto3` absents de l'environnement où le code
a été écrit. Premier test à lancer pour transformer "écrit" en "prouvé" :

```bash
pip install moto boto3
pytest tests/test_aws_collector_moto.py -v
```

## Ce qui n'existe pas encore

Aucun test contre un vrai PostgreSQL (pas de persistance), aucun test API
(pas de FastAPI), aucun test contre l'AI Service réel (contrat non
vérifié contre son code, seulement contre le handoff reçu).
