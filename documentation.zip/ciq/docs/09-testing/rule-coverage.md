# Rule Coverage

Voir `04-compliance/yaml-rules.md` pour la colonne "Test coverage" par
`rule_id`, extraite programmatiquement.

## Résumé

- 4 `rule_id` référencés nommément dans un test
- 29 `rule_id` couverts uniquement indirectement via le moteur générique
  (`test_rule_engine.py` construit des ressources synthétiques et vérifie
  le comportement du moteur, pas règle par règle)

## GAP

**LOW** — pas de suite `tests/rules/test_<rule_id>.py` dédiée. Le moteur
lui-même est solidement testé (35 tests) ; c'est la couverture par règle
individuelle qui reste indirecte.
