# 08 · AI

## Statut : NOT IMPLEMENTED dans ce dépôt

L'assistant IA / RAG appartient à un dépôt séparé (AI Service, développé
par une autre personne de l'équipe). Frontière documentée dans
`04-compliance/findings.md` (contrat des 11 champs) et dans le handoff
d'intégration mémorisé (endpoints `/ai/enrich`, `/ai/map`, `/ai/correlate`,
`/ai/financial`, `/ai/remediate`, `/ai/ask`, `/ai/report`). Aucun concept
de ce domaine (`ProviderName`, `TaskClass`, RAG, LLM Gateway) ne doit être
introduit dans ce dépôt.
