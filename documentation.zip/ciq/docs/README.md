# ComplianceIQ — Documentation d'ingénierie

Documentation vivante du **dépôt réel** (`ciq/`, le Core Scanner). Générée
par reconnaissance directe du code — aucun composant n'est documenté sans
avoir été vérifié dans le code source au moment de la rédaction.

> **Politique de vérité** : le code est autoritaire pour l'implémentation
> actuelle. Les tests sont autoritaires pour le comportement vérifié. En cas
> de désaccord entre une documentation antérieure et le code, le code
> l'emporte, et l'écart est signalé explicitement — jamais réconcilié en
> silence.
>
> **Aucun historique Git n'existe dans ce dépôt** (`git log` → *not a git
> repository*). Toute notion de "phase" dans ce document est donc une
> **INFERENCE** reconstruite à partir des dépendances du code, jamais un
> fait historique constaté.

## Sommaire

| Section | Contenu | Statut du composant documenté |
|---|---|---|
| [00 · Vue d'ensemble](00-overview/README.md) | Résumé exécutif, flux actuel vs cible | — |
| [01 · Architecture](01-architecture/README.md) | Domain/Application/Infrastructure, règles de dépendance | IMPLEMENTED |
| [02 · Cloud](02-cloud/README.md) | AWS, Azure, Terraform | PARTIAL / NOT IMPLEMENTED |
| [03 · Scanner](03-scanner/README.md) | Discovery, Normalization, Resource Graph | IMPLEMENTED |
| [04 · Compliance](04-compliance/README.md) | Policy Engine, 33 règles YAML, Risk, Findings | IMPLEMENTED |
| [05 · Security Analysis](05-security-analysis/README.md) | Drift Detection, Attack Paths | IMPLEMENTED |
| [06 · Backend](06-backend/README.md) | FastAPI | NOT IMPLEMENTED |
| [07 · Frontend](07-frontend/README.md) | Dashboard React | NOT IMPLEMENTED |
| [08 · AI](08-ai/README.md) | Assistant IA / RAG | NOT IMPLEMENTED (dans ce dépôt) |
| [09 · Testing](09-testing/README.md) | 90 tests, 84 exécutés | IMPLEMENTED |
| [10 · Security](10-security/README.md) | Modèle de menace, contrôles | PARTIAL |
| [11 · Deployment](11-deployment/README.md) | Local, environnements, production | NOT IMPLEMENTED |
| [12 · Study Guides](12-study-guides/) | Un guide par phase inférée | — |
| [13 · Decisions](13-decisions/architecture-decisions.md) | ADR | — |

## Statut global des composants (vérifié par inspection directe)

| Composant | Planned | Partial | Implemented | Tested | Integrated |
|---|---|---|---|---|---|
| Domain (Finding, NormalizedResource, Rule) | | | ✓ | ✓ | ✓ |
| Value Objects (Evidence, RiskScore, ConfidenceScore) | | | ✓ | ✓ | ✓ |
| Condition Evaluator (AND/OR/NOT) | | | ✓ | ✓ | ✓ (jamais utilisé par une règle réelle) |
| Rule Engine | | | ✓ | ✓ | ✓ |
| Resource Graph | | | ✓ | ✓ | ✓ |
| Attack Path Engine | | | ✓ | ✓ | ✓ |
| Drift Detection | | | ✓ | ✓ | partiel (comparaison en mémoire uniquement) |
| Collecteur Mock | | | ✓ | ✓ | ✓ |
| Collecteur AWS réel | | ✓ | ✓ | non exécuté | non |
| Collecteur Azure | ✓ | | | | |
| Persistance PostgreSQL | ✓ | | | | |
| API FastAPI | ✓ | | | | |
| Authentification / RBAC | ✓ | | | | |
| Terraform (dans CE dépôt) | | | | | absent — référencé dans des sessions antérieures du projet, aucun fichier `.tf` présent ici |
| Frontend React | ✓ | | | | |
| AI/RAG (dans CE dépôt) | | | | | absent — appartient au dépôt séparé de l'AI Service |
