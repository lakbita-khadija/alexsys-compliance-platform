# Phase E (inférée) — Resource Graph

Voir `03-scanner/resource-graph.md` pour le traitement complet (déjà au
format des 22 sections). Résumé pour révision rapide :
- Isolation tenant vérifiée au niveau du domaine lui-même
- Aucune relation fabriquée : cible hors périmètre = arête abandonnée
- Nœud `__internet__` créé uniquement s'il existe une exposition réelle
