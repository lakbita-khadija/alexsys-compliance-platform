# Phase F (inférée) — Attack Path

Voir `05-security-analysis/attack-paths.md` pour le traitement complet.
Point clé à savoir défendre : ce n'est pas un shortest-path — un chemin
plus long mais traversant une identité privilégiée peut scorer plus haut
qu'un chemin plus court sans privilège (`test_path_involving_privileged_
identity_scores_higher`).
