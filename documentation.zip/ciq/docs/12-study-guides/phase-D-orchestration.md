# Phase D (inférée) — Orchestration

**Niveau 1** : `scan_service.py::ScanService.run()`.
**Niveau 2** : assembler collecte, graphe, règles, attack path, risque et
drift en un seul appel cohérent.
**Niveau 3** : orchestration séquentielle stricte, chaque étape utilisant
la sortie de la précédente.
**Niveau 4** : 12 tests d'intégration (`test_scan_service.py`).
**Niveau 5** : la séquence Graph→Findings→AttackPath→Risk est justifiée
explicitement dans le docstring du module, pas arbitraire.
**Niveau 6** : un échec de collecte partiel ne doit jamais interrompre le
scan entier — vérifié.
**Niveau 7** : `test_partial_collection_failure_is_reported_but_data_is_kept`.
**Niveau 8** : demanderait pourquoi ce n'est pas encore un "Use Case"
formel dans une couche `application/` dédiée — réponse dans
`01-architecture/application.md`.
