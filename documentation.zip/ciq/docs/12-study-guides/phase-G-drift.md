# Phase G (inférée) — Drift Detection

Voir `05-security-analysis/drift-detection.md` pour le traitement complet.
Point clé : la canonicalisation n'exclut QUE ce qui est prouvé volatil
(`collected_at`), jamais un champ métier par supposition.
