# Phase C (inférée) — Collecte

**Niveau 1** : `collectors/base.py`, `mock_collector.py`, `aws_collector.py`.
**Niveau 2** : produire des `NormalizedResource` à partir de vraies
ressources cloud, sans coupler le domaine à un SDK.
**Niveau 3** : `BaseCollector.collect(tenant_id) -> CollectionResult`,
injection de session (`boto3.Session`).
**Niveau 4** : Mock exécuté et testé ; AWS écrit, non exécuté.
**Niveau 5** : injection de dépendance plutôt que construction interne du
client cloud — testable sans credentials réels (`moto`).
**Niveau 6** : absence de pagination dans les appels AWS actuels — GAP
identifié dans `03-scanner/discovery.md`.
**Niveau 7** : `test_aws_collector_moto.py`, non exécuté.
**Niveau 8** : demanderait de démontrer la tolérance aux pannes partielles
en coupant l'accès à un seul service AWS pendant la démo.
