# Phase B (inférée) — Rule Engine

**Niveau 1** : `conditions.py` (évaluateur), `rule_engine.py` (orchestration).
**Niveau 2** : évaluer des règles de sécurité déclaratives sans jamais
exécuter de code arbitraire.
**Niveau 3** : YAML → Pydantic → arbre de conditions récursif (AND/OR/NOT,
logique à 3 états) → Finding.
**Niveau 4** : 35 tests, 33 règles réelles chargées avec succès.
**Niveau 5** : la logique à 3 états (pas booléenne) empêche qu'un attribut
non collecté devienne silencieusement "conforme" — décision de sécurité,
pas seulement de conception.
**Niveau 6** : un opérateur non enregistré ou une fonction contextuelle
inconnue lève une exception explicite plutôt que d'échouer silencieusement.
**Niveau 7** : `test_rule_engine.py`, 35 tests.
**Niveau 8** : demanderait pourquoi `Rule.condition` est un `dict[str, Any]`
plutôt qu'un modèle Pydantic récursif typé — réponse : éviter les limites
de résolution récursive/union d'un typage strict, au prix d'une validation
de forme faite à l'exécution plutôt qu'au chargement.
