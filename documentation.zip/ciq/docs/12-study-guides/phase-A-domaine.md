# Phase A (inférée) — Domaine de base

**Niveau 1 — Quoi** : `NormalizedResource`, `Rule`, `Finding`, `Evidence`,
`RiskScore`, `ConfidenceScore`. Le socle sur lequel tout le reste s'appuie.

**Niveau 2 — Pourquoi** : sans un modèle canonique unique, chaque
composant suivant (moteur de règles, graphe, attack path) aurait dû
définir sa propre notion de "ressource" ou de "finding" — source de
duplication et d'incohérence.

**Niveau 3 — Comment ça marche** : Pydantic v2, `frozen=True`,
`extra="forbid"` — immuabilité et rejet strict des champs inconnus dès la
frontière.

**Niveau 4 — Implémentation ComplianceIQ** : `schema.py` (211 lignes),
`value_objects.py` (107 lignes).

**Niveau 5 — Pourquoi cette architecture** : aligner le format exact sur
le contrat attendu par l'AI Service (11 champs Finding) réduit le travail
de traduction ultérieur — même si une divergence existe encore côté
`NormalizedResource` (voir `04-compliance/findings.md`).

**Niveau 6 — Ce qui peut casser** : un champ ajouté sans mettre à jour le
contrat externe ferait rejeter le payload (`extra="forbid"` côté AI
Service).

**Niveau 7 — Comment c'est testé** : 9 tests dédiés (`test_value_objects.py`).

**Niveau 8 — Revue senior** : demanderait pourquoi `TenantId`/`FindingId`
ne sont pas des Value Objects typés (aujourd'hui des `str` nus) — décision
ouverte, documentée dans les blueprints de sessions antérieures.
