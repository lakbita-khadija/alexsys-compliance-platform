# Phase H (inférée) — Intégration finale

**Niveau 1** : `scan_service.py` révisé pour appeler Graph + AttackPath +
Drift dans la même exécution.
**Niveau 2** : sans cette intégration, chaque capacité resterait une
démonstration isolée, pas un produit cohérent.
**Niveau 3** : `_enrich_with_attack_path_involvement` recalcule le
`RiskScore` d'un `Finding` déjà construit via `model_copy(update=...)` —
un `Finding` immuable enrichi produit une NOUVELLE instance, jamais une
mutation.
**Niveau 4** : `scripts/demo_scan.py` démontre la chaîne complète,
hors-ligne, exécutable en une commande.
**Niveau 5** : garder `Finding` immuable même pendant l'enrichissement
préserve la garantie d'auditabilité posée dès la Phase A.
**Niveau 6** : un bug trouvé en exécutant cette intégration (pas en
relisant) : `AttackPathAnalyzer` référençait `finding.id` au lieu de
`finding.finding_id` — corrigé après que 12 tests aient échoué.
**Niveau 7** : `test_scan_service.py` (12 tests) couvre cette intégration
de bout en bout.
**Niveau 8** : demanderait de reproduire la démo en direct et d'expliquer
chaque étape de la sortie affichée.
