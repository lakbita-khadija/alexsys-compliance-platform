# 07 · Frontend

## Statut : NOT IMPLEMENTED

`find . -iname "*.jsx" -o -iname "*.tsx" -o -iname "package.json"` → aucun
résultat. Aucun dashboard React n'existe dans ce dépôt.
