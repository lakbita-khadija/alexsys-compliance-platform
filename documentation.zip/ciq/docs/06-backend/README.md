# 06 · Backend

## Statut : NOT IMPLEMENTED

Aucune trace de FastAPI dans ce dépôt (`grep -rln "fastapi" scanner/` →
aucun résultat). Conçu dans les blueprints de sessions antérieures de ce
projet (endpoints `/api/v1/scans`, `/findings`, `/frameworks`,
authentification JWT — le Core Service serait responsable de l'émission
du JWT d'après le handoff d'intégration reçu de l'AI Service), mais aucune
ligne de code n'existe ici.
