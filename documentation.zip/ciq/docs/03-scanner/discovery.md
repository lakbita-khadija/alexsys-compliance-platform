# Discovery

## 1. Overview

La découverte collecte les ressources cloud brutes et produit des
`NormalizedResource`. Trois collecteurs implémentent `BaseCollector`
(`collectors/base.py`) : `MockAwsCollector` (IMPLEMENTED), `AwsCollector`
(PARTIAL), Azure (NOT IMPLEMENTED).

## 2. AWS — flux réel

```
boto3.Session (injectee)
   |
AwsCollector.collect(tenant_id)
   |
_collect_s3 / _collect_security_groups / _collect_iam_users
   (chaque appel isole via _safe() -- un echec n'empeche pas les autres)
   |
CollectionResult(resources, errors)
```

Pas de pagination explicite trouvée dans le code actuel (`list_buckets`,
`describe_security_groups`, `list_users` appelés sans gestion de
`NextToken`/`Marker`) — **limite non documentée ailleurs, à signaler** :
sur un compte avec plus de ressources qu'une page API, certaines seraient
silencieusement omises. **GAP HIGH** — voir `13-decisions/`.

## 3. Azure — NOT IMPLEMENTED

Aucun code.

## 4. Tolérance aux pannes partielles

`CollectionResult.merge()` — une erreur sur un service (ex : IAM
inaccessible) n'empêche pas la collecte des autres (S3, Security Groups).
Vérifié : `AwsCollector.collect()` itère sur les 3 méthodes de collecte
dans un `try/except` individuel par méthode.

## 5. Testing

`MockAwsCollector` : couvert par tous les tests du pipeline complet.
`AwsCollector` : `tests/test_aws_collector_moto.py`, **NON EXÉCUTÉ**
(dépendances absentes de l'environnement de rédaction).

## 6. Common Mistakes

**Technique** : supposer que `_safe()` retournant `None` signifie "la
ressource n'a pas cet attribut" — en réalité ça signifie "on n'a pas pu le
vérifier", ce qui déclenche le chemin `INDETERMINATE` du Rule Engine, pas
une valeur par défaut.
