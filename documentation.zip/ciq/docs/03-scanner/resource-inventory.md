# Resource Inventory

## Statut : NOT IMPLEMENTED (modèle formel)

Le concept CSPM classique distingue 8 états : `DISCOVERED`, `IN_SCOPE`,
`EVALUATED`, `PASSED`, `FAILED`, `UNSUPPORTED`, `PERMISSION_DENIED`,
`ERROR`. **Aucun de ces états n'est modélisé explicitement dans ce dépôt.**

## Ce qui existe réellement à la place

`ScanReport` (`scan_service.py`) distingue seulement :
- `resources` (tout ce qui a été collecté = `DISCOVERED`)
- `findings` (tout ce qui a été évalué)
- `violations` (`status=fail`) / `passed` (`status=pass`)
- `errors` (liste de chaînes de log, pas structurée par ressource)

Pas de distinction entre `UNSUPPORTED` (aucune règle ne s'applique à ce
type de ressource) et `PERMISSION_DENIED` (la collecte a échoué sur cette
ressource précise) — les deux finissent aujourd'hui dans des catégories
différentes et peu comparables (`UNSUPPORTED` n'apparaît nulle part
explicitement ; `PERMISSION_DENIED` se traduit par une entrée dans
`errors`, une simple chaîne de texte).

## GAP

**MEDIUM** — sans ce modèle formel, un futur widget de dashboard "taux de
couverture" (ressources évaluées / ressources découvertes) ne peut pas être
construit correctement : le calcul serait trompeur sans distinguer
`UNSUPPORTED` de `PERMISSION_DENIED` de `EVALUATED`.
