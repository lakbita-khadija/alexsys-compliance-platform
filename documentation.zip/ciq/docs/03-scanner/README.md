# 03 · Scanner

Pipeline : Discovery → Normalization → Resource Inventory (concept partiel)
→ Resource Graph. Tous les composants de cette section sont **IMPLEMENTED**
sauf `resource-inventory.md`, dont le modèle formel à 8 états n'existe pas
encore.

| Sous-composant | Fichier(s) | Statut |
|---|---|---|
| Discovery | `collectors/*.py` | IMPLEMENTED (Mock), PARTIAL (AWS), NOT IMPLEMENTED (Azure) |
| Normalization | `schema.py::NormalizedResource` | IMPLEMENTED |
| Resource Inventory (formel) | — | NOT IMPLEMENTED |
| Resource Graph | `graph/*.py` | IMPLEMENTED, testé (7 tests dédiés) |
