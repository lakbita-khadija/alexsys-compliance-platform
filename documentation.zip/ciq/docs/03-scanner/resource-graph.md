# Resource Graph

## 1. Overview

Le Resource Graph modélise les relations entre ressources cloud
(`sg -> ALLOWS -> rds`, `internet -> CONNECTS_TO -> sg`, etc.) pour
permettre l'évaluation de règles contextuelles et l'analyse de chemins
d'attaque. **IMPLEMENTED, 7 tests dédiés, tous verts.**

## 2. Scope

### Responsable de
Construire un graphe en mémoire à partir des relations réellement
collectées, garantir l'isolation multi-tenant à la construction.

### NOT responsable de
Persister le graphe (NOT IMPLEMENTED), le mettre à jour incrémentalement
entre deux scans (chaque scan reconstruit le graphe entièrement).

## 3. Architecture Position

```mermaid
flowchart LR
    NR[NormalizedResource.relationships] --> GB[GraphBuilder.build]
    GB --> RG[ResourceGraph]
    RG --> RC[ResourceContext]
    RC --> CF[CONTEXT_FUNCTIONS]
    CF --> CE[conditions.py]
    RG --> APA[AttackPathAnalyzer]
```

## 4. Project Structure (réelle)

```text
graph/
├── models.py     -- GraphNode, GraphEdge, ResourceGraph, ResourceGraphPort
├── builder.py      -- GraphBuilder.build()
└── context.py        -- ResourceContext, CONTEXT_FUNCTIONS
```

## 5. Core Concepts

**GraphNode** — WHAT : un nœud identifié (`id`, `resource_type`,
`tenant_id`, `properties`). WHY : représenter une ressource ou le point
d'entrée conceptuel `__internet__`. HOW : `dataclass(frozen=True)`. HOW
UTILISÉ : `properties["attributes"]` porte une copie des attributs de la
ressource, consultée par l'Attack Path Engine sans re-fetch.

**GraphEdge** — WHAT : une relation dirigée avec un booléen `blocked`. WHY :
distinguer "relation techniquement présente" de "relation exploitable".
HOW : `blocked` vient de `relationship.properties.get("blocked", False)`.

**Nœud `__internet__`** — créé uniquement s'il existe au moins une relation
`PUBLICLY_EXPOSED` dans le jeu de ressources du scan — jamais fabriqué par
défaut (vérifié : `test_no_internet_node_when_nothing_is_publicly_exposed`).

## 6. Implementation — extrait réel

```python
def add_node(self, node: GraphNode) -> None:
    if node.tenant_id != self.tenant_id:
        raise ValueError(
            f"Node {node.id} appartient au tenant {node.tenant_id}, "
            f"pas au graphe du tenant {self.tenant_id} -- isolation violee"
        )
    self._nodes[node.id] = node
```

## 7. Code Walkthrough

`GraphBuilder.build(resources, tenant_id)` : (1) détecte s'il existe une
exposition publique, (2) ajoute tous les nœuds, (3) pour chaque relation
`PUBLICLY_EXPOSED`, crée une arête `__internet__ -> ressource` ; pour toute
autre relation dont la cible est réellement dans le scan, crée l'arête
correspondante ; **si la cible n'est pas dans le scan, l'arête est
abandonnée silencieusement** — jamais de nœud fantôme créé.

## 8. Data Flow

```
NormalizedResource[] --> GraphBuilder.build --> ResourceGraph
   --> (RuleEngine via ResourceContext) --> Finding[]
   --> (AttackPathAnalyzer) --> AttackPath[]
```

## 9. Interfaces & Contracts

`ResourceGraphPort` (`models.py`) — interface de persistance, **NOT
IMPLEMENTED** (aucun adaptateur concret aujourd'hui, le graphe ne vit qu'en
mémoire pour la durée d'un scan).

## 10. Dependencies

Interne uniquement : `scanner.schema` (`NormalizedResource`,
`RelationshipType`). Aucune dépendance externe.

## 11. Error Handling

`add_node`/`add_edge` lèvent `ValueError` sur violation d'isolation tenant
ou référence à un nœud inexistant — jamais un échec silencieux.

## 12. Security

| THREAT | ATTACK | RISK | DEFENSE | IMPLEMENTATION | TEST |
|---|---|---|---|---|---|
| Fuite inter-tenant via le graphe | Un bug de collecteur mélange des ressources de deux tenants | Isolation compromise | Validation à la construction du nœud | `ResourceGraph.add_node` | `test_adding_node_from_another_tenant_raises` |
| Nœud fantôme fabriqué | Une relation mal formée référence une cible inexistante | Faux positif d'exposition | Abandon silencieux de l'arête, jamais de création de nœud | `GraphBuilder.build` | `test_relationship_to_uncollected_target_is_dropped_not_fabricated` |

## 13. Testing

7 tests (`tests/test_graph.py`) : construction depuis relations réelles,
absence de nœud Internet sans exposition, cible hors périmètre ignorée,
cycles sans boucle infinie, arête bloquée exclue par défaut, isolation
tenant, arête vers nœud inexistant rejetée.

## 14. Common Mistakes

**Technique** : oublier `include_blocked=True` en voulant inspecter TOUTES
les relations (par défaut, `neighbors()` exclut les arêtes bloquées).
**Architecturale** : vouloir persister le graphe avant que les tables
relationnelles PostgreSQL n'existent (`ResourceGraphPort` reste sans
adaptateur).
**Sécurité** : construire un nœud sans validation tenant en contournant
`add_node` (ex : accès direct à `_nodes`) — l'attribut est privé par
convention Python, pas par verrou technique.

## 15. Architecture Decisions

Voir `13-decisions/architecture-decisions.md` : "Pas de Neo4j au
démarrage".

## 16. Study Questions

**Débutant** : qu'est-ce qu'un nœud `__internet__` et pourquoi n'existe-t-il
pas toujours ?
**Intermédiaire** : pourquoi `add_edge` valide-t-il l'existence des deux
nœuds avant de créer l'arête ?
**Senior** : quelle serait la complexité d'une traversée sur ce graphe si
le nombre de ressources par tenant atteignait 10 000, et à partir de quel
volume PostgreSQL relationnel deviendrait-il insuffisant ?
**Jury** : pourquoi ce graphe est-il reconstruit à chaque scan plutôt que
mis à jour incrémentalement ?

## 17. Connections

```
Normalization (precedent) -> RESOURCE GRAPH -> Policy Engine contextuel
                                              -> Attack Path Engine (suivant)
```
