# Normalization

## 1. Overview

Transforme une ressource brute d'un fournisseur en `NormalizedResource`
(`schema.py`), un modèle unique et provider-agnostique.

## 2. Champs réels (CURRENT CODE)

```python
class NormalizedResource(BaseModel):
    resource_id: str
    resource_type: str
    cloud_provider: CloudProvider          # aws | azure | gcp
    tenant_id: str
    region: str = "unknown"
    attributes: dict[str, Any] = {}         # libre, propre au provider
    tags: dict[str, str] = {}
    relationships: list[ResourceRelationship] = []
    collected_at: datetime
```

`environment` est une **propriété calculée**, pas un champ stocké — dérivée
des tags (`Environment`/`environment`/`env`/`Env`), retourne `"unknown"`
par défaut, **jamais** `"production"` par supposition optimiste (principe
explicite dans le docstring du code).

## 3. Garanties de normalisation

- `attributes` reste un dict libre : les particularités provider-spécifiques
  n'y sont jamais perdues, mais jamais non plus forcées dans un schéma trop
  rigide.
- `resource_type` sert de filtre provider-agnostique pour les règles (ex :
  `s3_bucket` et un futur `blob_container` pourraient tous deux être
  normalisés en un type canonique commun — **NOT IMPLEMENTED**, chaque
  `resource_type` actuel reste littéralement le nom AWS, pas un type
  canonique abstrait).

## 4. GAP identifié

**MEDIUM** — `resource_type` n'est aujourd'hui PAS un type canonique
véritablement provider-agnostique (`s3_bucket` reste un nom AWS). Une
future ressource Azure Blob équivalente devrait porter le même
`resource_type` pour que les règles YAML actuelles s'appliquent sans
modification — ce mapping sémantique n'existe pas encore.
