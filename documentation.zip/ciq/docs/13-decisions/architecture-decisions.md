# Architecture Decision Records

## ADR-001 — Trois états d'évaluation, pas booléen

**Contexte** : un attribut cloud peut être inconnu (permission refusée,
appel API en échec), pas seulement vrai/faux.
**Problème** : un modèle booléen traiterait "on ne sait pas" comme "c'est
conforme" par défaut.
**Décision** : `ConditionOutcome` à 3 valeurs (`matched`/`not_matched`/
`indeterminate`), propagées à travers AND/OR/NOT en logique de Kleene.
**Conséquences** : un `Finding` `INDETERMINATE` est émis en `FAIL` avec
confiance rétrogradée plutôt que silencieusement ignoré.
**Statut** : Accepté, implémenté, testé (18 tests).

## ADR-002 — `Rule.condition` en dict brut, pas un modèle Pydantic récursif

**Contexte** : supporter AND/OR/NOT imbriqués avec des feuilles de deux
natures (resource / graph).
**Options** : (a) modèle Pydantic récursif avec Union polymorphe, (b) dict
brut validé à l'exécution par un évaluateur récursif pur Python.
**Décision** : (b).
**Raison** : évite la complexité (et la fragilité) d'une résolution de
type récursive/polymorphe, au prix d'une validation de forme différée à
l'évaluation plutôt qu'au chargement.
**Statut** : Accepté, implémenté.

## ADR-003 — Pas de Neo4j au démarrage

**Contexte** : le Resource Graph a besoin de traversées bornées.
**Décision** : PostgreSQL relationnel (futur) plutôt que Neo4j dès le
départ.
**Raison** : le volume actuel (dizaines de nœuds par tenant) ne justifie
pas une base spécialisée ; `ResourceGraphPort` (interface déjà posée)
permettrait un remplacement sans toucher au domaine si le volume
l'exigeait un jour, mesuré et non supposé.
**Statut** : Accepté, `ResourceGraphPort` existe, aucune implémentation
concrète encore (persistance absente).

## ADR-004 — Attack Path avant Risk Engine dans la séquence

**Contexte** : où insérer l'analyse Attack Path dans le pipeline ?
**Décision** : Graph → Findings → Attack Path → Risk (enrichi).
**Raison** : `RiskScore.factors["attack_path_involvement"]` ne peut être
peuplé qu'après que les chemins d'attaque soient connus — l'inverse
obligerait un second passage complet.
**Statut** : Accepté, implémenté (`scan_service.py`), documenté dans le
docstring du module.

## ADR-005 — Injection de la session cloud, jamais de construction interne

**Contexte** : `AwsCollector` a besoin d'un client `boto3`.
**Décision** : reçoit une `boto3.Session` déjà construite en paramètre.
**Raison** : testabilité (`moto`), séparation domaine/infrastructure, pas
de credential géré par le collecteur lui-même.
**Statut** : Accepté, implémenté, vérifié par grep (aucun `import boto3`
direct nulle part).

## ADR-006 — `MockAwsCollector` comme citoyen de première classe

**Contexte** : comment développer/démontrer sans compte cloud ni réseau ?
**Décision** : un collecteur mock complet, fixtures réalistes calquées sur
un Terraform de test (référencé, pas présent dans ce dépôt).
**Raison** : miroir du choix de l'AI Service (provider `fake` par défaut,
d'après le handoff d'intégration) — cohérence entre les deux services.
**Statut** : Accepté, implémenté, utilisé par tous les tests d'intégration.
