# Attack Paths

## 1. Overview

Identifie des chemins exploitables entre une exposition (`__internet__`)
et une ressource sensible, en traversant le Resource Graph.
**IMPLEMENTED**, 9 tests dédiés, **PAS un simple plus court chemin**
(vérifié : le score dépend du privilège traversé et de la sensibilité de
la cible, pas uniquement de la longueur du chemin — voir
`test_path_involving_privileged_identity_scores_higher`).

## 2. Flux réel

```
ResourceGraph
   |
PathDiscovery.discover(graph, "__internet__", sensitive_target_ids,
                        max_depth=6, max_paths_per_target=5)
   -- DFS borne, PAS shortest-path
   |
PathConstraintEvaluator.evaluate(candidate, graph)
   -- is_blocked, exposure_factor, privilege_factor, target_sensitivity
   |
AttackPathScorer.score(feasibility)   -- 0 si is_blocked
   |
AttackTechniqueMapper.map_techniques(feasibility, graph)
   |
AttackPath (contributing_finding_ids lies aux findings FAIL sur le chemin)
```

## 3. Cibles sensibles et identités privilégiées (CURRENT CODE)

`SENSITIVE_RESOURCE_TYPES = {"rds_instance", "s3_bucket"}` —
`attack_path/constraints.py` — heuristique fixe, documentée comme telle.

`PRIVILEGE_ATTRIBUTES = {"has_admin_access": True}` — un seul attribut,
car c'est le seul réellement collecté (`iam_user.has_admin_access`).

## 4. Scoring (formule réelle, `AttackPathScorer`)

```
score = 100 * ( 0.35 * exposure_factor
              + 0.30 * privilege_factor
              + 0.25 * target_sensitivity
              + 0.10 * depth_factor )

si is_blocked : score = 0.0   -- jamais compte comme exploitable
```

`ALGORITHM_VERSION = "1.0"`, `graph_version` — un chemin historique reste
interprétable même si l'algorithme change.

## 5. Findings contributeurs — heuristique documentée comme limite

Un `Finding` en `FAIL` sur un nœud du chemin est considéré "contributeur"
— **sur-attribution documentée explicitement dans le code** (docstring de
`AttackPathAnalyzer.analyze`) : un finding "backup retention" sur une RDS
apparaît comme contributeur d'un chemin d'exploitation SSH, sans lien
causal réel. Affiner exigerait une catégorisation des règles par vecteur
d'accès — hors périmètre actuel, assumé.

## 6. Sécurité

| THREAT | ATTACK | RISK | DEFENSE | IMPLEMENTATION | TEST |
|---|---|---|---|---|---|
| Faux chemin d'attaque exploitable annoncé | Une arête bloquée par un contrôle de sécurité est comptée comme exploitable | Alerte trompeuse, perte de confiance dans l'outil | Score 0 systématique si `is_blocked` | `AttackPathScorer.score` | `test_blocked_path_produces_no_attack_path` |
| Explosion combinatoire | Graphe dense, traversée non bornée | Déni de service / lenteur | `max_depth`, `max_paths_per_target` | `PathDiscovery` | `test_max_depth_prunes_paths_beyond_the_limit` |

## 7. Testing

9 tests : chemin public→DB, multi-sauts (LB→app→DB), chemin bloqué,
chemins multiples, graphe cyclique (sans boucle infinie), profondeur
maximale respectée, identité privilégiée fait scorer plus haut, aucun
chemin sans exposition, lien bidirectionnel finding↔chemin.

## 8. GAP

**MEDIUM** — sur-attribution des `contributing_finding_ids`, documentée en
§5, non corrigée.
