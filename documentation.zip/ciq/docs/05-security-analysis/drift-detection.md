# Drift Detection

## 1. Overview

Compare deux snapshots de ressources pour détecter un changement de
posture. **IMPLEMENTED**, comparaison **en mémoire uniquement** — pas de
baseline persistée.

## 2. Flux réel

```
previous: dict[resource_id, NormalizedResource]     (fourni manuellement)
current: dict[resource_id, NormalizedResource]
   |
canonicalize() sur chaque ressource            -- drift/canonicalization.py
   |
DiffEngine.compare()                              -- drift/diff_engine.py
   |
DriftEvent[]  -- classes en 4 types
```

**Baseline** : contrairement au schéma cible (`Baseline → Previous Scan →
Current Scan`), il n'existe **aucune notion de baseline persistée** — le
"previous" est un paramètre explicite de `ScanService.run()`, fourni par
l'appelant (démontré manuellement dans `scripts/demo_scan.py`, jamais
automatiquement depuis un historique).

## 3. Canonicalisation — champs exclus, justifiés un par un

| Champ exclu | Justification vérifiée dans le code |
|---|---|
| `collected_at` | Change à chaque scan par construction (`default_factory=lambda: datetime.now(...)`) — volatile par nature, pas une supposition |
| Ordre des `tags` | Un dict Python n'a pas d'ordre sémantique — trié avant comparaison |

**Aucun champ de `attributes` n'est exclu par défaut** — contrairement à
`collected_at`, rien dans le code ne prouve qu'un attribut cloud précis
est volatil ; en exclure un sans preuve serait une supposition non
vérifiée (principe explicite du docstring de `canonicalization.py`).

## 4. Classification (4 types, CURRENT CODE)

| Type | Déclencheur |
|---|---|
| `RESOURCE_LIFECYCLE_DRIFT` | Ressource apparue/disparue entre les deux snapshots |
| `SECURITY_POSTURE_DRIFT` | Un champ de `SECURITY_POSTURE_FIELDS` a changé |
| `RELATIONSHIP_DRIFT` | Les relations canonicalisées diffèrent |
| `CONFIGURATION_DRIFT` | Tout autre changement d'attribut |

`SECURITY_POSTURE_FIELDS` (15 champs, `diff_engine.py`) mappe chaque
attribut à sa valeur sûre — **vérifié champ par champ contre `rules/*.yaml`
au moment de la rédaction** : chaque clé y est bien l'`attribute` d'au
moins une condition existante (ex : `public_access_blocked`,
`ssh_open_to_world`, `mfa_enabled`).

## 5. Sévérité — direction du changement

```python
became_unsafe = old_val == safe_value and new_val != safe_value
severity = "high" if became_unsafe else "low"
```

Une dégradation de posture = `HIGH`. Une amélioration = `LOW`. Testé dans
les deux sens (`test_security_posture_drift_public_access_becomes_true`,
`test_security_posture_improving_is_low_severity_not_high`).

## 6. Sécurité

| THREAT | ATTACK | RISK | DEFENSE | IMPLEMENTATION | TEST |
|---|---|---|---|---|---|
| Faux positifs de drift noyant les vraies alertes | Comparaison JSON brute sensible à l'ordre/aux métadonnées | Alerte fatigue, vraie régression manquée | Canonicalisation avant comparaison | `canonicalization.py` | `test_collected_at_alone_never_produces_drift`, `test_tag_order_alone_never_produces_drift` |

## 7. Testing

12 tests (`test_drift.py`) : pas de changement, `collected_at` seul,
ordre des tags, dégradation HIGH, amélioration LOW, drift de config, drift
de relation, création, suppression, champ ajouté/retiré, isolation tenant.

## 8. GAP

**HIGH** — aucune persistance de baseline : le Drift Detection ne peut pas
fonctionner automatiquement entre deux VRAIS scans historiques aujourd'hui,
seulement via un couple de snapshots fourni manuellement en paramètre.

## 9. Connections

```
Normalization -> [snapshot precedent fourni manuellement] -> DRIFT DETECTION
   -> DriftEvent[] -> (lien conceptuel vers Attack Path re-analysis,
                        demontre manuellement, PAS automatise)
```
