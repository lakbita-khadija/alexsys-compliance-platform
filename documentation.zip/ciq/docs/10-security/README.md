# 10 · Security

Voir `threat-model.md` (menaces couvertes par le code actuel, format
THREAT→ATTACK→RISK→DEFENSE→IMPLEMENTATION→TEST) et `security-controls.md`
(contrôles NOT IMPLEMENTED, car aucune authentification/persistance
n'existe encore).
