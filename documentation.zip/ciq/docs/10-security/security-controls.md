# Security Controls

| Contrôle | Statut |
|---|---|
| Validation d'entrée (Pydantic, `extra="forbid"`) | IMPLEMENTED |
| Absence d'`eval()`/`exec()` | IMPLEMENTED (vérifié par grep) |
| Isolation tenant (domaine) | IMPLEMENTED, testé |
| Isolation tenant (repository/API/RLS) | NOT IMPLEMENTED |
| Authentification (JWT) | NOT IMPLEMENTED |
| RBAC | NOT IMPLEMENTED |
| Rédaction des secrets (Anti-Corruption Layer) | NOT IMPLEMENTED |
| Gestion des credentials cloud (AssumeRole+ExternalId) | NOT IMPLEMENTED (session injectée manuellement aujourd'hui) |
| Logs structurés / audit trail | NOT IMPLEMENTED |
| Scan de dépendances / `gitleaks` | NOT IMPLEMENTED |
