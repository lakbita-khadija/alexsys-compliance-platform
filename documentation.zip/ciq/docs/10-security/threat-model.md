# Threat Model

Consolidation des menaces déjà documentées section par section, plus
celles propres à l'absence de couches non encore implémentées.

## Menaces couvertes par le code actuel

| THREAT | ATTACK | RISK | DEFENSE | IMPLEMENTATION | TEST |
|---|---|---|---|---|---|
| Exécution de code arbitraire via une règle | YAML contenant une expression Python | Compromission du process | `yaml.safe_load`, évaluateur fermé | `conditions.py`, `rule_engine.py` | Vérification statique uniquement (`grep`) |
| Fuite inter-tenant (graphe) | Bug de collecteur mélangeant deux tenants | Isolation compromise | Validation à la construction du nœud | `graph/models.py` | `test_adding_node_from_another_tenant_raises` |
| Fuite inter-tenant (évaluation) | Ressource d'un autre tenant dans le lot évalué | Isolation compromise | Garde explicite dans `evaluate_all` | `rule_engine.py` | `test_resource_from_another_tenant_is_never_evaluated` |
| Faux chemin d'attaque exploitable | Arête bloquée comptée comme exploitable | Alerte trompeuse | Score 0 si `is_blocked` | `attack_path/scorer.py` | `test_blocked_path_produces_no_attack_path` |
| Explosion combinatoire (traversée) | Graphe dense sans borne | Déni de service | `max_depth`, `max_paths_per_target` | `attack_path/discovery.py` | `test_max_depth_prunes_paths_beyond_the_limit` |
| Faux positifs de drift | Comparaison JSON brute | Alerte fatigue | Canonicalisation | `drift/canonicalization.py` | `test_collected_at_alone_never_produces_drift` |
| Conformité silencieuse sur donnée manquante | Attribut non collecté traité comme "pass" | Faux négatif de sécurité | 3 états, `INDETERMINATE` explicite | `conditions.py` | `test_missing_attribute_is_indeterminate_not_compliant` |

## Menaces NON couvertes — absence de couche (NOT IMPLEMENTED)

| THREAT | Pourquoi non couvert aujourd'hui |
|---|---|
| Vol de credentials cloud permanents | Aucune persistance n'existe — mais aucun mécanisme d'injection sécurisée (AssumeRole+ExternalId) n'est non plus implémenté encore, seulement conçu |
| Falsification de `tenant_id` via une requête HTTP | Aucune API n'existe — le risque n'est pas encore matérialisé mais devra être traité dès la Phase 6/7 |
| Fuite de secrets dans `evidence` | Aucune Anti-Corruption Layer n'existe pour rédiger les secrets avant projection externe — **GAP HIGH** si une configuration cloud collectée contenait un secret (ex: variable d'environnement Lambda) |
| Injection SQL | Aucune base de données n'existe encore |

## GAP prioritaire

**HIGH** — l'absence d'Anti-Corruption Layer avec rédaction des secrets
est le seul gap de sécurité qui concerne du code déjà écrit
(`AwsCollector` collecte des `attributes` bruts qui pourraient un jour
inclure des données sensibles si le périmètre de collecte s'étend), pas
seulement une couche future absente.
