from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class DriftType(str, Enum):
    CONFIGURATION_DRIFT = "configuration_drift"
    SECURITY_POSTURE_DRIFT = "security_posture_drift"
    RESOURCE_LIFECYCLE_DRIFT = "resource_lifecycle_drift"
    RELATIONSHIP_DRIFT = "relationship_drift"


@dataclass(frozen=True, slots=True)
class DriftEvent:
    id: str
    tenant_id: str
    resource_id: str
    previous_scan_id: str
    current_scan_id: str
    field: str
    old_value: object
    new_value: object
    drift_type: DriftType
    severity: str
    detected_at: datetime
    related_rule_id: str | None = None
