"""
scanner/drift/diff_engine.py

DiffEngine -- compare deux snapshots (dict resource_id -> NormalizedResource)
deja canonicalises, et classe chaque changement (S9) :

  RESOURCE_LIFECYCLE_DRIFT  : ressource creee ou supprimee
  SECURITY_POSTURE_DRIFT    : un attribut de securite connu a change,
                              severite HIGH si la posture s'est degradee
  RELATIONSHIP_DRIFT        : une relation a ete ajoutee/retiree
  CONFIGURATION_DRIFT       : tout autre changement d'attribut

SECURITY_POSTURE_FIELDS documente, pour chaque attribut de securite
REELLEMENT lu par au moins une regle YAML existante, quelle valeur est
consideree sure -- ce mapping est verifiable en confrontant les cles a
rules/*.yaml, pas invente.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from scanner.drift.canonicalization import canonicalize
from scanner.drift.models import DriftEvent, DriftType
from scanner.schema import NormalizedResource

# attribut -> valeur considérée sûre. Vérifié contre rules/*.yaml : chacune
# de ces clés est l'`attribute` d'au moins une condition existante.
SECURITY_POSTURE_FIELDS: dict[str, object] = {
    "public_access_blocked": True,
    "public_read_access": False,
    "public_write_access": False,
    "encrypted": True,
    "kms_encrypted": True,
    "mfa_enabled": True,
    "has_admin_access": False,
    "ssh_open_to_world": False,
    "rdp_open_to_world": False,
    "database_port_open_to_world": False,
    "any_port_open_to_world": False,
    "publicly_accessible": False,
    "storage_encrypted": True,
    "is_multi_region": True,
    "log_file_validation_enabled": True,
}


class DiffEngine:
    @staticmethod
    def compare(
        previous: dict[str, NormalizedResource],
        current: dict[str, NormalizedResource],
        previous_scan_id: str,
        current_scan_id: str,
        tenant_id: str,
    ) -> list[DriftEvent]:
        events: list[DriftEvent] = []
        now = datetime.now(timezone.utc)

        for resource_id in current.keys() - previous.keys():
            events.append(
                DriftEvent(
                    id=str(uuid.uuid4()), tenant_id=tenant_id, resource_id=resource_id,
                    previous_scan_id=previous_scan_id, current_scan_id=current_scan_id,
                    field="__resource__", old_value=None, new_value="created",
                    drift_type=DriftType.RESOURCE_LIFECYCLE_DRIFT, severity="medium",
                    detected_at=now,
                )
            )

        for resource_id in previous.keys() - current.keys():
            events.append(
                DriftEvent(
                    id=str(uuid.uuid4()), tenant_id=tenant_id, resource_id=resource_id,
                    previous_scan_id=previous_scan_id, current_scan_id=current_scan_id,
                    field="__resource__", old_value="existed", new_value="deleted",
                    drift_type=DriftType.RESOURCE_LIFECYCLE_DRIFT, severity="medium",
                    detected_at=now,
                )
            )

        for resource_id in previous.keys() & current.keys():
            old_canon = canonicalize(previous[resource_id])
            new_canon = canonicalize(current[resource_id])

            old_attrs, new_attrs = old_canon["attributes"], new_canon["attributes"]
            for key in old_attrs.keys() | new_attrs.keys():
                old_val, new_val = old_attrs.get(key), new_attrs.get(key)
                if old_val == new_val:
                    continue
                events.append(DiffEngine._build_attribute_event(
                    resource_id, key, old_val, new_val, tenant_id,
                    previous_scan_id, current_scan_id, now,
                ))

            if old_canon["relationships"] != new_canon["relationships"]:
                events.append(
                    DriftEvent(
                        id=str(uuid.uuid4()), tenant_id=tenant_id, resource_id=resource_id,
                        previous_scan_id=previous_scan_id, current_scan_id=current_scan_id,
                        field="relationships",
                        old_value=old_canon["relationships"], new_value=new_canon["relationships"],
                        drift_type=DriftType.RELATIONSHIP_DRIFT, severity="medium",
                        detected_at=now,
                    )
                )

        return events

    @staticmethod
    def _build_attribute_event(
        resource_id, field, old_val, new_val, tenant_id,
        previous_scan_id, current_scan_id, now,
    ) -> DriftEvent:
        if field in SECURITY_POSTURE_FIELDS:
            safe_value = SECURITY_POSTURE_FIELDS[field]
            became_unsafe = old_val == safe_value and new_val != safe_value
            severity = "high" if became_unsafe else "low"
            return DriftEvent(
                id=str(uuid.uuid4()), tenant_id=tenant_id, resource_id=resource_id,
                previous_scan_id=previous_scan_id, current_scan_id=current_scan_id,
                field=f"attributes.{field}", old_value=old_val, new_value=new_val,
                drift_type=DriftType.SECURITY_POSTURE_DRIFT, severity=severity,
                detected_at=now,
            )
        return DriftEvent(
            id=str(uuid.uuid4()), tenant_id=tenant_id, resource_id=resource_id,
            previous_scan_id=previous_scan_id, current_scan_id=current_scan_id,
            field=f"attributes.{field}", old_value=old_val, new_value=new_val,
            drift_type=DriftType.CONFIGURATION_DRIFT, severity="low",
            detected_at=now,
        )
