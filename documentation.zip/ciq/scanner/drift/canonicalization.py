"""
scanner/drift/canonicalization.py

Canonicalise une NormalizedResource avant comparaison, pour eviter les faux
positifs de drift (S8, exigence explicite : PAS un old_json != new_json).

CHAMPS EXCLUS -- justifies un par un, pas supposes :
  collected_at : horodatage de LA COLLECTE, change a chaque scan par
                 construction meme si rien n'a change sur la ressource
                 (verifie dans scanner/schema.py : default_factory=now()).
  tags (ordre)  : un dict Python n'a pas d'ordre semantique ; on compare
                 apres tri par cle pour ignorer un simple changement
                 d'ordre de retour d'API cloud.

AUCUN champ de `attributes` n'est exclu par defaut : contrairement a
`collected_at`, rien dans le code actuel ne prouve qu'un attribut cloud
specifique est volatil. Exclure un champ sans preuve serait fabriquer une
hypothese -- voir l'avertissement explicite du cahier des charges.
"""

from __future__ import annotations

from typing import Any

from scanner.schema import NormalizedResource


def canonicalize(resource: NormalizedResource) -> dict[str, Any]:
    return {
        "resource_id": resource.resource_id,
        "resource_type": resource.resource_type,
        "cloud_provider": resource.cloud_provider.value,
        "region": resource.region,
        "attributes": dict(sorted(resource.attributes.items())),
        "tags": dict(sorted(resource.tags.items())),
        "relationships": sorted(
            (
                (r.relationship_type.value, r.target_resource_id)
                for r in resource.relationships
            )
        ),
    }
