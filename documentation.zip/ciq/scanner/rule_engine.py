"""
scanner/rule_engine.py

Rule Engine — transforme des NormalizedResource en Finding, selon des règles
déclaratives chargées depuis rules/*.yaml.

PRINCIPE DE SÉCURITÉ : les conditions ne sont JAMAIS évaluées avec eval().
L'évaluation elle-même est déléguée à scanner/conditions.py (AND/OR/NOT,
feuilles resource/graph, logique à trois valeurs) — ce fichier reste
responsable de l'orchestration (chargement des règles, construction des
Finding), pas de l'évaluation des conditions elle-même.

RÉTROCOMPATIBILITÉ : les 33 règles YAML existantes utilisent la forme plate
{attribute, operator, value} sous la clé `condition` — c'est exactement une
feuille de l'évaluateur récursif, donc AUCUNE d'entre elles n'a besoin
d'être réécrite pour ce refactor.

TROIS CHOIX DE CONCEPTION (déjà actés, inchangés par ce refactor) :
1. Attribut manquant = INDÉTERMINÉ, jamais silencieusement conforme.
2. Le moteur produit aussi les succès (status=pass), sinon aucun
   dénominateur pour calculer une couverture.
3. Amortissement du risque par la confiance : un finding incertain ne doit
   pas côtoyer une violation confirmée en tête de file.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Sequence

import yaml
from pydantic import BaseModel, ConfigDict

from scanner.conditions import ConditionError, ConditionOutcome, evaluate_condition_tree
from scanner.graph.context import ResourceContext
from scanner.graph.models import ResourceGraph
from scanner.schema import (
    ComplianceStatus,
    Domain,
    Finding,
    Framework,
    NormalizedResource,
    Severity,
)
from scanner.value_objects import ConfidenceScore, Evidence, EvidenceOutcome, RiskScore

logger = logging.getLogger("complianceiq.rule_engine")


class Rule(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    rule_id: str
    version: str = "1.0.0"
    domain: Domain
    severity: Severity
    resource_types: list[str]
    description: str
    # Dict brut, pas un modèle Pydantic strict : une feuille {attribute,
    # operator, value} OU un nœud {all:[...]}/{any:[...]}/{not: ...} — voir
    # scanner/conditions.py pour la justification de ce choix.
    condition: dict[str, Any]
    # Mapping primaire vers un référentiel — obligatoire : un finding sans
    # framework/control_id serait rejeté par le contrat de l'AI Service.
    framework: Framework
    control_id: str
    # Provenance interne (ex. « CIS AWS Foundations 1.4 »). N'est PAS un
    # framework au sens du contrat partagé.
    benchmark_source: str | None = None
    enabled: bool = True


# ---------------------------------------------------------------------------
# Calcul du risque (0-100) — interne au Core Service
# ---------------------------------------------------------------------------
class RiskCalculator:
    """Score de risque multi-facteurs, inspiré du modèle CRSF du projet.

    Les pondérations sont un point de départ défendable, pas une vérité
    scientifique : à annoncer comme tel devant un jury.

    `attack_path_involvement` (0.0 ou 1.0 aujourd'hui, jamais négatif ni
    None) est peuplé par ScanService APRÈS l'Attack Path Analysis — voir
    la justification de la séquence Graph -> Findings -> Attack Path ->
    Risk dans le document d'assessment. Sa valeur par défaut ici est 0.0
    (finding non enrichi), jamais fabriquée.
    """

    MODEL_VERSION = "crsf-1.1"  # 1.1 : ajout du facteur attack_path

    WEIGHT_SEVERITY = 0.40
    WEIGHT_EXPOSURE = 0.25
    WEIGHT_ENVIRONMENT = 0.10
    WEIGHT_CONFIDENCE = 0.10
    WEIGHT_ATTACK_PATH = 0.15

    @classmethod
    def calculate(
        cls,
        rule: Rule,
        resource: NormalizedResource,
        confidence: float,
        attack_path_involvement: float = 0.0,
    ) -> RiskScore:
        severity_factor = rule.severity.weight / 4.0

        exposure = resource.attributes.get("public_access_blocked")
        public_read = resource.attributes.get("public_read_access")
        is_exposed = (exposure is False) or (public_read is True)
        exposure_factor = 1.0 if is_exposed else 0.3

        environment_factor = 1.0 if resource.environment == "production" else 0.5

        raw = (
            cls.WEIGHT_SEVERITY * severity_factor
            + cls.WEIGHT_EXPOSURE * exposure_factor
            + cls.WEIGHT_ENVIRONMENT * environment_factor
            + cls.WEIGHT_CONFIDENCE * confidence
            + cls.WEIGHT_ATTACK_PATH * attack_path_involvement
        )
        score = raw * 100

        # Amortissement par la confiance : un finding incertain ne doit pas
        # côtoyer une violation confirmée en tête de file de priorisation.
        if confidence < 0.5:
            score *= confidence + 0.2

        return RiskScore(
            value=min(round(score, 2), 100.0),
            model_version=cls.MODEL_VERSION,
            factors={
                "severity": round(severity_factor, 3),
                "exposure": round(exposure_factor, 3),
                "environment": round(environment_factor, 3),
                "confidence": round(confidence, 3),
                "attack_path_involvement": round(attack_path_involvement, 3),
            },
        )


# ---------------------------------------------------------------------------
# Rule Engine
# ---------------------------------------------------------------------------
CONFIDENCE_CONFIRMED = 0.95
CONFIDENCE_INDETERMINATE = 0.30


class RuleEngine:
    def __init__(self, rules: list[Rule], emit_passes: bool = True):
        self.rules = rules
        self.emit_passes = emit_passes
        logger.info("Rule Engine initialisé avec %d règles", len(rules))

    @classmethod
    def from_directory(
        cls, rules_dir: str | Path, emit_passes: bool = True
    ) -> "RuleEngine":
        """Charge toutes les règles depuis les fichiers *.yaml d'un dossier."""
        rules_dir = Path(rules_dir)
        if not rules_dir.is_dir():
            raise FileNotFoundError(f"Dossier de règles introuvable : {rules_dir}")

        rules: list[Rule] = []
        seen_ids: set[str] = set()

        for yaml_file in sorted(rules_dir.glob("*.yaml")):
            with open(yaml_file, encoding="utf-8") as f:
                raw_rules = yaml.safe_load(f)  # safe_load : jamais d'exécution de code

            if not raw_rules:
                continue

            loaded = 0
            for raw_rule in raw_rules:
                rule_id = raw_rule.get("rule_id", "?")
                if rule_id in seen_ids:
                    logger.error(
                        "rule_id dupliqué ignoré : %s (%s)", rule_id, yaml_file.name
                    )
                    continue
                try:
                    rule = Rule(**raw_rule)
                except Exception as e:  # noqa: BLE001
                    logger.error(
                        "Règle invalide dans %s (rule_id=%s) : %s",
                        yaml_file.name,
                        rule_id,
                        e,
                    )
                    continue
                rules.append(rule)
                seen_ids.add(rule_id)
                loaded += 1

            logger.info("%s : %d règle(s) chargée(s)", yaml_file.name, loaded)

        return cls(rules, emit_passes=emit_passes)

    def evaluate_resource(
        self, resource: NormalizedResource, scan_id: str, graph: ResourceGraph | None = None
    ) -> list[Finding]:
        """Évalue toutes les règles applicables à UNE ressource.

        `graph` est optionnel : si absent, un graphe réduit à cette seule
        ressource est utilisé — les fonctions contextuelles (is_reachable_
        from_internet, etc.) répondent alors False de façon sûre (voir
        scanner/graph/context.py), sans jamais lever d'exception. C'est ce
        qui garantit que les 33 règles existantes, purement resource-level,
        continuent de fonctionner à l'identique sans graphe fourni.
        """
        if graph is None:
            graph = ResourceGraph(tenant_id=resource.tenant_id)
            from scanner.graph.models import GraphNode
            graph.add_node(
                GraphNode(id=resource.resource_id, resource_type=resource.resource_type,
                          tenant_id=resource.tenant_id)
            )

        context = ResourceContext(resource=resource, graph=graph)
        findings: list[Finding] = []

        for rule in self.rules:
            if not rule.enabled:
                continue
            if resource.resource_type not in rule.resource_types:
                continue

            try:
                result = evaluate_condition_tree(rule.condition, context)
            except ConditionError as e:
                logger.error("Erreur d'évaluation pour %s : %s", rule.rule_id, e)
                continue

            finding = self._build_finding(rule, resource, result.outcome, scan_id, result.trace)
            if finding is not None:
                findings.append(finding)

        return findings

    def _build_finding(
        self, rule: Rule, resource: NormalizedResource, outcome: str, scan_id: str,
        trace: list[str],
    ) -> Finding | None:
        common = dict(
            tenant_id=resource.tenant_id,
            scan_id=scan_id,
            cloud_provider=resource.cloud_provider,
            resource_id=resource.resource_id,
            resource_type=resource.resource_type,
            region=resource.region,
            environment=resource.environment,
            rule_id=rule.rule_id,
            rule_version=rule.version,
            domain=rule.domain,
            framework=rule.framework,
            control_id=rule.control_id,
        )
        attribute = rule.condition.get("attribute")
        operator = rule.condition.get("operator")
        expected = rule.condition.get("value")

        if outcome == ConditionOutcome.NOT_MATCHED:
            if not self.emit_passes:
                return None
            confidence = ConfidenceScore(value=CONFIDENCE_CONFIRMED * 100)
            evidence = Evidence(
                outcome=EvidenceOutcome.NOT_MATCHED,
                observed_attribute=attribute or "condition_tree",
                expected_value=expected,
                actual_value=resource.attributes.get(attribute) if attribute else None,
                operator=operator,
                collector=resource.cloud_provider.value,
            )
            return Finding(
                **common,
                severity=rule.severity,
                status=ComplianceStatus.PASS,
                description=f"Conforme : {rule.rule_id}",
                evidence=evidence,
                risk=RiskScore(value=0.0, factors={"reason": 0.0}),
                confidence=confidence,
            )

        if outcome == ConditionOutcome.INDETERMINATE:
            confidence_value = CONFIDENCE_INDETERMINATE
            confidence = ConfidenceScore(value=confidence_value * 100)
            evidence = Evidence(
                outcome=EvidenceOutcome.INDETERMINATE,
                observed_attribute=attribute or "condition_tree",
                operator=operator,
                collector=resource.cloud_provider.value,
                indeterminate_reason="attribut ou fonction contextuelle indéterminé("
                + "; ".join(trace) + ")" if trace else "attribut absent des données collectées",
            )
            return Finding(
                **common,
                severity=rule.severity.downgrade(),
                status=ComplianceStatus.FAIL,
                description=(
                    f"Indéterminé pour {rule.rule_id} sur {resource.resource_id}."
                ),
                evidence=evidence,
                risk=RiskCalculator.calculate(rule, resource, confidence_value),
                confidence=confidence,
            )

        # MATCHED -> violation confirmée
        confidence_value = CONFIDENCE_CONFIRMED
        confidence = ConfidenceScore(value=confidence_value * 100)
        evidence = Evidence(
            outcome=EvidenceOutcome.MATCHED,
            observed_attribute=attribute or "condition_tree",
            expected_value=expected,
            actual_value=resource.attributes.get(attribute) if attribute else None,
            operator=operator,
            collector=resource.cloud_provider.value,
        )
        return Finding(
            **common,
            severity=rule.severity,
            status=ComplianceStatus.FAIL,
            description=rule.description.format(resource_id=resource.resource_id),
            evidence=evidence,
            risk=RiskCalculator.calculate(rule, resource, confidence_value),
            confidence=confidence,
        )

    def evaluate_all(
        self,
        resources: Sequence[NormalizedResource],
        scan_id: str,
        tenant_id: str | None = None,
        graph: ResourceGraph | None = None,
    ) -> list[Finding]:
        """Évalue une liste de ressources normalisées.

        `tenant_id` agit comme garde d'isolation : une ressource appartenant
        à un autre locataire est écartée plutôt que scannée.
        `graph` est partagé pour toutes les ressources du scan (construit
        une seule fois par ScanService, voir scan_service.py).
        """
        all_findings: list[Finding] = []

        for resource in resources:
            if tenant_id is not None and resource.tenant_id != tenant_id:
                logger.error(
                    "Ressource %s ignorée : tenant %s attendu, %s trouvé",
                    resource.resource_id,
                    tenant_id,
                    resource.tenant_id,
                )
                continue
            all_findings.extend(self.evaluate_resource(resource, scan_id, graph=graph))

        return all_findings
