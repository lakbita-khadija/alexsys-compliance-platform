"""
scanner/graph/models.py

Le Resource Graph — modèle de domaine, sans dépendance à une base de graphe.
PostgreSQL relationnel (deux tables nodes/edges) est le backend visé ; le
port ci-dessous permet de le remplacer par Neo4j plus tard SANS toucher au
domaine, si le volume le justifie un jour (voir la note dans le document
d'assessment — décision volontairement différée, pas "jamais").

INTERNET est un nœud spécial, unique par tenant : le point d'entrée
conceptuel de toute analyse d'exposition. Il n'existe dans aucune API cloud
— c'est la seule fiction assumée et documentée de ce modèle, standard dans
toute analyse d'attack path (Wiz, Orca, Prowler procèdent de même).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from scanner.schema import NormalizedResource, RelationshipType

INTERNET_NODE_ID = "__internet__"


@dataclass(frozen=True, slots=True)
class GraphNode:
    id: str
    resource_type: str
    tenant_id: str
    properties: dict = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class GraphEdge:
    source_id: str
    target_id: str
    relationship_type: RelationshipType
    # `blocked` : un contrôle de sécurité rend-il cette relation non
    # exploitable ? (ex: security group qui bloque le port). Consulté par
    # l'Attack Path Engine — une relation techniquement présente mais
    # bloquée ne doit jamais compter comme un chemin exploitable.
    blocked: bool = False
    properties: dict = field(default_factory=dict)


class ResourceGraph:
    """Aggregate : un graphe complet, scopé à un tenant.

    Construit en mémoire pour l'analyse d'un scan ; la persistance
    (Phase dédiée) sauvegarde nodes/edges tels quels, sans logique propre.
    """

    def __init__(self, tenant_id: str) -> None:
        self.tenant_id = tenant_id
        self._nodes: dict[str, GraphNode] = {}
        self._edges: list[GraphEdge] = []
        self._adjacency: dict[str, list[GraphEdge]] = {}

    def add_node(self, node: GraphNode) -> None:
        if node.tenant_id != self.tenant_id:
            raise ValueError(
                f"Node {node.id} appartient au tenant {node.tenant_id}, "
                f"pas au graphe du tenant {self.tenant_id} — isolation violée"
            )
        self._nodes[node.id] = node
        self._adjacency.setdefault(node.id, [])

    def add_edge(self, edge: GraphEdge) -> None:
        if edge.source_id not in self._nodes or edge.target_id not in self._nodes:
            raise ValueError(
                f"Impossible d'ajouter l'arête {edge.source_id}->{edge.target_id} : "
                "un des deux nœuds n'existe pas dans le graphe"
            )
        self._edges.append(edge)
        self._adjacency[edge.source_id].append(edge)

    def get_node(self, node_id: str) -> GraphNode | None:
        return self._nodes.get(node_id)

    def neighbors(self, node_id: str, include_blocked: bool = False) -> list[GraphEdge]:
        edges = self._adjacency.get(node_id, [])
        return edges if include_blocked else [e for e in edges if not e.blocked]

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        return len(self._edges)

    @property
    def nodes(self) -> list[GraphNode]:
        return list(self._nodes.values())

    @property
    def edges(self) -> list[GraphEdge]:
        return list(self._edges)


class ResourceGraphPort(ABC):
    """Port de persistance — implémentation Postgres relationnelle prévue
    en phase dédiée, pas construite ici (cette classe n'a aujourd'hui
    qu'un usage in-memory via ResourceGraph directement)."""

    @abstractmethod
    def save(self, graph: ResourceGraph, scan_id: str) -> None: ...

    @abstractmethod
    def load_latest(self, tenant_id: str) -> ResourceGraph | None: ...
