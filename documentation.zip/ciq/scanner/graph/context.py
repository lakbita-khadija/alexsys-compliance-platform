"""
scanner/graph/context.py

ResourceContext -- ce qu'une regle contextuelle recoit en plus de la
ressource brute : ses voisins et le graphe complet.

Le registre de fonctions est FERME (pas d'eval, pas d'expression Python
arbitraire dans le YAML) : une regle ne peut appeler que les fonctions
explicitement enregistrees ici, chacune implementee en Python pur et
testee isolement.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Callable

from scanner.graph.models import INTERNET_NODE_ID, GraphNode, ResourceGraph
from scanner.schema import NormalizedResource


@dataclass(frozen=True, slots=True)
class ResourceContext:
    resource: NormalizedResource
    graph: ResourceGraph

    @property
    def neighbors(self) -> list[GraphNode]:
        edges = self.graph.neighbors(self.resource.resource_id, include_blocked=True)
        return [n for e in edges if (n := self.graph.get_node(e.target_id)) is not None]


def is_publicly_exposed(context: ResourceContext) -> bool:
    """Vrai si une arete NON bloquee relie INTERNET a cette ressource."""
    node_id = context.resource.resource_id
    for edge in context.graph.neighbors(INTERNET_NODE_ID, include_blocked=False):
        if edge.target_id == node_id:
            return True
    return False


def is_reachable_from_internet(context: ResourceContext, max_depth: int = 4) -> bool:
    """BFS borne (voir S17 -- pas de O(N^2), profondeur maximale stricte)
    depuis INTERNET jusqu'a cette ressource, en ignorant les aretes bloquees
    par un controle de securite actif (ex: security group qui filtre)."""
    if context.graph.get_node(INTERNET_NODE_ID) is None:
        return False

    target = context.resource.resource_id
    visited: set[str] = {INTERNET_NODE_ID}
    queue: deque[tuple[str, int]] = deque([(INTERNET_NODE_ID, 0)])

    while queue:
        current, depth = queue.popleft()
        if current == target:
            return True
        if depth >= max_depth:
            continue
        for edge in context.graph.neighbors(current, include_blocked=False):
            if edge.target_id not in visited:
                visited.add(edge.target_id)
                queue.append((edge.target_id, depth + 1))
    return False


def has_path_to(context: ResourceContext, target_resource_id: str, max_depth: int = 4) -> bool:
    """Generalisation de is_reachable_from_internet a une source arbitraire
    (la ressource du contexte elle-meme)."""
    source = context.resource.resource_id
    visited: set[str] = {source}
    queue: deque[tuple[str, int]] = deque([(source, 0)])
    while queue:
        current, depth = queue.popleft()
        if current == target_resource_id:
            return True
        if depth >= max_depth:
            continue
        for edge in context.graph.neighbors(current, include_blocked=False):
            if edge.target_id not in visited:
                visited.add(edge.target_id)
                queue.append((edge.target_id, depth + 1))
    return False


# Registre ferme -- une regle YAML ne peut referencer QUE ces noms.
CONTEXT_FUNCTIONS: dict[str, Callable[..., bool]] = {
    "is_publicly_exposed": is_publicly_exposed,
    "is_reachable_from_internet": is_reachable_from_internet,
    "has_path_to": has_path_to,
}
