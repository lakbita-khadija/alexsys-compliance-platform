"""
scanner/graph/builder.py

Construit un ResourceGraph à partir des `relationships` réellement portées
par les NormalizedResource d'un scan — jamais inventées ici. Si une relation
n'a pas été collectée, elle n'apparaît simplement pas dans le graphe : c'est
la conséquence honnête du principe "MISSING COLLECTOR CAPABILITY", pas une
lacune de ce module.

Le nœud INTERNET est ajouté uniquement s'il existe au moins une ressource
publiquement exposée (`relationships` contenant PUBLICLY_EXPOSED), pour ne
jamais faire apparaître un graphe connecté à Internet là où rien ne l'expose.
"""

from __future__ import annotations

from scanner.graph.models import INTERNET_NODE_ID, GraphEdge, GraphNode, ResourceGraph
from scanner.schema import NormalizedResource, RelationshipType


class GraphBuilder:
    @staticmethod
    def build(resources: list[NormalizedResource], tenant_id: str) -> ResourceGraph:
        graph = ResourceGraph(tenant_id=tenant_id)

        has_public_exposure = any(
            r.relationship_type == RelationshipType.PUBLICLY_EXPOSED
            for res in resources
            for r in res.relationships
        )
        if has_public_exposure:
            graph.add_node(
                GraphNode(id=INTERNET_NODE_ID, resource_type="internet", tenant_id=tenant_id)
            )

        for resource in resources:
            graph.add_node(
                GraphNode(
                    id=resource.resource_id,
                    resource_type=resource.resource_type,
                    tenant_id=tenant_id,
                    properties={
                        "cloud_provider": resource.cloud_provider.value,
                        "environment": resource.environment,
                        # Attributs bruts conservés pour l'Attack Path Engine
                        # (technique mapping, scoring) sans re-fetch du
                        # NormalizedResource complet.
                        "attributes": dict(resource.attributes),
                    },
                )
            )

        for resource in resources:
            for rel in resource.relationships:
                target_id = rel.target_resource_id
                if rel.relationship_type == RelationshipType.PUBLICLY_EXPOSED:
                    graph.add_edge(
                        GraphEdge(
                            source_id=INTERNET_NODE_ID,
                            target_id=resource.resource_id,
                            relationship_type=RelationshipType.CONNECTS_TO,
                            blocked=bool(rel.properties.get("blocked", False)),
                            properties=rel.properties,
                        )
                    )
                    continue

                known_ids = {r.resource_id for r in resources}
                if target_id not in known_ids and target_id != INTERNET_NODE_ID:
                    continue

                graph.add_edge(
                    GraphEdge(
                        source_id=resource.resource_id,
                        target_id=target_id,
                        relationship_type=rel.relationship_type,
                        blocked=bool(rel.properties.get("blocked", False)),
                        properties=rel.properties,
                    )
                )

        return graph
