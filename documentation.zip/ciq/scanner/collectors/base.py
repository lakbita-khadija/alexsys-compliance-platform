"""
scanner/collectors/base.py

Interface commune à tous les collecteurs cloud.

C'est la frontière qui garde boto3 et les SDK Azure HORS du Rule Engine :
au-dessus de cette ligne on ne parle que de NormalizedResource, en dessous
seulement les adaptateurs savent ce qu'est un ARN. C'est ce qui permet à une
même règle YAML de s'appliquer à AWS et à Azure sans un seul `if provider`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from scanner.schema import NormalizedResource


@dataclass
class CollectionResult:
    """La collecte est TOLÉRANTE AUX ÉCHECS PARTIELS par conception : une
    région en erreur ou une permission manquante ne doit pas faire perdre
    tout le reste. `errors` permet au pipeline d'abaisser la confiance et
    au tableau de bord d'afficher « scanné avec lacunes » plutôt qu'une
    posture faussement saine.
    """

    resources: list[NormalizedResource] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def is_complete(self) -> bool:
        return not self.errors

    def merge(self, other: "CollectionResult") -> "CollectionResult":
        return CollectionResult(
            resources=self.resources + other.resources,
            errors=self.errors + other.errors,
        )


class BaseCollector(ABC):
    """Un collecteur par service cloud (S3, IAM, EC2...)."""

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def collect(self, tenant_id: str) -> CollectionResult:
        """Collecte et normalise. Ne doit JAMAIS lever sur un échec partiel :
        renvoyer ce qui a pu être collecté, avec les erreurs."""
