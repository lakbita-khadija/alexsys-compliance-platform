"""
scanner/collectors/mock_collector.py

Collecteur hors-ligne — citoyen de première classe, pas un jouet.

Les fixtures reproduisent fidèlement les ressources créées par le Terraform
de test (`modules/aws/*.tf`), y compris les paires conforme /
non-conforme délibérées. Résultat : la démo tourne sans compte AWS, sans
credentials et sans réseau, tout en restant représentative de ce que le
collecteur réel produira.

Un cas est volontairement INCOMPLET (`s3_bucket_permission_denied`) afin que
le chemin « indéterminé » du Rule Engine soit exercé par le jeu de données
par défaut, et non seulement par un test dédié.
"""

from __future__ import annotations

from scanner.collectors.base import BaseCollector, CollectionResult
from scanner.graph.models import INTERNET_NODE_ID
from scanner.schema import (
    CloudProvider,
    NormalizedResource,
    RelationshipType,
    ResourceRelationship,
)


class MockAwsCollector(BaseCollector):
    def __init__(self, with_errors: bool = False):
        self._with_errors = with_errors

    @property
    def name(self) -> str:
        return "mock-aws"

    def collect(self, tenant_id: str) -> CollectionResult:
        resources = [
            # --- S3 : le bucket non conforme du Terraform ---
            NormalizedResource(
                resource_id="ciq-sandbox-public-bucket",
                resource_type="s3_bucket",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-1",
                attributes={
                    "public_access_blocked": False,
                    "has_public_access_block_config": True,
                    "public_read_access": True,
                    "public_write_access": False,
                    "encrypted": False,
                    "kms_encrypted": False,
                    "versioning_enabled": False,
                    "logging_enabled": False,
                },
                tags={"Environment": "production", "ComplianceStatus": "non-compliant"},
                relationships=[
                    ResourceRelationship(
                        relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                        target_resource_id=INTERNET_NODE_ID,
                        source_field="s3_bucket.public_read_access (ACL analysis)",
                    ),
                ],
            ),
            # --- S3 : le bucket CloudTrail conforme du Terraform ---
            NormalizedResource(
                resource_id="ciq-sandbox-cloudtrail-logs",
                resource_type="s3_bucket",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-1",
                attributes={
                    "public_access_blocked": True,
                    "has_public_access_block_config": True,
                    "public_read_access": False,
                    "public_write_access": False,
                    "encrypted": True,
                    "kms_encrypted": True,
                    "versioning_enabled": True,
                    "logging_enabled": True,
                },
                tags={"Environment": "production", "ComplianceStatus": "compliant"},
            ),
            # --- S3 : permissions insuffisantes -> attributs manquants ---
            NormalizedResource(
                resource_id="ciq-sandbox-permission-denied",
                resource_type="s3_bucket",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-3",
                attributes={},  # rien n'a pu être lu : chemin « indéterminé »
                tags={"Environment": "sandbox"},
            ),
            # --- CloudTrail non conforme (mono-région, sans validation) ---
            NormalizedResource(
                resource_id="ciq-sandbox-test-trail-non-compliant",
                resource_type="cloudtrail",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-1",
                attributes={
                    "is_multi_region": False,
                    "log_file_validation_enabled": False,
                    "cloudwatch_logs_enabled": False,
                    "log_bucket_encrypted": True,
                },
                tags={"Environment": "sandbox", "ComplianceStatus": "non-compliant"},
            ),
            # --- CloudTrail conforme ---
            NormalizedResource(
                resource_id="ciq-sandbox-compliant-trail",
                resource_type="cloudtrail",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-1",
                attributes={
                    "is_multi_region": True,
                    "log_file_validation_enabled": True,
                    "cloudwatch_logs_enabled": True,
                    "log_bucket_encrypted": True,
                },
                tags={"Environment": "production", "ComplianceStatus": "compliant"},
            ),
            # --- Security group : SSH ouvert au monde ---
            NormalizedResource(
                resource_id="sg-ciq-open-ssh",
                resource_type="security_group",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-1",
                attributes={
                    "ssh_open_to_world": True,
                    "rdp_open_to_world": False,
                    "database_port_open_to_world": False,
                    "any_port_open_to_world": True,
                },
                tags={"Environment": "production", "ComplianceStatus": "non-compliant"},
                relationships=[
                    ResourceRelationship(
                        relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                        target_resource_id=INTERNET_NODE_ID,
                        source_field="security_group.ip_permissions (0.0.0.0/0 sur any_port)",
                    ),
                    ResourceRelationship(
                        relationship_type=RelationshipType.ALLOWS,
                        target_resource_id="ciq-sandbox-db-public",
                        source_field="rds_instance.vpc_security_groups (attachement SG->RDS)",
                        properties={"blocked": False},
                    ),
                ],
            ),
            # --- IAM : utilisateur sans MFA ---
            NormalizedResource(
                resource_id="ciq-sandbox-user-no-mfa",
                resource_type="iam_user",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                attributes={
                    "mfa_enabled": False,
                    "has_admin_access": True,
                    "access_key_age_days": 210,
                    "days_since_last_activity": 5,
                },
                tags={"Environment": "production", "ComplianceStatus": "non-compliant"},
            ),
            # --- RDS : base publiquement accessible et non chiffrée ---
            NormalizedResource(
                resource_id="ciq-sandbox-db-public",
                resource_type="rds_instance",
                cloud_provider=CloudProvider.AWS,
                tenant_id=tenant_id,
                region="eu-west-1",
                attributes={
                    "publicly_accessible": True,
                    "storage_encrypted": False,
                    "backup_retention_period": 0,
                    "deletion_protection": False,
                },
                tags={"Environment": "production", "ComplianceStatus": "non-compliant"},
            ),
        ]

        errors = (
            ["eu-west-3: AccessDenied sur s3:GetBucketAcl (ciq-sandbox-permission-denied)"]
            if self._with_errors
            else []
        )
        return CollectionResult(resources=resources, errors=errors)
