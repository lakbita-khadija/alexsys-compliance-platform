"""
scanner/collectors/aws_collector.py

Collecteur AWS réel — le SEUL fichier du scanner qui importe boto3.

⚠️ NON EXÉCUTÉ dans l'environnement hors-ligne où ce code a été écrit
(ni réseau, ni credentials AWS). Contrairement au Rule Engine et au
ScanService (35 tests verts), ce fichier n'a PAS été prouvé. À vérifier
avec `moto` (voir tests/test_aws_collector_moto.py) ou un compte réel en
lecture seule avant de s'y fier. La logique qu'il alimente, elle, est
entièrement testée via MockAwsCollector.

SÉCURITÉ (non négociable) :
  - permissions IAM en LECTURE SEULE uniquement
  - jamais de credentials en dur : chaîne par défaut de boto3 (variables
    d'environnement, rôle IAM, ou AssumeRole avec ExternalId en cross-account)
  - ne jamais journaliser les credentials ni les réponses API complètes

PRINCIPE DE COLLECTE : un attribut qui n'a pas pu être lu est OMIS du
dictionnaire, jamais mis à False. C'est ce qui déclenche le chemin
« indéterminé » du Rule Engine plutôt qu'un faux « conforme ».
"""

from __future__ import annotations

import logging
from typing import Any

from scanner.collectors.base import BaseCollector, CollectionResult
from scanner.schema import CloudProvider, NormalizedResource

logger = logging.getLogger("complianceiq.collectors.aws")


class AwsCollector(BaseCollector):
    def __init__(self, session: Any, region: str = "eu-west-1"):
        """`session` est une boto3.Session injectée — injectée plutôt que
        construite ici, pour qu'un test puisse passer une session pilotée
        par moto sans que cette classe le sache."""
        self._session = session
        self._region = region

    @property
    def name(self) -> str:
        return f"aws-{self._region}"

    def collect(self, tenant_id: str) -> CollectionResult:
        result = CollectionResult()
        for collect_fn in (self._collect_s3, self._collect_security_groups, self._collect_iam_users):
            try:
                partial = collect_fn(tenant_id)
                result = result.merge(partial)
            except Exception as exc:  # noqa: BLE001
                # Un service en échec ne doit pas annuler les autres.
                result.errors.append(f"{collect_fn.__name__}: {type(exc).__name__}")
                logger.warning("Collecte partielle en échec: %s", type(exc).__name__)
        return result

    # ------------------------------------------------------------------ S3
    def _collect_s3(self, tenant_id: str) -> CollectionResult:
        client = self._session.client("s3", region_name=self._region)
        result = CollectionResult()

        buckets = client.list_buckets().get("Buckets", [])
        for bucket in buckets:
            name = bucket["Name"]
            attributes: dict[str, Any] = {}

            # Chaque appel est isolé : une permission manquante sur l'un
            # n'empêche pas de collecter les autres attributs.
            pab = self._safe(client.get_public_access_block, Bucket=name)
            if pab is not None:
                cfg = pab.get("PublicAccessBlockConfiguration", {})
                attributes["has_public_access_block_config"] = True
                attributes["public_access_blocked"] = bool(
                    cfg.get("BlockPublicAcls")
                    and cfg.get("BlockPublicPolicy")
                    and cfg.get("IgnorePublicAcls")
                    and cfg.get("RestrictPublicBuckets")
                )

            acl = self._safe(client.get_bucket_acl, Bucket=name)
            if acl is not None:
                public_uris = (
                    "http://acs.amazonaws.com/groups/global/AllUsers",
                    "http://acs.amazonaws.com/groups/global/AuthenticatedUsers",
                )
                read = write = False
                for grant in acl.get("Grants", []):
                    uri = grant.get("Grantee", {}).get("URI", "")
                    if uri in public_uris:
                        permission = grant.get("Permission", "")
                        if permission in ("READ", "FULL_CONTROL"):
                            read = True
                        if permission in ("WRITE", "FULL_CONTROL"):
                            write = True
                attributes["public_read_access"] = read
                attributes["public_write_access"] = write

            enc = self._safe(client.get_bucket_encryption, Bucket=name)
            if enc is not None:
                rules = enc.get("ServerSideEncryptionConfiguration", {}).get("Rules", [])
                attributes["encrypted"] = bool(rules)
                attributes["kms_encrypted"] = any(
                    r.get("ApplyServerSideEncryptionByDefault", {}).get("SSEAlgorithm") == "aws:kms"
                    for r in rules
                )

            ver = self._safe(client.get_bucket_versioning, Bucket=name)
            if ver is not None:
                attributes["versioning_enabled"] = ver.get("Status") == "Enabled"

            log = self._safe(client.get_bucket_logging, Bucket=name)
            if log is not None:
                attributes["logging_enabled"] = "LoggingEnabled" in log

            result.resources.append(
                NormalizedResource(
                    resource_id=name,
                    resource_type="s3_bucket",
                    cloud_provider=CloudProvider.AWS,
                    tenant_id=tenant_id,
                    region=self._region,
                    attributes=attributes,
                    tags=self._bucket_tags(client, name),
                    relationships=self._bucket_relationships(attributes),
                )
            )
        return result

    @staticmethod
    def _bucket_relationships(attributes: dict[str, Any]) -> list["ResourceRelationship"]:
        """Une seule relation honnêtement dérivable aujourd'hui côté S3 :
        l'exposition publique, directement issue de l'ACL déjà lue
        ci-dessus (aucun appel API supplémentaire).

        ⚠️ MISSING COLLECTOR CAPABILITY — SG->RDS/EC2 : ce collecteur ne
        collecte NI les instances RDS (describe_db_instances jamais
        appelé) NI l'attachement d'un security group à une ressource
        (aucune jointure security_group<->instance). La relation ALLOWS
        démontrée dans MockAwsCollector représente ce qu'un collecteur
        étendu produirait — PAS ce que ce collecteur réel produit
        aujourd'hui. Étendre _collect_security_groups et ajouter un
        _collect_rds avant de considérer cette relation comme fiable
        contre un compte AWS réel.
        """
        if not attributes.get("public_read_access") and not attributes.get("public_write_access"):
            return []
        from scanner.graph.models import INTERNET_NODE_ID
        from scanner.schema import RelationshipType, ResourceRelationship

        return [
            ResourceRelationship(
                relationship_type=RelationshipType.PUBLICLY_EXPOSED,
                target_resource_id=INTERNET_NODE_ID,
                source_field="s3:GetBucketAcl grants to AllUsers/AuthenticatedUsers",
            )
        ]

    def _bucket_tags(self, client: Any, name: str) -> dict[str, str]:
        tagging = self._safe(client.get_bucket_tagging, Bucket=name)
        if tagging is None:
            return {}
        return {t["Key"]: t["Value"] for t in tagging.get("TagSet", [])}

    # ------------------------------------------------- Security groups (EC2)
    def _collect_security_groups(self, tenant_id: str) -> CollectionResult:
        client = self._session.client("ec2", region_name=self._region)
        result = CollectionResult()

        response = client.describe_security_groups()
        for sg in response.get("SecurityGroups", []):
            attributes = self._analyze_sg_rules(sg.get("IpPermissions", []))
            result.resources.append(
                NormalizedResource(
                    resource_id=sg["GroupId"],
                    resource_type="security_group",
                    cloud_provider=CloudProvider.AWS,
                    tenant_id=tenant_id,
                    region=self._region,
                    attributes=attributes,
                    tags={t["Key"]: t["Value"] for t in sg.get("Tags", [])},
                )
            )
        return result

    @staticmethod
    def _analyze_sg_rules(permissions: list[dict[str, Any]]) -> dict[str, Any]:
        DB_PORTS = {3306, 5432, 1433, 27017, 6379, 5439}
        result = {
            "ssh_open_to_world": False,
            "rdp_open_to_world": False,
            "database_port_open_to_world": False,
            "any_port_open_to_world": False,
        }
        for perm in permissions:
            open_to_world = any(
                r.get("CidrIp") == "0.0.0.0/0" for r in perm.get("IpRanges", [])
            ) or any(r.get("CidrIpv6") == "::/0" for r in perm.get("Ipv6Ranges", []))
            if not open_to_world:
                continue

            result["any_port_open_to_world"] = True
            from_port = perm.get("FromPort")
            to_port = perm.get("ToPort", from_port)
            if from_port is None:  # -1 / tous les protocoles
                result["ssh_open_to_world"] = True
                result["rdp_open_to_world"] = True
                result["database_port_open_to_world"] = True
                continue

            port_range = range(from_port, (to_port or from_port) + 1)
            if 22 in port_range:
                result["ssh_open_to_world"] = True
            if 3389 in port_range:
                result["rdp_open_to_world"] = True
            if any(p in port_range for p in DB_PORTS):
                result["database_port_open_to_world"] = True
        return result

    # ----------------------------------------------------------------- IAM
    def _collect_iam_users(self, tenant_id: str) -> CollectionResult:
        client = self._session.client("iam")
        result = CollectionResult()

        for user in client.list_users().get("Users", []):
            username = user["UserName"]
            attributes: dict[str, Any] = {}

            mfa = self._safe(client.list_mfa_devices, UserName=username)
            if mfa is not None:
                attributes["mfa_enabled"] = bool(mfa.get("MFADevices"))

            policies = self._safe(client.list_attached_user_policies, UserName=username)
            if policies is not None:
                attributes["has_admin_access"] = any(
                    p.get("PolicyName") == "AdministratorAccess"
                    for p in policies.get("AttachedPolicies", [])
                )

            result.resources.append(
                NormalizedResource(
                    resource_id=username,
                    resource_type="iam_user",
                    cloud_provider=CloudProvider.AWS,
                    tenant_id=tenant_id,
                    region="global",
                    attributes=attributes,
                    tags={t["Key"]: t["Value"] for t in user.get("Tags", [])},
                )
            )
        return result

    # -------------------------------------------------------------- helpers
    @staticmethod
    def _safe(fn: Any, **kwargs: Any) -> dict[str, Any] | None:
        """Exécute un appel API et renvoie None en cas d'échec.

        None signifie « information non disponible » et provoque l'OMISSION
        de l'attribut, ce qui déclenche le chemin « indéterminé » du Rule
        Engine. Ne jamais transformer un échec en valeur False : ce serait
        rapporter une conformité qu'on n'a pas vérifiée.
        """
        try:
            return fn(**kwargs)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Appel API ignoré (%s): %s", fn.__name__, type(exc).__name__)
            return None
