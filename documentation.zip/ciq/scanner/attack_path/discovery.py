"""
scanner/attack_path/discovery.py

PathDiscovery -- traversee du Resource Graph bornee (profondeur maximale,
nombre de chemins maximal), JAMAIS un simple plus-court-chemin : elle
enumere plusieurs chemins candidats, que PathConstraintEvaluator filtrera
et pondera ensuite selon le contexte de securite (S17 : eviter l'explosion
combinatoire ; S5 : pas de shortest-path naif).
"""

from __future__ import annotations

from dataclasses import dataclass

from scanner.graph.models import GraphEdge, ResourceGraph


@dataclass(frozen=True, slots=True)
class CandidatePath:
    node_ids: list[str]
    edges: list[GraphEdge]


class PathDiscovery:
    def __init__(self, max_depth: int = 6, max_paths_per_target: int = 5) -> None:
        self._max_depth = max_depth
        self._max_paths = max_paths_per_target

    def discover(
        self, graph: ResourceGraph, source_id: str, target_ids: list[str],
        include_blocked: bool = False,
    ) -> list[CandidatePath]:
        """DFS borne en profondeur ET en nombre de chemins par cible --
        c'est ce qui evite l'explosion combinatoire sur un graphe dense.
        `include_blocked` permet de decouvrir des chemins "techniquement
        possibles mais actuellement bloques" (utile pour l'analyse
        d'impact du Drift, S11), sans jamais les compter par defaut comme
        exploitables."""
        if graph.get_node(source_id) is None:
            return []

        targets = set(target_ids)
        found: dict[str, list[CandidatePath]] = {t: [] for t in targets}

        def dfs(current: str, path_nodes: list[str], path_edges: list[GraphEdge], visited: set[str]):
            if current in targets and len(path_nodes) > 1:
                if len(found[current]) < self._max_paths:
                    found[current].append(CandidatePath(list(path_nodes), list(path_edges)))
            if len(path_nodes) - 1 >= self._max_depth:
                return
            for edge in graph.neighbors(current, include_blocked=include_blocked):
                if edge.target_id in visited:
                    continue  # évite les cycles, garantit la terminaison
                visited.add(edge.target_id)
                path_nodes.append(edge.target_id)
                path_edges.append(edge)
                dfs(edge.target_id, path_nodes, path_edges, visited)
                path_edges.pop()
                path_nodes.pop()
                visited.discard(edge.target_id)

        dfs(source_id, [source_id], [], {source_id})

        all_paths: list[CandidatePath] = []
        for paths in found.values():
            all_paths.extend(paths)
        return all_paths
