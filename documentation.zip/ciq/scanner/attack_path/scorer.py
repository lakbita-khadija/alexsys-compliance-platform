"""
scanner/attack_path/scorer.py

AttackPathScorer -- combine les facteurs de PathConstraintEvaluator en un
score borne et versionne (S8 : algorithm_version obligatoire ; S13 : la
formule ne doit pas etre codee en dur sans abstraction remplacable).
"""

from __future__ import annotations

from scanner.attack_path.constraints import PathFeasibility


class AttackPathScorer:
    ALGORITHM_VERSION = "1.0"

    WEIGHT_EXPOSURE = 0.35
    WEIGHT_PRIVILEGE = 0.30
    WEIGHT_TARGET_SENSITIVITY = 0.25
    WEIGHT_DEPTH_PENALTY = 0.10  # un chemin plus long est légèrement moins probable

    @classmethod
    def score(cls, feasibility: PathFeasibility) -> float:
        if feasibility.is_blocked:
            return 0.0  # bloqué par un contrôle de sécurité -> non exploitable

        depth = len(feasibility.path.node_ids) - 1
        depth_factor = max(0.0, 1.0 - (depth - 1) * 0.15)  # dégressif au-delà de 1 saut

        raw = (
            cls.WEIGHT_EXPOSURE * feasibility.exposure_factor
            + cls.WEIGHT_PRIVILEGE * feasibility.privilege_factor
            + cls.WEIGHT_TARGET_SENSITIVITY * feasibility.target_sensitivity
            + cls.WEIGHT_DEPTH_PENALTY * depth_factor
        )
        return round(min(raw * 100, 100.0), 2)

    @staticmethod
    def classify(score: float) -> str:
        if score >= 75:
            return "critical"
        if score >= 50:
            return "high"
        if score >= 25:
            return "medium"
        return "low"
