"""
scanner/attack_path/technique_mapper.py

AttackTechniqueMapper -- associe des etiquettes de technique a un chemin,
UNIQUEMENT a partir d'attributs reellement collectes (jamais une technique
inventee sans support dans les donnees, voir S19 du cahier des charges).
"""

from __future__ import annotations

from scanner.attack_path.constraints import PathFeasibility
from scanner.graph.models import ResourceGraph


class AttackTechniqueMapper:
    @staticmethod
    def map_techniques(feasibility: PathFeasibility, graph: ResourceGraph) -> list[str]:
        techniques: list[str] = []

        if feasibility.exposure_factor >= 1.0:
            techniques.append("public_exposure")

        if feasibility.privilege_factor >= 1.0:
            techniques.append("privilege_escalation")

        target_id = feasibility.path.node_ids[-1]
        target_node = graph.get_node(target_id)
        if target_node is not None:
            attrs = target_node.properties.get("attributes", {})
            if attrs.get("encrypted") is False:
                techniques.append("unencrypted_data_at_rest")
            if attrs.get("public_read_access") is True:
                techniques.append("public_data_read_access")

        if not techniques:
            techniques.append("network_reachability")

        return techniques
