"""
scanner/attack_path/models.py

AttackPath -- objet metier reel, pas une liste de noeuds. `algorithm_version`
est obligatoire et non optionnel : un AttackPath historique doit rester
interpretable meme si l'algorithme evolue (voir S8 du cahier des charges).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class ExposureLevel(str, Enum):
    INTERNET_FACING = "internet_facing"
    INTERNAL_ONLY = "internal_only"


@dataclass(frozen=True, slots=True)
class AttackPathEdgeRef:
    source_id: str
    target_id: str
    relationship_type: str
    blocked: bool


@dataclass(frozen=True, slots=True)
class AttackPath:
    id: str
    tenant_id: str
    source_resource_id: str
    target_resource_id: str
    nodes: list[str]
    edges: list[AttackPathEdgeRef]
    risk_score: float
    severity: str
    exposure: ExposureLevel
    attack_techniques: list[str]
    contributing_finding_ids: list[str]
    discovered_at: datetime
    graph_version: str
    algorithm_version: str = "1.0"

    @property
    def depth(self) -> int:
        return len(self.nodes) - 1
