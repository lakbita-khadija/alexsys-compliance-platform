"""
scanner/attack_path/analyzer.py

AttackPathAnalyzer -- orchestre PathDiscovery, PathConstraintEvaluator,
AttackPathScorer et AttackTechniqueMapper. Composants separes et
remplacables individuellement (S5), pas une seule methode monolithique.

Relie chaque AttackPath aux Finding qui y contribuent (S6) : un Finding en
FAIL sur un noeud du chemin est considere contributeur.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from scanner.attack_path.constraints import SENSITIVE_RESOURCE_TYPES, PathConstraintEvaluator
from scanner.attack_path.discovery import PathDiscovery
from scanner.attack_path.models import AttackPath, AttackPathEdgeRef, ExposureLevel
from scanner.attack_path.scorer import AttackPathScorer
from scanner.attack_path.technique_mapper import AttackTechniqueMapper
from scanner.graph.models import INTERNET_NODE_ID, ResourceGraph
from scanner.schema import ComplianceStatus, Finding

GRAPH_VERSION = "1.0"  # incrémenté si la structure du graphe change de forme


class AttackPathAnalyzer:
    def __init__(self, discovery: PathDiscovery | None = None) -> None:
        self._discovery = discovery or PathDiscovery()

    def analyze(
        self, graph: ResourceGraph, tenant_id: str, findings: list[Finding],
    ) -> list[AttackPath]:
        if graph.get_node(INTERNET_NODE_ID) is None:
            return []  # rien d'exposé -> aucune analyse à faire, pas une erreur

        targets = [
            n.id for n in graph.nodes if n.resource_type in SENSITIVE_RESOURCE_TYPES
        ]
        if not targets:
            return []

        candidates = self._discovery.discover(graph, INTERNET_NODE_ID, targets)
        findings_by_resource: dict[str, list[Finding]] = {}
        for f in findings:
            if f.status == ComplianceStatus.FAIL:
                findings_by_resource.setdefault(f.resource_id, []).append(f)

        # HEURISTIQUE ASSUMÉE, PAS UNE VÉRITÉ ABSOLUE : un finding est
        # considéré "contributeur" s'il est en FAIL sur un nœud du chemin
        # — pas nécessairement s'il rend TECHNIQUEMENT ce chemin précis
        # exploitable. Exemple concret observé en exécutant ce moteur :
        # "backup retention insuffisante" sur une RDS apparaît comme
        # contributeur d'un chemin SSH->RDS, alors qu'elle n'a aucun lien
        # causal avec l'exploitabilité de CE chemin. Affiner nécessiterait
        # de catégoriser chaque règle par "vecteur d'accès" vs "impact une
        # fois compromis" — hors périmètre de cette phase, documenté ici
        # plutôt que caché.

        attack_paths: list[AttackPath] = []
        now = datetime.now(timezone.utc)

        for candidate in candidates:
            feasibility = PathConstraintEvaluator.evaluate(candidate, graph)
            score = AttackPathScorer.score(feasibility)
            if score <= 0.0:
                continue  # bloqué ou score nul -> pas un attack path réel

            techniques = AttackTechniqueMapper.map_techniques(feasibility, graph)
            contributing_ids = [
                f.finding_id
                for node_id in candidate.node_ids
                for f in findings_by_resource.get(node_id, [])
            ]

            attack_paths.append(
                AttackPath(
                    id=str(uuid.uuid4()),
                    tenant_id=tenant_id,
                    source_resource_id=INTERNET_NODE_ID,
                    target_resource_id=candidate.node_ids[-1],
                    nodes=candidate.node_ids,
                    edges=[
                        AttackPathEdgeRef(e.source_id, e.target_id, e.relationship_type.value, e.blocked)
                        for e in candidate.edges
                    ],
                    risk_score=score,
                    severity=AttackPathScorer.classify(score),
                    exposure=ExposureLevel.INTERNET_FACING,
                    attack_techniques=techniques,
                    contributing_finding_ids=contributing_ids,
                    discovered_at=now,
                    graph_version=GRAPH_VERSION,
                    algorithm_version=AttackPathScorer.ALGORITHM_VERSION,
                )
            )

        return attack_paths
