"""
scanner/attack_path/constraints.py

PathConstraintEvaluator -- calcule, pour chaque chemin candidat, les
facteurs contextuels (exposition, privilege, controle de securite) qui
distinguent "chemin techniquement possible" de "chemin presentant un
risque de securite significatif" (S5, exigence explicite du cahier des
charges : PAS un shortest-path sans contexte).
"""

from __future__ import annotations

from dataclasses import dataclass

from scanner.attack_path.discovery import CandidatePath
from scanner.graph.models import ResourceGraph

# Types de ressources dont la compromission est jugee critique -- heuristique
# assumee et documentee, pas une verite absolue. A affiner avec un vrai
# catalogue de criticite des actifs (hors perimetre de cette phase).
SENSITIVE_RESOURCE_TYPES = frozenset({"rds_instance", "s3_bucket"})

# Attributs qui, s'ils indiquent un privilege eleve sur un noeud du chemin,
# aggravent le risque -- uniquement des attributs REELLEMENT collectes
# aujourd'hui par les collecteurs existants (has_admin_access sur iam_user).
PRIVILEGE_ATTRIBUTES = {"has_admin_access": True}


@dataclass(frozen=True, slots=True)
class PathFeasibility:
    path: CandidatePath
    is_blocked: bool          # au moins une arete bloquee par un controle
    exposure_factor: float    # 0.0-1.0
    privilege_factor: float   # 0.0-1.0
    target_sensitivity: float  # 0.0-1.0


class PathConstraintEvaluator:
    @staticmethod
    def evaluate(path: CandidatePath, graph: ResourceGraph) -> PathFeasibility:
        is_blocked = any(edge.blocked for edge in path.edges)

        # Exposition : le chemin part-il d'INTERNET (première arête) ?
        exposure_factor = 1.0 if path.edges and path.edges[0].source_id.startswith("__") else 0.5

        # Privilège : un nœud du chemin porte-t-il un attribut de privilège
        # élevé réellement collecté (ex: has_admin_access=True) ?
        privilege_factor = 0.0
        for node_id in path.node_ids:
            node = graph.get_node(node_id)
            if node is None:
                continue
            attrs = node.properties.get("attributes", {})
            if any(attrs.get(k) == v for k, v in PRIVILEGE_ATTRIBUTES.items()):
                privilege_factor = 1.0
                break

        target_id = path.node_ids[-1]
        target_node = graph.get_node(target_id)
        target_sensitivity = (
            1.0 if target_node and target_node.resource_type in SENSITIVE_RESOURCE_TYPES else 0.3
        )

        return PathFeasibility(
            path=path,
            is_blocked=is_blocked,
            exposure_factor=exposure_factor,
            privilege_factor=privilege_factor,
            target_sensitivity=target_sensitivity,
        )
