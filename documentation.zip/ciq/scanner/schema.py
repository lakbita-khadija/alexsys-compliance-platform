"""
scanner/schema.py

Modèles de données du scanner ComplianceIQ.

Tous les modèles sont des modèles Pydantic v2 : validés à chaque frontière,
immuables (frozen) et refusant les champs inconnus (extra="forbid").

⚠️ CONTRAT PARTAGÉ — NE PAS MODIFIER SANS ACCORD DE L'ÉQUIPE AI SERVICE
Les modèles NormalizedResource et Finding sont la frontière publiée entre
le Core Service (scanner) et l'AI Service. Leurs champs doivent
correspondre EXACTEMENT à ceux déclarés côté AI Service, sans quoi le
payload est rejeté (extra="forbid" ne pardonne pas un champ en trop).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from scanner.value_objects import ConfidenceScore, Evidence, RiskScore


class RelationshipType(str, Enum):
    """Types de relations réellement observables entre ressources cloud —
    volontairement restreint à ce que les collecteurs peuvent produire.
    N'ajouter une valeur ici que lorsqu'un collecteur peut réellement la
    peupler (voir le principe 'MISSING COLLECTOR CAPABILITY')."""

    CONTAINS = "contains"           # ex: VPC contains Subnet
    CONNECTS_TO = "connects_to"     # ex: Internet connects_to SecurityGroup
    PROTECTS = "protects"           # SecurityGroup protects RDS/EC2
    ALLOWS = "allows"               # SecurityGroup allows a port/CIDR
    ASSUMES = "assumes"             # Resource assumes IAMRole
    ACCESSES = "accesses"           # IAMRole accesses S3Bucket
    ATTACHED_TO = "attached_to"     # NIC attached_to Instance
    PUBLICLY_EXPOSED = "publicly_exposed"  # Resource publicly_exposed_to Internet


class ResourceRelationship(BaseModel):
    """Une relation dirigée depuis la ressource qui la porte vers une autre.

    `source_field` documente D'OÙ vient la donnée (quel attribut de quel
    appel API) — exigé pour ne jamais fabriquer une relation fictive :
    si `source_field` ne peut pas être renseigné honnêtement, la relation
    ne doit pas être créée."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    relationship_type: RelationshipType
    target_resource_id: str
    source_field: str
    properties: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Énumérations — alignées sur le contrat de l'AI Service
# ---------------------------------------------------------------------------
class CloudProvider(str, Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"


class Domain(str, Enum):
    """Domaines transverses évalués par le scanner."""

    IAM = "iam"
    NETWORK = "network"
    ENCRYPTION = "encryption"
    LOGGING = "logging"
    STORAGE = "storage"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def weight(self) -> int:
        return {"low": 1, "medium": 2, "high": 3, "critical": 4}[self.value]

    def downgrade(self) -> "Severity":
        """Rétrograde d'un cran. Utilisé quand la confiance est faible :
        une incertitude ne doit pas remonter au même niveau qu'un fait
        confirmé."""
        order = [Severity.LOW, Severity.MEDIUM, Severity.HIGH, Severity.CRITICAL]
        idx = order.index(self)
        return order[max(0, idx - 1)]


class ComplianceStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"


class Framework(str, Enum):
    """Référentiels supportés — identique à l'énumération de l'AI Service.

    CIS n'y figure volontairement pas : il sert de source de benchmark
    interne (champ `benchmark_source` d'une règle), jamais de valeur de
    framework sur un Finding, sous peine de rejet à la frontière.
    """

    ISO_27001 = "iso_27001"
    LOI_05_20 = "loi_05_20"
    DNSSI = "dnssi"
    NIST_CSF = "nist_csf"
    SOC_2 = "soc_2"


# ---------------------------------------------------------------------------
# Ressource normalisée (URM)
# ---------------------------------------------------------------------------
class NormalizedResource(BaseModel):
    """Une ressource cloud exprimée de façon indépendante du fournisseur.

    `attributes` porte les faits SPÉCIFIQUES au fournisseur sous forme de
    dictionnaire plat (`public_access_blocked`, `encrypted`, ...). C'est
    volontairement non typé : forcer chaque particularité d'AWS et d'Azure
    dans des champs typés est la façon la plus sûre de tuer une
    abstraction multi-cloud. Les règles YAML lisent ces clés par leur nom.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    resource_id: str
    resource_type: str  # s3_bucket, iam_user, security_group, ...
    cloud_provider: CloudProvider
    tenant_id: str
    region: str = "unknown"
    attributes: dict[str, Any] = Field(default_factory=dict)
    tags: dict[str, str] = Field(default_factory=dict)
    relationships: list[ResourceRelationship] = Field(default_factory=list)
    collected_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def environment(self) -> str:
        """Environnement déduit des tags. Retourne 'unknown' par défaut,
        jamais 'production' : on ne doit jamais sous-appliquer un contrôle
        par une supposition optimiste."""
        for key in ("Environment", "environment", "env", "Env"):
            if key in self.tags:
                return self.tags[key].lower()
        return "unknown"


# ---------------------------------------------------------------------------
# Finding
# ---------------------------------------------------------------------------
class Finding(BaseModel):
    """Le verdict d'une règle sur une ressource — modèle CANONIQUE unique
    du projet suite à la revue d'architecture (déprécie le Finding
    dupliqué de complianceiq-core).

    Immuable une fois créé (frozen=True) : un finding n'est jamais modifié,
    une nouvelle version est créée. C'est ce qui permet la traçabilité
    d'audit exigée par un outil GRC.

    Champs ajoutés suite à la revue (corrigent P3 de l'audit — aucune
    reproductibilité sans eux) :
      scan_id       : quel scan a produit ce finding
      rule_version  : quelle version de la règle a été évaluée
      region, environment : contexte suffisant pour que l'AI Service
                      explique un finding sans accéder à la base du Scanner
                      (voir Q6 de la revue) — ⚠️ absents du contrat qu'elle
                      documente aujourd'hui, à confirmer avec elle avant
                      de les considérer comme partie du contrat v1.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    finding_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    schema_version: str = "1.0"
    tenant_id: str
    scan_id: str
    cloud_provider: CloudProvider
    resource_id: str
    resource_type: str
    region: str | None = None
    environment: str | None = None
    rule_id: str
    rule_version: str = "1.0.0"
    domain: Domain
    severity: Severity
    status: ComplianceStatus
    description: str
    # Mapping primaire porté par la règle — la vue multi-référentiels
    # complète relève de la Compliance Intelligence Engine, pas d'ici.
    framework: Framework
    control_id: str
    evidence: "Evidence"
    detected_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    # --- champs INTERNES : jamais exposés à l'AI Service (extra="forbid"
    #     côté contrat rejetterait tout le payload s'ils fuitaient) ---
    risk: "RiskScore"
    confidence: "ConfidenceScore"
    version: int = 1
    superseded_by: str | None = None
    related_drift_event_ids: list[str] = Field(default_factory=list)
    related_attack_path_ids: list[str] = Field(default_factory=list)

    @property
    def is_violation(self) -> bool:
        return self.status == ComplianceStatus.FAIL
