"""
scanner/value_objects.py

Value objects introduits suite à la revue d'architecture du Finding.

Corrige trois défauts identifiés dans l'audit :
  P2 — Evidence était un dict libre à 3 formes non testées -> devient un
       modèle typé, discriminé par `outcome`.
  P8 — risk_score/confidence_score étaient des float nus, sans borne
       garantie ni version de modèle -> deviennent des value objects
       reproductibles.
  P3 — aucune règle ne portait de version -> RiskScore/ConfidenceScore
       imposent la traçabilité du modèle qui les a produits.

Tous frozen + extra="forbid", comme le reste du contrat du projet.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EvidenceOutcome(str, Enum):
    MATCHED = "matched"
    NOT_MATCHED = "not_matched"
    INDETERMINATE = "indeterminate"


class Evidence(BaseModel):
    """La preuve structurée d'un verdict de règle.

    Remplace le `dict[str, Any]` libre du moteur d'origine, qui produisait
    trois formes différentes selon l'issue (voir P2 de la revue) — aucune
    n'étant garantie par un type, donc invisible à la frontière avec
    l'AI Service tant qu'un test ne cassait pas.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    outcome: EvidenceOutcome
    observed_attribute: str
    expected_value: Any | None = None
    actual_value: Any | None = None
    operator: str | None = None
    collector: str = "unknown"
    collected_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    indeterminate_reason: str | None = None

    @field_validator("indeterminate_reason")
    @classmethod
    def _reason_only_when_indeterminate(cls, v, info):
        outcome = info.data.get("outcome")
        if outcome == EvidenceOutcome.INDETERMINATE and not v:
            raise ValueError("indeterminate_reason est requis quand outcome=indeterminate")
        if outcome != EvidenceOutcome.INDETERMINATE and v:
            raise ValueError("indeterminate_reason ne doit être renseigné que si indéterminé")
        return v


class RiskScore(BaseModel):
    """Score de risque interne, JAMAIS exposé au contrat AI Service.

    `model_version` est le champ non négociable identifié dans la revue
    (Q8) : sans lui, un score archivé n'est pas reproductible — on ne peut
    pas distinguer « le contexte a changé » de « la formule a changé ».
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    value: float
    model_version: str = "crsf-1.0"
    factors: dict[str, float] = Field(default_factory=dict)

    @field_validator("value")
    @classmethod
    def _bounded(cls, v: float) -> float:
        if not (0.0 <= v <= 100.0):
            raise ValueError(f"RiskScore.value doit être dans [0,100], reçu {v}")
        return round(v, 2)


class ConfidenceScore(BaseModel):
    """Confiance dans l'évidence collectée. Interne, jamais exposée."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    value: float
    model_version: str = "crsf-1.0"

    @field_validator("value")
    @classmethod
    def _bounded(cls, v: float) -> float:
        if not (0.0 <= v <= 100.0):
            raise ValueError(f"ConfidenceScore.value doit être dans [0,100], reçu {v}")
        return round(v, 2)

    @property
    def band(self) -> str:
        if self.value >= 85:
            return "high"
        if self.value >= 60:
            return "medium"
        return "low"
