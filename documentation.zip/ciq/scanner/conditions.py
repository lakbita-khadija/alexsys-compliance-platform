"""
scanner/conditions.py

Évaluateur de conditions récursif : AND / OR / NOT, feuilles sur la
ressource OU sur le graphe (fonctions enregistrées, jamais d'eval()).

Logique à TROIS valeurs (matched / not_matched / indeterminate), pas une
simple logique booléenne — c'est délibéré : le Rule Engine existant ne
traite déjà jamais un attribut manquant comme "conforme" (voir
scanner/rule_engine.py), et cette garantie doit se propager à travers les
combinaisons AND/OR/NOT, pas seulement aux feuilles isolées.

Rétrocompatibilité : les 33 règles YAML existantes utilisent la forme plate
{attribute, operator, value} — c'est exactement la forme d'une feuille de
cet évaluateur, donc AUCUNE règle existante n'a besoin d'être réécrite.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from scanner.graph.context import CONTEXT_FUNCTIONS, ResourceContext

_MISSING = object()


class ConditionOutcome:
    MATCHED = "matched"
    NOT_MATCHED = "not_matched"
    INDETERMINATE = "indeterminate"


class ConditionError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class ConditionResult:
    outcome: str
    trace: list[str] = field(default_factory=list)


_LEAF_OPERATORS = {
    "equals": lambda actual, expected: actual == expected,
    "not_equals": lambda actual, expected: actual != expected,
    "greater_than": lambda actual, expected: _safe_gt(actual, expected),
    "less_than": lambda actual, expected: _safe_lt(actual, expected),
    "contains": lambda actual, expected: _safe_contains(actual, expected),
    "not_contains": lambda actual, expected: not _safe_contains(actual, expected),
    "in": lambda actual, expected: _safe_contains(expected, actual),
    "not_in": lambda actual, expected: not _safe_contains(expected, actual),
    "exists": lambda actual, expected: actual is not _MISSING,
    "not_exists": lambda actual, expected: actual is _MISSING,
}


def _safe_gt(actual, expected):
    try:
        return actual is not None and actual is not _MISSING and actual > expected
    except TypeError:
        return False


def _safe_lt(actual, expected):
    try:
        return actual is not None and actual is not _MISSING and actual < expected
    except TypeError:
        return False


def _safe_contains(container, item):
    if container is None or container is _MISSING:
        return False
    try:
        return item in container
    except TypeError:
        return False


def evaluate_condition_tree(
    node: dict[str, Any], context: ResourceContext
) -> ConditionResult:
    """Point d'entrée récursif. `node` est un dict brut issu du YAML — voir
    le docstring du module pour la justification de ce choix plutôt qu'une
    modélisation Pydantic récursive profonde."""
    if "all" in node:
        return _evaluate_all(node["all"], context)
    if "any" in node:
        return _evaluate_any(node["any"], context)
    if "not" in node:
        return _evaluate_not(node["not"], context)
    return _evaluate_leaf(node, context)


def _evaluate_all(children: list[dict], context: ResourceContext) -> ConditionResult:
    results = [evaluate_condition_tree(c, context) for c in children]
    trace = [t for r in results for t in r.trace]
    if any(r.outcome == ConditionOutcome.NOT_MATCHED for r in results):
        return ConditionResult(ConditionOutcome.NOT_MATCHED, trace)
    if any(r.outcome == ConditionOutcome.INDETERMINATE for r in results):
        return ConditionResult(ConditionOutcome.INDETERMINATE, trace)
    return ConditionResult(ConditionOutcome.MATCHED, trace)


def _evaluate_any(children: list[dict], context: ResourceContext) -> ConditionResult:
    results = [evaluate_condition_tree(c, context) for c in children]
    trace = [t for r in results for t in r.trace]
    if any(r.outcome == ConditionOutcome.MATCHED for r in results):
        return ConditionResult(ConditionOutcome.MATCHED, trace)
    if any(r.outcome == ConditionOutcome.INDETERMINATE for r in results):
        return ConditionResult(ConditionOutcome.INDETERMINATE, trace)
    return ConditionResult(ConditionOutcome.NOT_MATCHED, trace)


def _evaluate_not(child: dict, context: ResourceContext) -> ConditionResult:
    result = evaluate_condition_tree(child, context)
    if result.outcome == ConditionOutcome.MATCHED:
        return ConditionResult(ConditionOutcome.NOT_MATCHED, result.trace)
    if result.outcome == ConditionOutcome.NOT_MATCHED:
        return ConditionResult(ConditionOutcome.MATCHED, result.trace)
    return result  # indeterminate reste indeterminate, jamais inversé


def _evaluate_leaf(node: dict, context: ResourceContext) -> ConditionResult:
    source = node.get("source", "resource")

    if source == "graph":
        function_name = node.get("function")
        fn = CONTEXT_FUNCTIONS.get(function_name)
        if fn is None:
            raise ConditionError(
                f"Fonction contextuelle inconnue : '{function_name}'. "
                f"Fonctions enregistrées : {sorted(CONTEXT_FUNCTIONS)}"
            )
        args = node.get("args", {})
        matched = bool(fn(context, **args))
        trace = [f"graph.{function_name}({args}) = {matched}"]
        return ConditionResult(
            ConditionOutcome.MATCHED if matched else ConditionOutcome.NOT_MATCHED, trace
        )

    attribute = node.get("attribute")
    operator = node.get("operator")
    expected = node.get("value")
    if operator not in _LEAF_OPERATORS:
        raise ConditionError(f"Opérateur non supporté : {operator}")

    actual = context.resource.attributes.get(attribute, _MISSING)
    if operator not in ("exists", "not_exists") and (actual is _MISSING or actual is None):
        trace = [f"resource.{attribute} indéterminé (non collecté)"]
        return ConditionResult(ConditionOutcome.INDETERMINATE, trace)

    matched = _LEAF_OPERATORS[operator](actual, expected)
    trace = [f"resource.{attribute} {operator} {expected} -> actual={actual!r} -> {matched}"]
    return ConditionResult(
        ConditionOutcome.MATCHED if matched else ConditionOutcome.NOT_MATCHED, trace
    )
