"""
scanner/scan_service.py

Orchestrateur du scan : collecte -> graphe -> évaluation -> attack path
-> enrichissement du risque -> (drift optionnel) -> rapport.

SÉQUENCE JUSTIFIÉE (voir le document d'assessment pour le raisonnement
complet) : le Resource Graph est construit AVANT l'évaluation des
règles, car des règles contextuelles (is_reachable_from_internet, etc.)
en dépendent. L'Attack Path Engine tourne APRÈS les Findings, car il a
besoin de savoir quels nœuds du graphe sont déjà en violation pour les
citer comme contributeurs. Le Risk Engine enrichit les Findings APRÈS
l'Attack Path, car `attack_path_involvement` ne peut être connu qu'à ce
moment — un second passage sur le risque, pas un recalcul complet.

Agnostique du fournisseur par construction : il accepte une liste de
collecteurs. Scanner AWS et Azure ensemble revient à passer deux
collecteurs — il n'y a aucun `if aws` dans ce fichier, et il ne doit
jamais y en avoir.
"""

from __future__ import annotations

import uuid
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone

from scanner.attack_path.analyzer import AttackPathAnalyzer
from scanner.attack_path.models import AttackPath
from scanner.collectors.base import BaseCollector, CollectionResult
from scanner.drift.diff_engine import DiffEngine
from scanner.drift.models import DriftEvent
from scanner.graph.builder import GraphBuilder
from scanner.graph.models import ResourceGraph
from scanner.rule_engine import RiskCalculator, RuleEngine
from scanner.schema import ComplianceStatus, Finding, NormalizedResource, Severity


@dataclass
class ScanReport:
    scan_id: str
    tenant_id: str
    started_at: datetime
    completed_at: datetime
    resources: list[NormalizedResource] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    graph: ResourceGraph | None = None
    attack_paths: list[AttackPath] = field(default_factory=list)
    drift_events: list[DriftEvent] = field(default_factory=list)

    @property
    def violations(self) -> list[Finding]:
        return [f for f in self.findings if f.status == ComplianceStatus.FAIL]

    @property
    def passed(self) -> list[Finding]:
        return [f for f in self.findings if f.status == ComplianceStatus.PASS]

    @property
    def is_complete(self) -> bool:
        return not self.errors

    @property
    def compliance_rate(self) -> float:
        """Taux de conformité = contrôles satisfaits / contrôles évalués.

        À ne PAS confondre avec un « score de conformité » global : ce
        chiffre ne dit rien des contrôles qui n'ont jamais été évalués.
        La distinction est traitée en détail par le Coverage Engine.
        """
        if not self.findings:
            return 0.0
        return round(len(self.passed) / len(self.findings) * 100, 2)

    def by_severity(self) -> dict[str, int]:
        return dict(Counter(f.severity.value for f in self.violations))

    def by_domain(self) -> dict[str, int]:
        return dict(Counter(f.domain.value for f in self.violations))

    def top_findings(self, limit: int = 10) -> list[Finding]:
        return sorted(self.violations, key=lambda f: f.risk.value, reverse=True)[:limit]


class ScanService:
    def __init__(self, collectors: list[BaseCollector], rule_engine: RuleEngine):
        self._collectors = collectors
        self._engine = rule_engine
        self._attack_path_analyzer = AttackPathAnalyzer()

    def run(
        self,
        tenant_id: str,
        previous_resources: dict[str, NormalizedResource] | None = None,
        previous_scan_id: str | None = None,
    ) -> ScanReport:
        """`previous_resources`/`previous_scan_id` sont optionnels : sans
        eux, aucun Drift n'est calculé (rien à comparer), mais Graph et
        Attack Path fonctionnent normalement dès le premier scan — la
        persistance qui fournira automatiquement le snapshot précédent
        est une phase dédiée, pas un prérequis de ce moteur."""
        scan_id = str(uuid.uuid4())
        started = datetime.now(timezone.utc)
        collected = CollectionResult()

        for collector in self._collectors:
            result = collector.collect(tenant_id)
            result.errors = [f"[{collector.name}] {e}" for e in result.errors]
            collected = collected.merge(result)

        # 1. Resource Graph — avant l'évaluation, pour les règles contextuelles
        graph = GraphBuilder.build(collected.resources, tenant_id)

        # 2. Policy Evaluation — graph-aware
        findings = self._engine.evaluate_all(
            collected.resources, scan_id=scan_id, tenant_id=tenant_id, graph=graph
        )

        # 3. Attack Path Analysis — après les Findings (cite les contributeurs)
        attack_paths = self._attack_path_analyzer.analyze(graph, tenant_id, findings)

        # 4. Risk enrichment — un second passage, pas un recalcul complet
        findings = self._enrich_with_attack_path_involvement(findings, attack_paths)

        # 5. Drift — uniquement si un snapshot précédent est fourni
        drift_events: list[DriftEvent] = []
        if previous_resources is not None and previous_scan_id is not None:
            current_by_id = {r.resource_id: r for r in collected.resources}
            drift_events = DiffEngine.compare(
                previous=previous_resources, current=current_by_id,
                previous_scan_id=previous_scan_id, current_scan_id=scan_id,
                tenant_id=tenant_id,
            )

        return ScanReport(
            scan_id=scan_id,
            tenant_id=tenant_id,
            started_at=started,
            completed_at=datetime.now(timezone.utc),
            resources=collected.resources,
            findings=findings,
            errors=collected.errors,
            graph=graph,
            attack_paths=attack_paths,
            drift_events=drift_events,
        )

    @staticmethod
    def _enrich_with_attack_path_involvement(
        findings: list[Finding], attack_paths: list[AttackPath]
    ) -> list[Finding]:
        involved_finding_ids: set[str] = {
            fid for path in attack_paths for fid in path.contributing_finding_ids
        }
        path_ids_by_finding: dict[str, list[str]] = {}
        for path in attack_paths:
            for fid in path.contributing_finding_ids:
                path_ids_by_finding.setdefault(fid, []).append(path.id)

        enriched: list[Finding] = []
        for finding in findings:
            if finding.finding_id not in involved_finding_ids:
                enriched.append(finding)
                continue

            # RiskCalculator n'a pas accès à la ressource ici (seulement au
            # Finding) — on ajuste le RiskScore directement plutôt que de
            # retraverser tout le calcul, en documentant explicitement le
            # facteur ajouté. Le model_version reste crsf-1.1 (formule
            # inchangée), seule la valeur du facteur est mise à jour.
            new_risk = finding.risk.model_copy(
                update={
                    "value": min(
                        round(finding.risk.value + finding.risk.value * RiskCalculator.WEIGHT_ATTACK_PATH, 2),
                        100.0,
                    ),
                    "factors": {**finding.risk.factors, "attack_path_involvement": 1.0},
                }
            )
            enriched.append(
                finding.model_copy(
                    update={
                        "risk": new_risk,
                        "related_attack_path_ids": path_ids_by_finding.get(finding.finding_id, []),
                    }
                )
            )
        return enriched
