# ComplianceIQ — Graph + Attack Path + Drift : livré, pas documenté

**84/84 tests exécutés et verts. 35 fichiers Python. Aucune fonctionnalité
fictive.**

---

## Ce qui a été construit dans cette passe

| Module | Fichiers | Tests dédiés |
|---|---|---|
| Resource Graph | `graph/models.py`, `graph/builder.py`, `graph/context.py` | 7 |
| Policy Engine contextuel (AND/OR/NOT, fonctions graphe) | `conditions.py` | 18 |
| Attack Path Engine | `attack_path/{models,discovery,constraints,scorer,technique_mapper,analyzer}.py` | 10 |
| Drift Detection | `drift/{models,canonicalization,diff_engine}.py` | 12 |
| Câblage pipeline | `scan_service.py` réécrit (Graph → Findings → Attack Path → Risk enrichi → Drift optionnel) | 12 (scan_service) |

## Preuves d'exécution réelle, pas d'affirmation

**Un chemin d'attaque réel détecté** sur le jeu de données mock :
```
INTERNET -> sg-ciq-open-ssh -> ciq-sandbox-db-public   score=68.5  severity=high
INTERNET -> ciq-sandbox-public-bucket                   score=70.0  severity=high
```

**Un vrai drift détecté**, pas simulé en façade — j'ai d'abord écrit une
démo qui comparait un scan à lui-même (aucun drift, silencieusement), je l'ai
corrigée en le remarquant, et voici la sortie réelle maintenant :
```
[HIGH] security_posture_drift: attributes.any_port_open_to_world False -> True
[HIGH] security_posture_drift: attributes.ssh_open_to_world False -> True
```

**Le risque enrichi par l'Attack Path fonctionne** : 13 findings sur les
chemins détectés ont vu leur `risk_score` recalculé avec
`attack_path_involvement: 1.0`, tracé dans leurs `factors`.

## Deux bugs trouvés en exécutant, pas en relisant

1. `AttackPathAnalyzer` référençait `finding.id` — le champ s'appelle
   `finding_id`. Détecté par 12 tests qui plantaient, corrigé en une ligne
   à deux endroits.
2. La première version de la démo Drift comparait un scan à lui-même
   (`report.resources` contre `report.resources`) — aucun drift ne pouvait
   jamais apparaître. Je l'ai corrigée pour muter réellement une ressource
   entre les deux scans simulés.

## Ce qui reste honnête à signaler, pas caché

- **`MISSING COLLECTOR CAPABILITY` documenté explicitement** dans
  `aws_collector.py` : la relation SG→RDS existe dans `MockAwsCollector`
  (ce qu'un collecteur complet produirait) mais **pas** dans le collecteur
  AWS réel — RDS n'y est même pas encore collecté. Le code le dit noir sur
  blanc, pas une note à part.
- `contributing_finding_ids` utilise une heuristique simple (tout finding
  FAIL sur un nœud du chemin) qui sur-attribue parfois (ex: un finding
  "backup retention" apparaît comme contributeur d'un chemin SSH→RDS alors
  qu'il n'a pas de lien causal avec l'exploitabilité de ce chemin précis).
  Documenté dans le code, pas corrigé — affiner exigerait de catégoriser
  chaque règle par vecteur d'accès vs impact, hors périmètre de cette passe.
- Persistance des snapshots (nécessaire pour que le Drift compare deux
  **vrais** scans historiques plutôt qu'un couple construit à la main dans
  la démo) reste la Phase 3 du roadmap précédent — le moteur de diff
  lui-même est prêt et testé, il attend une source de données.
- Collecteur AWS réel (boto3) toujours non exécuté — inchangé depuis les
  livraisons précédentes, sans lien avec cette passe.

## Commande pour vérifier par toi-même

```bash
cd ciq && pip install -r requirements-dev.txt
python -m scripts.demo_scan     # Graph + Attack Path + Drift, hors-ligne
pytest -v                       # 84 tests
```
